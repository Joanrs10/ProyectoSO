﻿#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <mysql.h>
#include <pthread.h>
#include <my_global.h>

//estructura para sockets y conectados
typedef struct{
	char nombre[50];
	int socket;
}Conectado;
typedef struct{
	int numero;
	Conectado conectados[100];
}ListaConectados;


int PonerEnListaConectados(char nombre[50],int socket, ListaConectados *lista) //Funcion que recibe un nombre y lo introduce en una lista de conectados, retorna 0 si lo hace con exito y -1 en caso contrario
	
{
	if (lista->numero<100)
	{
		lista->conectados[lista->numero].socket=socket;
		strcpy(lista->conectados[lista->numero].nombre,nombre);
		lista->numero++;
		return 0;
	}
	else
		return -1;
}


int EliminarJugador(char nombre[50],ListaConectados *lista) //Funcion que recibe el nombre y la lista conectados, busca el nombre en la lista y elimina el jugador, retorna 0 si lo hace con exito y -1 en caso contrario
{
	int encontrado=0;
	int i=0;
	while ((i<lista->numero) &&(!encontrado))
	{
		if (strcmp(lista->conectados[i].nombre,nombre)==0)
			encontrado=1;
		else
			i=i+1;
	}
	if (encontrado)
	{
		while (i<lista->numero-1)
		{
			lista->conectados[i]=lista->conectados[i+1];
			i=i+1;
		}
		lista->numero=lista->numero-1;
		return 0;
	}
	else
		return -1;
}

void DameUsuario(char nombre[50],ListaConectados *lista, int socket) //Recibe un nombre y la lista de conectados y retorna el socket que tiene ese jugador
	
{
	int encontrado=0;
	int i=0;
	while((i<lista->numero)&&(!encontrado))
	{
		if (lista->conectados[i].socket==socket)
			encontrado=1;
		else
			i=i+1;
	}
	if (encontrado)
		strcpy(nombre,lista->conectados[i].nombre);
}

int DameSocket(char nombre[50],ListaConectados *lista) //Recibe un nombre y la lista conectados y busca el siguiente socket libre, retorna el numero de socket si encuentra uno libre o -1 si no hay un socket libre 
	
{
	int encontrado=0;
	int i=0;
	while((i<lista->numero)&&(!encontrado))
	{
		if (strcmp(lista->conectados[i].nombre,nombre)==0)
			encontrado=1;
		else
			i=i+1;
	}
	if (encontrado)
		return lista->conectados[i].socket;
	else
		return -1;
}


void DameConectados(ListaConectados *lista, char conectados[100]) //Recibe una lista de conectados y retorna un vector con los nombres y los sockets de esos jugadores
{
	int i;
	sprintf(conectados,"%d",lista->numero);
	for(i=0;i<(lista->numero);i++)
		sprintf(conectados,"%s/%s/%d",conectados,lista->conectados[i].nombre,lista->conectados[i].socket);
	
}





typedef struct{
	int id_partida;
	int contjug;
	char Jugadores[100];
}TablaPartida;




void Rellenar(TablaPartida table[100]) //Recibe una tabla y la rellena con parametros para ser modificados posteriormente
{
	int cont=0;
	while (cont<100)
	{
		table[cont].id_partida=-1;
		table[cont].contjug=0;
		cont=cont+1;
	}
	return;
}

int AnadirPartida(TablaPartida table[100], char jugador[100]) //Funcion que añade una partida a la tabla de partidas (Funcion no usada al final ya que el protocolo de invitacion no funciona)
{
	int cont=0;
	int encontrado=0;
	while ((!encontrado)&&(cont<100))
	{
		if (table[cont].id_partida==-1)
			encontrado=1;
		else
			cont=cont+1;
	}
	if (encontrado==1)
	{
		strcpy(table[cont].Jugadores,jugador);
		int tajadita=0;
		char *p=strtok(jugador,"/");
		while (p!=NULL)
		{
			tajadita=tajadita+1;
			p=strtok(NULL,"/");
		}
		table[cont].contjug=tajadita;
		table[cont].id_partida=cont;
		return cont;
	}
	else
		return -1;
}

int EliminarPartida(TablaPartida table[100], int id) //Funcion que elimina una partida de la tabla de partidas (Funcion no usada al final ya que el protocolo de invitacion no funciona)
{
	if ((id>=0) && (id<=100))
	{
		table[id].Jugadores,"";
		table[id].id_partida=-1;
		return id;
	}
	else
					return -1;
}

int contador;
ListaConectados miLista;
TablaPartida miTablaPartidas[100];
char lista9 [100];
int numres=0;
int AlgunoNo=0;
int partidita;
int puntos;





//Estructura acceso excluyente
pthread_mutex_t mutex=PTHREAD_MUTEX_INITIALIZER;

void *AtenderCliente (void *socket) //Funcion de Atender CLiente, lee el codigo del mensaje proveniente del cliente y realiza la funcion que toque
{
	int sock_conn;
	int *s;
	s=(int *) socket;
	sock_conn=*s;
	
	char peticion[512];
	char respuesta[512];
	int ret;
	
	int edad;
	int numero;
	char dni[10];
	char consulta [200];
	
	
	int terminar=0;
	
	// Entramos en un bucle para atender todas las peticiones de este cliente
	//hasta que se desconecte
	while (terminar ==0)
	{
		// Ahora recibimos la petici?n
		ret=read(sock_conn,peticion, sizeof(peticion));
		printf ("Recibido\n");
		
		MYSQL *conn;
		int err;
		// Estructura especial para almacenar resultados de consultas 
		MYSQL_RES *resultado;
		MYSQL_ROW row;
		
		//Creamos una conexion al servidor MYSQL 
		conn = mysql_init(NULL);
		if (conn==NULL) {
			printf ("Error al crear la conexiÃ¯Â¿Ã¯\u0178Â³n: %u %s\n", 
					mysql_errno(conn), mysql_error(conn));
			exit (1);
		}
		//inicializar la conexion
		conn = mysql_real_connect (conn, "shiva2.upc.es","root", "mysql", "Juego",0, NULL, 0);
		if (conn==NULL) {
			printf ("Error al inicializar la conexiÃ¯Â¿Ã¯\u0178Â³n: %u %s\n", 
					mysql_errno(conn), mysql_error(conn));
			exit (1);
		}
		// consulta SQL para obtener una tabla con todos los datos
		// de la base de datos
		err=mysql_query (conn, "SELECT * FROM Jugador");
		if (err!=0) {
			printf ("Error al consultar datos de la base %u %s\n",
					mysql_errno(conn), mysql_error(conn));
			exit (1);
		}
		//recogemos el resultado de la consulta. El resultado de la
		//consulta se devuelve en una variable del tipo puntero a
		//MYSQL_RES tal y como hemos declarado anteriormente.
		//Se trata de una tabla virtual en memoria que es la copia
		//de la tabla real en disco.
		resultado = mysql_store_result (conn);
		// El resultado es una estructura matricial en memoria
		// en la que cada fila contiene los datos de una persona.
		
		// Ahora obtenemos la primera fila que se almacena en una
		// variable de tipo MYSQL_ROW
		row = mysql_fetch_row (resultado);
		// En una fila hay tantas columnas como datos tiene una
		// persona. En nuestro caso hay tres columnas: dni(row[0]),
		// nombre(row[1]) y edad (row[2]).
		if (row == NULL)
			printf ("No se han obtenido datos en la consulta\n");
		else
		{
			while (row !=NULL) 
			{
				// la columna 2 contiene una palabra que es la edad
				// la convertimos a entero 
				
				// las columnas 0 y 1 contienen DNI y nombre 
				printf ("ID: %s, Username: %s, Password: %s\n", row[0], row[1], row[2]);
				// obtenemos la siguiente fila
				row = mysql_fetch_row (resultado);
			}
		}
		
		
		err=mysql_query (conn, "SELECT * FROM Relacion");
		if (err!=0) {
			printf ("Error al consultar datos de la base %u %s\n",
					mysql_errno(conn), mysql_error(conn));
			exit (1);
		}
		//recogemos el resultado de la consulta. El resultado de la
		//consulta se devuelve en una variable del tipo puntero a
		//MYSQL_RES tal y como hemos declarado anteriormente.
		//Se trata de una tabla virtual en memoria que es la copia
		//de la tabla real en disco.
		resultado = mysql_store_result (conn);
		// El resultado es una estructura matricial en memoria
		// en la que cada fila contiene los datos de una persona.
		
		// Ahora obtenemos la primera fila que se almacena en una
		// variable de tipo MYSQL_ROW
		row = mysql_fetch_row (resultado);
		// En una fila hay tantas columnas como datos tiene una
		// persona. En nuestro caso hay tres columnas: dni(row[0]),
		// nombre(row[1]) y edad (row[2]).
		if (row == NULL)
			printf ("No se han obtenido datos en la consulta\n");
		else
		{
			while (row !=NULL) 
			{
				// la columna 2 contiene una palabra que es la edad
				// la convertimos a entero 
				
				// las columnas 0 y 1 contienen DNI y nombre 
				printf ("Id jugador: %d, Id partida: %d, puntos: %d\n", atoi(row[0]), atoi(row[1]), atoi(row[2]));
				// obtenemos la siguiente fila
				row = mysql_fetch_row (resultado);
			}
		}
		
		err=mysql_query (conn, "SELECT * FROM Partida");
		if (err!=0) {
			printf ("Error al consultar datos de la base %u %s\n",
					mysql_errno(conn), mysql_error(conn));
			exit (1);
		}
		//recogemos el resultado de la consulta. El resultado de la
		//consulta se devuelve en una variable del tipo puntero a
		//MYSQL_RES tal y como hemos declarado anteriormente.
		//Se trata de una tabla virtual en memoria que es la copia
		//de la tabla real en disco.
		resultado = mysql_store_result (conn);
		// El resultado es una estructura matricial en memoria
		// en la que cada fila contiene los datos de una persona.
		
		// Ahora obtenemos la primera fila que se almacena en una
		// variable de tipo MYSQL_ROW
		row = mysql_fetch_row (resultado);
		// En una fila hay tantas columnas como datos tiene una
		// persona. En nuestro caso hay tres columnas: dni(row[0]),
		// nombre(row[1]) y edad (row[2]).
		if (row == NULL)
			printf ("No se han obtenido datos en la consulta\n");
		else
		{
			while (row !=NULL) 
			{
				// la columna 2 contiene una palabra que es la edad
				// la convertimos a entero 
				
				// las columnas 0 y 1 contienen DNI y nombre 
				printf ("Id: %d, Ganador: %s, Durada: %d\n", atoi(row[0]), row[1], atoi(row[2]));
				// obtenemos la siguiente fila
				row = mysql_fetch_row (resultado);
			}
		}
		
		// Tenemos que a?adirle la marca de fin de string 
		// para que no escriba lo que hay despues en el buffer
		peticion[ret]='\0';
		
		
		printf ("Peticion: %s\n",peticion);
		
		// vamos a ver que quieren
		char *p = strtok( peticion, "/");
		int codigo =  atoi (p);
		// Ya tenemos el codigo de la petici?n
		char nombre[20];
		char partida[20];
		char usuario[50];
		char contrasenya[50];
		char fila[20];
		int SocketRival;
		char invitacion[50];
		int contTabla;
		
		DameUsuario(usuario,&miLista, sock_conn);
		
		
		
		if (codigo ==00)//peticion de desconexion
		{
			char respuesta1[512];
			strcpy(respuesta1,"OK");
			strcpy(respuesta, "00|OK");
			sprintf(respuesta, "00|%s",respuesta1);
			break;
		
		}

		else if (codigo ==1) //Consulta 1, enviamos mensaje 1 a cliente con las partidas ganadas por el usuario recibido
		{
			p = strtok( NULL, "/");
			char usuario[20];
			strcpy (usuario, p); 
			char consulta[80]; 
			strcpy(consulta,"SELECT Jugador.Partidasganadas FROM Jugador WHERE Jugador.username = '");
			strcat(consulta,usuario);
			strcat(consulta,"'");
			err=mysql_query (conn,consulta);
			
			if (err!=0)
			{
				printf ("Error al consultar datos de la base %u %s\n",
						mysql_errno(conn), mysql_error(conn));
				exit (1);
			}
			
			resultado = mysql_store_result (conn);
			row = mysql_fetch_row (resultado);
			if (row == NULL)
			{
				printf ("No se han obtenido datos en la consulta\n");
			}
			else
			{
				while (row !=NULL) 
				{
					
					char respuesta1[512];
					strcpy(respuesta1,row[0]);
					row = mysql_fetch_row (resultado);
					sprintf(respuesta, "1|%s", respuesta1);
					break;
				}
			}			
		}
		
		else if (codigo ==11) //Consulta 2, enviamos mensaje 12a cliente con las partidas perdidas por el usuario recibido
		{
			p = strtok( NULL, "/");
			char usuario[20];
			strcpy (usuario, p); 
			char consulta[80]; 
			strcpy(consulta,"SELECT Jugador.Partidasperdidas FROM Jugador WHERE Jugador.username = '");
			strcat(consulta,usuario);
			strcat(consulta,"'");
			err=mysql_query (conn,consulta);
			
			if (err!=0)
			{
				printf ("Error al consultar datos de la base %u %s\n",
						mysql_errno(conn), mysql_error(conn));
				exit (1);
			}
			
			resultado = mysql_store_result (conn);
			row = mysql_fetch_row (resultado);
			if (row == NULL)
			{
				printf ("No se han obtenido datos en la consulta\n");
			}
			else
			{
				while (row !=NULL) 
				{
					
					char respuesta1[512];
					strcpy(respuesta1,row[0]);
					row = mysql_fetch_row (resultado);
					sprintf(respuesta, "11|%s", respuesta1);
					break;
				}
			}			
		}
		else if (codigo ==2) //Consulta 3, enviamos a cliente la contraseña del jugador que nos pida
		{
			p = strtok( NULL, "/");
			char usuario[20];
			strcpy (usuario, p); 
			char consulta[80]; 
			strcpy(consulta,"SELECT Jugador.password FROM Jugador WHERE Jugador.username = '");
			strcat(consulta,usuario);
			strcat(consulta,"'");
			//strcat(consulta1,"'AND Partida.id = Relacion.Id_partida AND jugador.id = relacion.Id_jugador");
			err=mysql_query (conn,consulta);
			
			if (err!=0)
			{
				printf ("Error al consultar datos de la base %u %s\n",
						mysql_errno(conn), mysql_error(conn));
				exit (1);
			}
			
			resultado = mysql_store_result (conn);
			row = mysql_fetch_row (resultado);
			if (row == NULL)
			{
				printf ("No se han obtenido datos en la consulta\n");
			}
			else
			{
				while (row !=NULL) 
				{
					
					char respuesta1[512];
					strcpy(respuesta1,row[0]);
					row = mysql_fetch_row (resultado);
					sprintf(respuesta, "2|%s", respuesta1);
					break;
				}
			}			
		}
		else if (codigo ==3) //Consulta 3
		{
			strcpy(respuesta,"");
			strcpy(consulta,"SELECT * FROM Jugador");
			err=mysql_query (conn, consulta); 
			if (err!=0) {
				printf ("Error al consultar datos de la base %u %s\n",
						mysql_errno(conn), mysql_error(conn));
				exit (1);
			}
			//recogemos el resultado de la consulta 
			resultado = mysql_store_result (conn); 
			row = mysql_fetch_row (resultado);
			if (row == NULL)
				printf ("No se han obtenido datos en la consulta\n");
			else
			{
				while (row !=NULL) 
				{
					
					char respuesta1[512];
					strcpy(respuesta1, row[1]);
					row = mysql_fetch_row (resultado);// El resultado debe ser una matriz con una sola fila
					if (row == NULL)// y una columna que contiene el nombre
					{
						sprintf(respuesta, "3|%s", respuesta1);
						//write(sock_conn, respuesta, strlen(respuesta));
						break;
					}	
				}	
			}
			
			
		}			
		else if (codigo == 4) //Login, comprobamos usuario y contraseña y enviamos a cliente o si (caso correcto), inc (caso incorrecto), no (caso que no se encuentre el usuario)
		{
			p = strtok( NULL, "/");
			strcpy(usuario,p);
			p = strtok( NULL, "/");
			strcpy(contrasenya,p);
			
			strcpy(respuesta,"");
			strcpy(consulta,"SELECT Jugador.Password FROM Jugador WHERE Jugador.Username='");
			strcat(consulta,usuario);
			strcat(consulta,"'");
			pthread_mutex_lock(&mutex);
			err=mysql_query (conn, consulta); 
			pthread_mutex_unlock(&mutex);
			if (err!=0) {
				printf ("Error al consultar datos de la base %u %s\n",
						mysql_errno(conn), mysql_error(conn));
				exit (1);
			}
			//recogemos el resultado de la consulta 
			resultado = mysql_store_result (conn); 
			row = mysql_fetch_row (resultado);
			printf("ContrasenyaBBDD: %s\n",row[0]);
			printf("Contrasenya: %s\n",contrasenya);
			if (row == NULL)
			{
				printf ("No se han obtenido datos en la consulta\n");
				strcpy(respuesta,"4|NO");
			}
			
			else
			{
				if (strcmp(row[0],contrasenya)==0)
				{
					strcpy(respuesta,"4|SI");
					
					pthread_mutex_lock(&mutex);
					int cod=PonerEnListaConectados(usuario,sock_conn,&miLista);
					pthread_mutex_unlock(&mutex);
					if (cod==-1)
						printf("Error\n");
				}
				else
					strcpy(respuesta,"4|INC");
			}
		}
		
		else if (codigo == 5) //Registro, recibimos usuario y contraseña y lo añadimos a la bbdd
		{
			p = strtok( NULL, "/");
			strcpy(usuario,p);
			p = strtok( NULL, "/");
			strcpy(contrasenya,p);
			
			strcpy(respuesta,"");
			strcpy(consulta,"SELECT * FROM Jugador");
			pthread_mutex_lock(&mutex);
			err=mysql_query (conn, consulta); 
			pthread_mutex_unlock(&mutex);
			if (err!=0) {
				printf ("Error al consultar datos de la base %u %s\n",
						mysql_errno(conn), mysql_error(conn));
				exit (1);
			}
			//recogemos el resultado de la consulta 
			resultado = mysql_store_result (conn); 
			row = mysql_fetch_row (resultado);
			if (row == NULL)
				printf ("No se han obtenido datos en la consulta\n");
			else
			{
				int encontrado=0;
				//idc sera un contador per saber quina id esta lliure
				int idc=0;
				while ((row != NULL) && (encontrado ==0))
				{
					if (strcmp(usuario,row[1])==0)
						encontrado=1;
					else
					{
						row = mysql_fetch_row (resultado);
						idc=idc+1;
					}
				}
				if (encontrado==0)
				{
					idc=idc+1;
					char idc1[3];
					strcpy(respuesta,"");
					strcpy(consulta,"INSERT INTO Jugador (id,username,password,Partidasganadas,Partidasperdidas) VALUES ('");
					//sprintf(idc1,"%d",idc);
					strcat(consulta,idc);
					strcat(consulta,",'");
					strcat(consulta,usuario);
					strcat(consulta,"','");
					strcat(consulta,contrasenya);
					strcat(consulta,"','");
					strcat(consulta,0);
					strcat(consulta,"','");
					strcat(consulta,0);
					strcat(consulta,"')");
					pthread_mutex_lock(&mutex);
					err=mysql_query (conn, consulta); 
					pthread_mutex_unlock(&mutex);
					if (err!=0) {
						printf ("Error al consultar datos de la base %u %s\n",
								mysql_errno(conn), mysql_error(conn));
						strcpy(respuesta,"5|NO");
						exit (1);
					}
					else
						strcpy(respuesta,"5|SI");
				}
				else
				{
					strcpy(respuesta,"5|EXIS");
				}
			}
		}
		
		else if (codigo == 6) //Borrar usuario BBDD
		{
			p = strtok( NULL, "/");
			strcpy(usuario,p);
			p = strtok( NULL, "/"); 
			strcpy(contrasenya,p);
			
			strcpy(respuesta,"");
			strcpy(consulta,"SELECT * FROM Jugador");
			pthread_mutex_lock(&mutex);
			err=mysql_query (conn, consulta); 
			pthread_mutex_unlock(&mutex);
			if (err!=0) {
				printf ("Error al consultar datos de la base %u %s\n",
						mysql_errno(conn), mysql_error(conn));
				exit (1);
			}
			//recogemos el resultado de la consulta 
			resultado = mysql_store_result (conn); 
			row = mysql_fetch_row (resultado);
			if (row == NULL)
				printf ("No se han obtenido datos en la consulta\n");
			else
			{
				int encontrado=0;
				//idc sera un contador per saber quina id esta lliure
				int idc=0;
				while ((row != NULL) && (encontrado ==0))
				{
					if (strcmp(usuario,row[1])==0)
						encontrado=1;
					else
					{
						row = mysql_fetch_row (resultado);
						idc=idc+1;
					}
				}
				if (encontrado==1)
				{
					idc=idc;
					char idc1[3];
					strcpy(respuesta,"");
					strcpy(consulta,"DELETE FROM Jugador (id,username,password,Partidasganadas,Partidasperdidas) WHERE username=' AND password=' LIMIT 1");
					//sprintf(idc1,"%d",idc);
					//strcat(consulta,idc);
					//strcat(consulta,",'");
					strcat(consulta,usuario);
					//strcat(consulta,"','");
					strcat(consulta,contrasenya);
					//strcat(consulta,0);
					//strcat(consulta,0);
					//strcat(consulta,"')");
					pthread_mutex_lock(&mutex);
					err=mysql_query (conn, consulta); 
					pthread_mutex_unlock(&mutex);
					if (err!=0) {
						printf ("Error al consultar datos de la base %u %s\n",
								mysql_errno(conn), mysql_error(conn));
						strcpy(respuesta,"7|NO");
						exit (1);
					}
					else
						strcpy(respuesta,"7|SI");
				}
				else
				{
					strcpy(respuesta,"7|NOEXIS");
				}
			}
		}
		
		else if (codigo==8) //Protocolo de invitacion
		{
			//desde C hem enviat una | per poguer agafar tots els noms ja separats per / i guardarlos directament a la taula
			
			p = strtok( NULL, "|");
			strcpy(fila,p);
			//aÃ±adimos partida a la Tabla
			
			sprintf(fila,"%s/%s",fila,usuario);
			pthread_mutex_lock(&mutex);
			int err=AnadirPartida(miTablaPartidas,fila);
			pthread_mutex_unlock(&mutex);
			if (err==-1)
				printf("Error\n");
			else
			{
				printf("Se ha aÃ±adido a partida:%d\n",err);
				contTabla=err;
			}
			
			
			sprintf(invitacion,"8|%s/%d",usuario,err);
			
			int c=0;
			//a buff nomes agafem tot el que tenim a la partida
			char buff[100];
			strcpy(buff,miTablaPartidas[contTabla].Jugadores);
			//buff1 ho utilitzarem per recorrer els jugadors
			char buff2 [10];
			strcpy(buff2,strtok(buff,"/"));
			while (strcmp(buff2,usuario)!=0)
			{
				SocketRival=DameSocket(buff2,&miLista);
				// Enviamos respuesta
				write(SocketRival,invitacion, strlen(invitacion));
				strcpy(buff2,strtok(NULL,"/"));
				/*contjug=contjug+1;*/
			}
			
			
		}
		
		
		
		else if (codigo == 10) //Funcion de mensaje de chat
		{
			p=strtok(NULL,"/");
			partidita=atoi(p);
			p=strtok(NULL,"\0");
			char cod10[512];
			strcpy(cod10,p);
			char buff[100];
			strcpy(buff,miTablaPartidas[partidita].Jugadores);
			char buff2[10];
			p=strtok(buff,"/");
			sprintf(respuesta,"10|%s: %s",usuario,cod10);
			while (p!=NULL)
			{
				strcpy(buff2,p);
				SocketRival=DameSocket(buff2,&miLista);
				write(SocketRival,respuesta,strlen(respuesta));
				p=strtok(NULL,"/");
			}
		}
		
		else if (codigo==12) //Timer agotado, random number selected
		{
			p=strtok(NULL,"/");
			partidita=atoi(p);
			int r = rand() % 37;
			char buff[100];
			strcpy(buff,miTablaPartidas[partidita].Jugadores);
			char buff2[10];
			p=strtok(buff,"/");
			sprintf(respuesta,"12|%d",r);
			while (p!=NULL)
			{
				strcpy(buff2,p);
				SocketRival=DameSocket(buff2,&miLista);
				write(SocketRival,respuesta,strlen(respuesta));
				p=strtok(NULL,"/");
			}
		}
		
		else if (codigo==14)
		{
			p=strtok(NULL,"/");
			partidita=atoi(p);
			char pers[20];
			p=strtok(NULL,"/");
			strcpy(pers,p);
			p=strtok(NULL,"/");
			puntos=atoi(p);
			char buff[100];
			strcpy(buff,miTablaPartidas[partidita].Jugadores);
			char buff2[10];
			p=strtok(buff,"/");
			sprintf(respuesta,"14|%s/%d",pers,puntos);
			while (p!=NULL)
			{
				strcpy(buff2,p);
				SocketRival=DameSocket(buff2,&miLista);
				write(SocketRival,respuesta,strlen(respuesta));
				p=strtok(NULL,"/");
			}
		}
		else if(codigo==20) //Iniciacion de partida conjunta
		{
			char notif[20];
			int x;
			sprintf(notif, "20|");
			while (x<miLista.numero)
			{
				write(miLista.conectados[x].socket, notif, strlen(notif));
				x=x+1;
			}
		}
		
		
		
		if ((codigo!=8) && (codigo!=9)&& (codigo!=10)&& (codigo!=12)&& (codigo!=14)&& (codigo!=15)  && (codigo!=20))
		{
			printf ("Respuesta: %s\n", respuesta);
			// Enviamos respuesta
			write(sock_conn,respuesta, strlen(respuesta));
		}
		
		
		
		if ((codigo==1)||(codigo==2)||(codigo==3)||(codigo==8)||(codigo==9)||(codigo==10)||(codigo==12)||(codigo==14)||(codigo==15)||(codigo==20))
		{
			pthread_mutex_lock(&mutex);
			contador=contador+1;
			pthread_mutex_unlock(&mutex);
		}
		
		if ((codigo==4)||(codigo==0))
		{
			char conectados[100];
			DameConectados(&miLista,conectados);
			printf ("%s\n",conectados);
			char notificacion[20];
			sprintf(notificacion, "6|%s", conectados);
			printf("Notificacion: %s\n", notificacion);
			int j=0;
			while (j<miLista.numero)
			{
				write(miLista.conectados[j].socket, notificacion, strlen(notificacion));
				
				j=j+1;
			}
			
		}
		// Se acabo el servicio para este cliente
		// cerrar la conexion con el servidor MYSQL 
		
		
	}
	
	close(sock_conn); 
	
}


int main(int argc, char *argv[])
{
	
	int sock_conn, sock_listen;
	struct sockaddr_in serv_adr;
	/*Rellenar(miTablaPartidas);*/
	Rellenar(miTablaPartidas);
	
	
	
	
	// INICIALITZACIONS
	// Obrim el socket
	if ((sock_listen = socket(AF_INET, SOCK_STREAM, 0)) < 0)
		printf("Error creant socket");
	// Fem el bind al port
	
	
	memset(&serv_adr, 0, sizeof(serv_adr));// inicialitza a zero serv_addr
	serv_adr.sin_family = AF_INET;
	
	// asocia el socket a cualquiera de las IP de la m?quina. 
	//htonl formatea el numero que recibe al formato necesario
	serv_adr.sin_addr.s_addr = htonl(INADDR_ANY);
	// establecemos el puerto de escucha
	serv_adr.sin_port = htons(50069);
	if (bind(sock_listen, (struct sockaddr *) &serv_adr, sizeof(serv_adr)) < 0)
		printf ("Error al bind");
	
	if (listen(sock_listen, 3) < 0)
		printf("Error en el Listen");
	
	contador=0;
	int i=0;
	int sockets[100];
	pthread_t thread[100];
	// Bucle infinito
	for (;;){
		printf ("Escuchando\n");
		
		sock_conn = accept(sock_listen, NULL, NULL);
		printf ("He recibido conexion\n");
		//sock_conn es el socket que usaremos para este cliente
		sockets[i]=sock_conn;
		
		pthread_create(&thread[i],NULL,AtenderCliente,&sockets[i]);
		i=i+1;
		
	}
	/*	mysql_close (conn);*/
	exit(0);
}


