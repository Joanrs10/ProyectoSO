﻿DROP DATABASE IF EXISTS Juego;
CREATE DATABASE Juego;
USE Juego;
CREATE TABLE Jugador (
  id INTEGER NOT NULL,
  username TEXT NOT NULL,
  password TEXT NOT NULL,
  Partidasganadas INTEGER NOT NULL,
  Partidasperdidas INTEGER NOT NULL,
  PRIMARY KEY (id)
)ENGINE = InnoDB;

CREATE TABLE Partida (
  id INTEGER NOT NULL,
  Nombreganador TEXT NOT NULL,
  Duracion INTEGER NOT NULL,
  Fecha TEXT NOT NULL,
  PRIMARY KEY (id)
)ENGINE = InnoDB;

CREATE TABLE Relacion (
  Id_jugador INTEGER, 
  Id_partida INTEGER,
  Puntos INTEGER NOT NULL,
  FOREIGN KEY (Id_jugador) REFERENCES Jugador(id),
  FOREIGN KEY (Id_partida) REFERENCES Partida(id)
  )ENGINE = InnoDB;

INSERT INTO Jugador(id, username, password, PartidasGanadas, PartidasPerdidas) VALUES(1,'Arnau','hola',3,0);
INSERT INTO Jugador(id, username, password, PartidasGanadas, PartidasPerdidas) VALUES(2,'Joan','hola',0,4);
INSERT INTO Jugador(id, username, password, PartidasGanadas, PartidasPerdidas) VALUES(3,'Alex','hola',1,0);

INSERT INTO Partida(id, Nombreganador, Duracion, Fecha) VALUES(1,'Arnau', 60, '2/10');
INSERT INTO Partida(id, Nombreganador, Duracion, Fecha) VALUES(2,'Arnau', 50, '2/10');
INSERT INTO Partida(id, Nombreganador, Duracion, Fecha) VALUES(3,'Alex', 40, '2/10');
INSERT INTO Partida(id, Nombreganador, Duracion, Fecha) VALUES(4,'Arnau', 30, '2/10');

INSERT INTO Relacion(Id_jugador, Id_partida, Puntos) VALUES(1, 1 , 20);
INSERT INTO Relacion(Id_jugador, Id_partida, Puntos) VALUES(2, 1 , 15);
INSERT INTO Relacion(Id_jugador, Id_partida, Puntos) VALUES(1, 2 , 30);
INSERT INTO Relacion(Id_jugador, Id_partida, Puntos) VALUES(2, 2 , 15);
INSERT INTO Relacion(Id_jugador, Id_partida, Puntos) VALUES(3, 3 , 50);
INSERT INTO Relacion(Id_jugador, Id_partida, Puntos) VALUES(2, 3 , 5);
INSERT INTO Relacion(Id_jugador, Id_partida, Puntos) VALUES(1, 4 , 45);
INSERT INTO Relacion(Id_jugador, Id_partida, Puntos) VALUES(2, 4 , 40);
