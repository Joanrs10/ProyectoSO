﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panelfunciones = new System.Windows.Forms.Panel();
            this.Checkf4 = new System.Windows.Forms.CheckBox();
            this.Checkf3 = new System.Windows.Forms.CheckBox();
            this.Checkf2 = new System.Windows.Forms.CheckBox();
            this.Consultbutton = new System.Windows.Forms.Button();
            this.Checkf1 = new System.Windows.Forms.CheckBox();
            this.ListaConectados = new System.Windows.Forms.DataGridView();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button41 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.labelganadas = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.MasFichas = new System.Windows.Forms.Button();
            this.tiempoLbl = new System.Windows.Forms.Label();
            this.labelfichas = new System.Windows.Forms.Label();
            this.FichasDisponibles = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.NumAnt = new System.Windows.Forms.Label();
            this.Numero = new System.Windows.Forms.Label();
            this.apuesta0 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.apuesta33 = new System.Windows.Forms.Label();
            this.apuesta36 = new System.Windows.Forms.Label();
            this.apuesta25 = new System.Windows.Forms.Label();
            this.apuesta28 = new System.Windows.Forms.Label();
            this.apuesta31 = new System.Windows.Forms.Label();
            this.apuesta34 = new System.Windows.Forms.Label();
            this.apuesta22 = new System.Windows.Forms.Label();
            this.apuesta23 = new System.Windows.Forms.Label();
            this.apuesta26 = new System.Windows.Forms.Label();
            this.apuesta29 = new System.Windows.Forms.Label();
            this.apuesta32 = new System.Windows.Forms.Label();
            this.apuesta35 = new System.Windows.Forms.Label();
            this.apuesta20 = new System.Windows.Forms.Label();
            this.apuesta18 = new System.Windows.Forms.Label();
            this.apuesta21 = new System.Windows.Forms.Label();
            this.apuesta24 = new System.Windows.Forms.Label();
            this.apuesta27 = new System.Windows.Forms.Label();
            this.apuesta30 = new System.Windows.Forms.Label();
            this.apuesta3 = new System.Windows.Forms.Label();
            this.apuesta4 = new System.Windows.Forms.Label();
            this.apuesta5 = new System.Windows.Forms.Label();
            this.apuesta6 = new System.Windows.Forms.Label();
            this.apuesta7 = new System.Windows.Forms.Label();
            this.apuesta8 = new System.Windows.Forms.Label();
            this.apuesta9 = new System.Windows.Forms.Label();
            this.apuesta10 = new System.Windows.Forms.Label();
            this.apuesta11 = new System.Windows.Forms.Label();
            this.apuesta12 = new System.Windows.Forms.Label();
            this.apuesta15 = new System.Windows.Forms.Label();
            this.apuesta13 = new System.Windows.Forms.Label();
            this.apuesta14 = new System.Windows.Forms.Label();
            this.apuesta16 = new System.Windows.Forms.Label();
            this.apuesta17 = new System.Windows.Forms.Label();
            this.apuesta19 = new System.Windows.Forms.Label();
            this.apuesta2 = new System.Windows.Forms.Label();
            this.apuesta1 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.Apuesta123 = new System.Windows.Forms.Label();
            this.Apuestotal = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button49 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label_Chat = new System.Windows.Forms.Label();
            this.Apostar = new System.Windows.Forms.TextBox();
            this.button0 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.Invitar = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.Connectbutton = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Passwordtext = new System.Windows.Forms.TextBox();
            this.Loginbutton = new System.Windows.Forms.Button();
            this.Usertext = new System.Windows.Forms.TextBox();
            this.Disconectbutton = new System.Windows.Forms.Button();
            this.panelfunciones.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ListaConectados)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panelfunciones
            // 
            this.panelfunciones.Controls.Add(this.Checkf4);
            this.panelfunciones.Controls.Add(this.Checkf3);
            this.panelfunciones.Controls.Add(this.Checkf2);
            this.panelfunciones.Controls.Add(this.Consultbutton);
            this.panelfunciones.Controls.Add(this.Checkf1);
            this.panelfunciones.Location = new System.Drawing.Point(24, 228);
            this.panelfunciones.Name = "panelfunciones";
            this.panelfunciones.Size = new System.Drawing.Size(493, 231);
            this.panelfunciones.TabIndex = 7;
            // 
            // Checkf4
            // 
            this.Checkf4.AutoSize = true;
            this.Checkf4.Location = new System.Drawing.Point(62, 44);
            this.Checkf4.Name = "Checkf4";
            this.Checkf4.Size = new System.Drawing.Size(164, 17);
            this.Checkf4.TabIndex = 5;
            this.Checkf4.Text = "Cuantas partidas he perdido?";
            this.Checkf4.UseVisualStyleBackColor = true;
            // 
            // Checkf3
            // 
            this.Checkf3.AutoSize = true;
            this.Checkf3.Location = new System.Drawing.Point(62, 109);
            this.Checkf3.Name = "Checkf3";
            this.Checkf3.Size = new System.Drawing.Size(158, 17);
            this.Checkf3.TabIndex = 4;
            this.Checkf3.Text = "Último usuario en registrarse";
            this.Checkf3.UseVisualStyleBackColor = true;
            // 
            // Checkf2
            // 
            this.Checkf2.AutoSize = true;
            this.Checkf2.Location = new System.Drawing.Point(62, 74);
            this.Checkf2.Name = "Checkf2";
            this.Checkf2.Size = new System.Drawing.Size(126, 17);
            this.Checkf2.TabIndex = 2;
            this.Checkf2.Text = "Recordar contraseña";
            this.Checkf2.UseVisualStyleBackColor = true;
            // 
            // Consultbutton
            // 
            this.Consultbutton.Location = new System.Drawing.Point(62, 145);
            this.Consultbutton.Name = "Consultbutton";
            this.Consultbutton.Size = new System.Drawing.Size(75, 23);
            this.Consultbutton.TabIndex = 1;
            this.Consultbutton.Text = "Consultar";
            this.Consultbutton.UseVisualStyleBackColor = true;
            this.Consultbutton.Click += new System.EventHandler(this.Consultbutton_Click_1);
            // 
            // Checkf1
            // 
            this.Checkf1.AutoSize = true;
            this.Checkf1.Location = new System.Drawing.Point(62, 16);
            this.Checkf1.Name = "Checkf1";
            this.Checkf1.Size = new System.Drawing.Size(165, 17);
            this.Checkf1.TabIndex = 0;
            this.Checkf1.Text = "Cuantas partidas he ganado?";
            this.Checkf1.UseVisualStyleBackColor = true;
            // 
            // ListaConectados
            // 
            this.ListaConectados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ListaConectados.Location = new System.Drawing.Point(208, 45);
            this.ListaConectados.Name = "ListaConectados";
            this.ListaConectados.Size = new System.Drawing.Size(145, 150);
            this.ListaConectados.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(246, 29);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Lista Conectados";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Green;
            this.panel1.Controls.Add(this.button41);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.labelganadas);
            this.panel1.Controls.Add(this.label21);
            this.panel1.Controls.Add(this.MasFichas);
            this.panel1.Controls.Add(this.tiempoLbl);
            this.panel1.Controls.Add(this.labelfichas);
            this.panel1.Controls.Add(this.FichasDisponibles);
            this.panel1.Controls.Add(this.label20);
            this.panel1.Controls.Add(this.label19);
            this.panel1.Controls.Add(this.NumAnt);
            this.panel1.Controls.Add(this.Numero);
            this.panel1.Controls.Add(this.apuesta0);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.apuesta33);
            this.panel1.Controls.Add(this.apuesta36);
            this.panel1.Controls.Add(this.apuesta25);
            this.panel1.Controls.Add(this.apuesta28);
            this.panel1.Controls.Add(this.apuesta31);
            this.panel1.Controls.Add(this.apuesta34);
            this.panel1.Controls.Add(this.apuesta22);
            this.panel1.Controls.Add(this.apuesta23);
            this.panel1.Controls.Add(this.apuesta26);
            this.panel1.Controls.Add(this.apuesta29);
            this.panel1.Controls.Add(this.apuesta32);
            this.panel1.Controls.Add(this.apuesta35);
            this.panel1.Controls.Add(this.apuesta20);
            this.panel1.Controls.Add(this.apuesta18);
            this.panel1.Controls.Add(this.apuesta21);
            this.panel1.Controls.Add(this.apuesta24);
            this.panel1.Controls.Add(this.apuesta27);
            this.panel1.Controls.Add(this.apuesta30);
            this.panel1.Controls.Add(this.apuesta3);
            this.panel1.Controls.Add(this.apuesta4);
            this.panel1.Controls.Add(this.apuesta5);
            this.panel1.Controls.Add(this.apuesta6);
            this.panel1.Controls.Add(this.apuesta7);
            this.panel1.Controls.Add(this.apuesta8);
            this.panel1.Controls.Add(this.apuesta9);
            this.panel1.Controls.Add(this.apuesta10);
            this.panel1.Controls.Add(this.apuesta11);
            this.panel1.Controls.Add(this.apuesta12);
            this.panel1.Controls.Add(this.apuesta15);
            this.panel1.Controls.Add(this.apuesta13);
            this.panel1.Controls.Add(this.apuesta14);
            this.panel1.Controls.Add(this.apuesta16);
            this.panel1.Controls.Add(this.apuesta17);
            this.panel1.Controls.Add(this.apuesta19);
            this.panel1.Controls.Add(this.apuesta2);
            this.panel1.Controls.Add(this.apuesta1);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.label17);
            this.panel1.Controls.Add(this.label18);
            this.panel1.Controls.Add(this.Apuesta123);
            this.panel1.Controls.Add(this.Apuestotal);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.button49);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label_Chat);
            this.panel1.Controls.Add(this.Apostar);
            this.panel1.Controls.Add(this.button0);
            this.panel1.Controls.Add(this.button34);
            this.panel1.Controls.Add(this.button35);
            this.panel1.Controls.Add(this.button36);
            this.panel1.Controls.Add(this.button31);
            this.panel1.Controls.Add(this.button32);
            this.panel1.Controls.Add(this.button33);
            this.panel1.Controls.Add(this.button28);
            this.panel1.Controls.Add(this.button29);
            this.panel1.Controls.Add(this.button30);
            this.panel1.Controls.Add(this.button25);
            this.panel1.Controls.Add(this.button26);
            this.panel1.Controls.Add(this.button27);
            this.panel1.Controls.Add(this.button22);
            this.panel1.Controls.Add(this.button23);
            this.panel1.Controls.Add(this.button24);
            this.panel1.Controls.Add(this.button19);
            this.panel1.Controls.Add(this.button20);
            this.panel1.Controls.Add(this.button21);
            this.panel1.Controls.Add(this.button16);
            this.panel1.Controls.Add(this.button17);
            this.panel1.Controls.Add(this.button18);
            this.panel1.Controls.Add(this.button13);
            this.panel1.Controls.Add(this.button14);
            this.panel1.Controls.Add(this.button15);
            this.panel1.Controls.Add(this.button10);
            this.panel1.Controls.Add(this.button11);
            this.panel1.Controls.Add(this.button12);
            this.panel1.Controls.Add(this.button8);
            this.panel1.Controls.Add(this.button7);
            this.panel1.Controls.Add(this.button9);
            this.panel1.Controls.Add(this.button5);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.button6);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Location = new System.Drawing.Point(439, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1054, 585);
            this.panel1.TabIndex = 75;
            // 
            // button41
            // 
            this.button41.Location = new System.Drawing.Point(50, 216);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(127, 98);
            this.button41.TabIndex = 0;
            this.button41.Text = "Iniciar partida";
            this.button41.UseVisualStyleBackColor = true;
            this.button41.Click += new System.EventHandler(this.button41_Click);
            // 
            // panel2
            // 
            this.panel2.Location = new System.Drawing.Point(41, 540);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(41, 10);
            this.panel2.TabIndex = 205;
            // 
            // labelganadas
            // 
            this.labelganadas.AutoSize = true;
            this.labelganadas.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelganadas.Location = new System.Drawing.Point(148, 54);
            this.labelganadas.Name = "labelganadas";
            this.labelganadas.Size = new System.Drawing.Size(31, 13);
            this.labelganadas.TabIndex = 203;
            this.labelganadas.Text = "0000";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.ForeColor = System.Drawing.Color.White;
            this.label21.Location = new System.Drawing.Point(18, 54);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(85, 13);
            this.label21.TabIndex = 202;
            this.label21.Text = "Fichas ganadas:";
            // 
            // MasFichas
            // 
            this.MasFichas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.MasFichas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MasFichas.ForeColor = System.Drawing.Color.White;
            this.MasFichas.Location = new System.Drawing.Point(21, 81);
            this.MasFichas.Name = "MasFichas";
            this.MasFichas.Size = new System.Drawing.Size(95, 42);
            this.MasFichas.TabIndex = 200;
            this.MasFichas.Text = "Más fichas";
            this.MasFichas.UseVisualStyleBackColor = false;
            this.MasFichas.Click += new System.EventHandler(this.MasFichas_Click_1);
            // 
            // tiempoLbl
            // 
            this.tiempoLbl.AutoSize = true;
            this.tiempoLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 35F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tiempoLbl.ForeColor = System.Drawing.Color.White;
            this.tiempoLbl.Location = new System.Drawing.Point(32, 393);
            this.tiempoLbl.Name = "tiempoLbl";
            this.tiempoLbl.Size = new System.Drawing.Size(75, 54);
            this.tiempoLbl.TabIndex = 199;
            this.tiempoLbl.Text = "60";
            // 
            // labelfichas
            // 
            this.labelfichas.AutoSize = true;
            this.labelfichas.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelfichas.Location = new System.Drawing.Point(148, 28);
            this.labelfichas.Name = "labelfichas";
            this.labelfichas.Size = new System.Drawing.Size(31, 13);
            this.labelfichas.TabIndex = 78;
            this.labelfichas.Text = "0000";
            // 
            // FichasDisponibles
            // 
            this.FichasDisponibles.AutoSize = true;
            this.FichasDisponibles.ForeColor = System.Drawing.Color.White;
            this.FichasDisponibles.Location = new System.Drawing.Point(20, 28);
            this.FichasDisponibles.Name = "FichasDisponibles";
            this.FichasDisponibles.Size = new System.Drawing.Size(96, 13);
            this.FichasDisponibles.TabIndex = 198;
            this.FichasDisponibles.Text = "Fichas disponibles:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label20.ForeColor = System.Drawing.Color.White;
            this.label20.Location = new System.Drawing.Point(808, 66);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(47, 13);
            this.label20.TabIndex = 197;
            this.label20.Text = "Número:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(115, 507);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(84, 13);
            this.label19.TabIndex = 196;
            this.label19.Text = "Últimas jugadas:";
            // 
            // NumAnt
            // 
            this.NumAnt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NumAnt.ForeColor = System.Drawing.Color.White;
            this.NumAnt.Location = new System.Drawing.Point(246, 507);
            this.NumAnt.Name = "NumAnt";
            this.NumAnt.Size = new System.Drawing.Size(475, 20);
            this.NumAnt.TabIndex = 195;
            // 
            // Numero
            // 
            this.Numero.BackColor = System.Drawing.Color.Green;
            this.Numero.Font = new System.Drawing.Font("Microsoft Sans Serif", 85F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Numero.ForeColor = System.Drawing.Color.White;
            this.Numero.Location = new System.Drawing.Point(828, 167);
            this.Numero.Name = "Numero";
            this.Numero.Size = new System.Drawing.Size(192, 127);
            this.Numero.TabIndex = 193;
            this.Numero.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // apuesta0
            // 
            this.apuesta0.AutoSize = true;
            this.apuesta0.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.apuesta0.ForeColor = System.Drawing.Color.White;
            this.apuesta0.Location = new System.Drawing.Point(1012, 353);
            this.apuesta0.Name = "apuesta0";
            this.apuesta0.Size = new System.Drawing.Size(16, 17);
            this.apuesta0.TabIndex = 192;
            this.apuesta0.Text = "0";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(991, 353);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(20, 17);
            this.label14.TabIndex = 191;
            this.label14.Text = "0:";
            // 
            // apuesta33
            // 
            this.apuesta33.AutoSize = true;
            this.apuesta33.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.apuesta33.ForeColor = System.Drawing.Color.White;
            this.apuesta33.Location = new System.Drawing.Point(1012, 539);
            this.apuesta33.Name = "apuesta33";
            this.apuesta33.Size = new System.Drawing.Size(16, 17);
            this.apuesta33.TabIndex = 190;
            this.apuesta33.Text = "0";
            // 
            // apuesta36
            // 
            this.apuesta36.AutoSize = true;
            this.apuesta36.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.apuesta36.ForeColor = System.Drawing.Color.White;
            this.apuesta36.Location = new System.Drawing.Point(1012, 556);
            this.apuesta36.Name = "apuesta36";
            this.apuesta36.Size = new System.Drawing.Size(16, 17);
            this.apuesta36.TabIndex = 189;
            this.apuesta36.Text = "0";
            // 
            // apuesta25
            // 
            this.apuesta25.AutoSize = true;
            this.apuesta25.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.apuesta25.ForeColor = System.Drawing.Color.White;
            this.apuesta25.Location = new System.Drawing.Point(872, 507);
            this.apuesta25.Name = "apuesta25";
            this.apuesta25.Size = new System.Drawing.Size(16, 17);
            this.apuesta25.TabIndex = 188;
            this.apuesta25.Text = "0";
            // 
            // apuesta28
            // 
            this.apuesta28.AutoSize = true;
            this.apuesta28.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.apuesta28.ForeColor = System.Drawing.Color.White;
            this.apuesta28.Location = new System.Drawing.Point(872, 523);
            this.apuesta28.Name = "apuesta28";
            this.apuesta28.Size = new System.Drawing.Size(16, 17);
            this.apuesta28.TabIndex = 187;
            this.apuesta28.Text = "0";
            // 
            // apuesta31
            // 
            this.apuesta31.AutoSize = true;
            this.apuesta31.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.apuesta31.ForeColor = System.Drawing.Color.White;
            this.apuesta31.Location = new System.Drawing.Point(872, 540);
            this.apuesta31.Name = "apuesta31";
            this.apuesta31.Size = new System.Drawing.Size(16, 17);
            this.apuesta31.TabIndex = 186;
            this.apuesta31.Text = "0";
            // 
            // apuesta34
            // 
            this.apuesta34.AutoSize = true;
            this.apuesta34.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.apuesta34.ForeColor = System.Drawing.Color.White;
            this.apuesta34.Location = new System.Drawing.Point(872, 557);
            this.apuesta34.Name = "apuesta34";
            this.apuesta34.Size = new System.Drawing.Size(16, 17);
            this.apuesta34.TabIndex = 185;
            this.apuesta34.Text = "0";
            // 
            // apuesta22
            // 
            this.apuesta22.AutoSize = true;
            this.apuesta22.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.apuesta22.ForeColor = System.Drawing.Color.White;
            this.apuesta22.Location = new System.Drawing.Point(872, 489);
            this.apuesta22.Name = "apuesta22";
            this.apuesta22.Size = new System.Drawing.Size(16, 17);
            this.apuesta22.TabIndex = 184;
            this.apuesta22.Text = "0";
            // 
            // apuesta23
            // 
            this.apuesta23.AutoSize = true;
            this.apuesta23.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.apuesta23.ForeColor = System.Drawing.Color.White;
            this.apuesta23.Location = new System.Drawing.Point(939, 489);
            this.apuesta23.Name = "apuesta23";
            this.apuesta23.Size = new System.Drawing.Size(16, 17);
            this.apuesta23.TabIndex = 183;
            this.apuesta23.Text = "0";
            // 
            // apuesta26
            // 
            this.apuesta26.AutoSize = true;
            this.apuesta26.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.apuesta26.ForeColor = System.Drawing.Color.White;
            this.apuesta26.Location = new System.Drawing.Point(939, 505);
            this.apuesta26.Name = "apuesta26";
            this.apuesta26.Size = new System.Drawing.Size(16, 17);
            this.apuesta26.TabIndex = 182;
            this.apuesta26.Text = "0";
            // 
            // apuesta29
            // 
            this.apuesta29.AutoSize = true;
            this.apuesta29.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.apuesta29.ForeColor = System.Drawing.Color.White;
            this.apuesta29.Location = new System.Drawing.Point(939, 522);
            this.apuesta29.Name = "apuesta29";
            this.apuesta29.Size = new System.Drawing.Size(16, 17);
            this.apuesta29.TabIndex = 181;
            this.apuesta29.Text = "0";
            // 
            // apuesta32
            // 
            this.apuesta32.AutoSize = true;
            this.apuesta32.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.apuesta32.ForeColor = System.Drawing.Color.White;
            this.apuesta32.Location = new System.Drawing.Point(939, 539);
            this.apuesta32.Name = "apuesta32";
            this.apuesta32.Size = new System.Drawing.Size(16, 17);
            this.apuesta32.TabIndex = 180;
            this.apuesta32.Text = "0";
            // 
            // apuesta35
            // 
            this.apuesta35.AutoSize = true;
            this.apuesta35.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.apuesta35.ForeColor = System.Drawing.Color.White;
            this.apuesta35.Location = new System.Drawing.Point(939, 555);
            this.apuesta35.Name = "apuesta35";
            this.apuesta35.Size = new System.Drawing.Size(16, 17);
            this.apuesta35.TabIndex = 179;
            this.apuesta35.Text = "0";
            // 
            // apuesta20
            // 
            this.apuesta20.AutoSize = true;
            this.apuesta20.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.apuesta20.ForeColor = System.Drawing.Color.White;
            this.apuesta20.Location = new System.Drawing.Point(939, 471);
            this.apuesta20.Name = "apuesta20";
            this.apuesta20.Size = new System.Drawing.Size(16, 17);
            this.apuesta20.TabIndex = 178;
            this.apuesta20.Text = "0";
            // 
            // apuesta18
            // 
            this.apuesta18.AutoSize = true;
            this.apuesta18.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.apuesta18.ForeColor = System.Drawing.Color.White;
            this.apuesta18.Location = new System.Drawing.Point(1012, 454);
            this.apuesta18.Name = "apuesta18";
            this.apuesta18.Size = new System.Drawing.Size(16, 17);
            this.apuesta18.TabIndex = 177;
            this.apuesta18.Text = "0";
            // 
            // apuesta21
            // 
            this.apuesta21.AutoSize = true;
            this.apuesta21.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.apuesta21.ForeColor = System.Drawing.Color.White;
            this.apuesta21.Location = new System.Drawing.Point(1012, 471);
            this.apuesta21.Name = "apuesta21";
            this.apuesta21.Size = new System.Drawing.Size(16, 17);
            this.apuesta21.TabIndex = 176;
            this.apuesta21.Text = "0";
            // 
            // apuesta24
            // 
            this.apuesta24.AutoSize = true;
            this.apuesta24.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.apuesta24.ForeColor = System.Drawing.Color.White;
            this.apuesta24.Location = new System.Drawing.Point(1012, 488);
            this.apuesta24.Name = "apuesta24";
            this.apuesta24.Size = new System.Drawing.Size(16, 17);
            this.apuesta24.TabIndex = 175;
            this.apuesta24.Text = "0";
            // 
            // apuesta27
            // 
            this.apuesta27.AutoSize = true;
            this.apuesta27.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.apuesta27.ForeColor = System.Drawing.Color.White;
            this.apuesta27.Location = new System.Drawing.Point(1012, 505);
            this.apuesta27.Name = "apuesta27";
            this.apuesta27.Size = new System.Drawing.Size(16, 17);
            this.apuesta27.TabIndex = 174;
            this.apuesta27.Text = "0";
            // 
            // apuesta30
            // 
            this.apuesta30.AutoSize = true;
            this.apuesta30.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.apuesta30.ForeColor = System.Drawing.Color.White;
            this.apuesta30.Location = new System.Drawing.Point(1012, 522);
            this.apuesta30.Name = "apuesta30";
            this.apuesta30.Size = new System.Drawing.Size(16, 17);
            this.apuesta30.TabIndex = 173;
            this.apuesta30.Text = "0";
            // 
            // apuesta3
            // 
            this.apuesta3.AutoSize = true;
            this.apuesta3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.apuesta3.ForeColor = System.Drawing.Color.White;
            this.apuesta3.Location = new System.Drawing.Point(1012, 370);
            this.apuesta3.Name = "apuesta3";
            this.apuesta3.Size = new System.Drawing.Size(16, 17);
            this.apuesta3.TabIndex = 172;
            this.apuesta3.Text = "0";
            // 
            // apuesta4
            // 
            this.apuesta4.AutoSize = true;
            this.apuesta4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.apuesta4.ForeColor = System.Drawing.Color.White;
            this.apuesta4.Location = new System.Drawing.Point(872, 388);
            this.apuesta4.Name = "apuesta4";
            this.apuesta4.Size = new System.Drawing.Size(16, 17);
            this.apuesta4.TabIndex = 171;
            this.apuesta4.Text = "0";
            // 
            // apuesta5
            // 
            this.apuesta5.AutoSize = true;
            this.apuesta5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.apuesta5.ForeColor = System.Drawing.Color.White;
            this.apuesta5.Location = new System.Drawing.Point(939, 388);
            this.apuesta5.Name = "apuesta5";
            this.apuesta5.Size = new System.Drawing.Size(16, 17);
            this.apuesta5.TabIndex = 170;
            this.apuesta5.Text = "0";
            // 
            // apuesta6
            // 
            this.apuesta6.AutoSize = true;
            this.apuesta6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.apuesta6.ForeColor = System.Drawing.Color.White;
            this.apuesta6.Location = new System.Drawing.Point(1012, 387);
            this.apuesta6.Name = "apuesta6";
            this.apuesta6.Size = new System.Drawing.Size(16, 17);
            this.apuesta6.TabIndex = 169;
            this.apuesta6.Text = "0";
            // 
            // apuesta7
            // 
            this.apuesta7.AutoSize = true;
            this.apuesta7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.apuesta7.ForeColor = System.Drawing.Color.White;
            this.apuesta7.Location = new System.Drawing.Point(872, 404);
            this.apuesta7.Name = "apuesta7";
            this.apuesta7.Size = new System.Drawing.Size(16, 17);
            this.apuesta7.TabIndex = 168;
            this.apuesta7.Text = "0";
            // 
            // apuesta8
            // 
            this.apuesta8.AutoSize = true;
            this.apuesta8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.apuesta8.ForeColor = System.Drawing.Color.White;
            this.apuesta8.Location = new System.Drawing.Point(939, 404);
            this.apuesta8.Name = "apuesta8";
            this.apuesta8.Size = new System.Drawing.Size(16, 17);
            this.apuesta8.TabIndex = 167;
            this.apuesta8.Text = "0";
            // 
            // apuesta9
            // 
            this.apuesta9.AutoSize = true;
            this.apuesta9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.apuesta9.ForeColor = System.Drawing.Color.White;
            this.apuesta9.Location = new System.Drawing.Point(1012, 404);
            this.apuesta9.Name = "apuesta9";
            this.apuesta9.Size = new System.Drawing.Size(16, 17);
            this.apuesta9.TabIndex = 166;
            this.apuesta9.Text = "0";
            // 
            // apuesta10
            // 
            this.apuesta10.AutoSize = true;
            this.apuesta10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.apuesta10.ForeColor = System.Drawing.Color.White;
            this.apuesta10.Location = new System.Drawing.Point(872, 421);
            this.apuesta10.Name = "apuesta10";
            this.apuesta10.Size = new System.Drawing.Size(16, 17);
            this.apuesta10.TabIndex = 165;
            this.apuesta10.Text = "0";
            // 
            // apuesta11
            // 
            this.apuesta11.AutoSize = true;
            this.apuesta11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.apuesta11.ForeColor = System.Drawing.Color.White;
            this.apuesta11.Location = new System.Drawing.Point(939, 421);
            this.apuesta11.Name = "apuesta11";
            this.apuesta11.Size = new System.Drawing.Size(16, 17);
            this.apuesta11.TabIndex = 164;
            this.apuesta11.Text = "0";
            // 
            // apuesta12
            // 
            this.apuesta12.AutoSize = true;
            this.apuesta12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.apuesta12.ForeColor = System.Drawing.Color.White;
            this.apuesta12.Location = new System.Drawing.Point(1012, 421);
            this.apuesta12.Name = "apuesta12";
            this.apuesta12.Size = new System.Drawing.Size(16, 17);
            this.apuesta12.TabIndex = 163;
            this.apuesta12.Text = "0";
            // 
            // apuesta15
            // 
            this.apuesta15.AutoSize = true;
            this.apuesta15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.apuesta15.ForeColor = System.Drawing.Color.White;
            this.apuesta15.Location = new System.Drawing.Point(1012, 438);
            this.apuesta15.Name = "apuesta15";
            this.apuesta15.Size = new System.Drawing.Size(16, 17);
            this.apuesta15.TabIndex = 162;
            this.apuesta15.Text = "0";
            // 
            // apuesta13
            // 
            this.apuesta13.AutoSize = true;
            this.apuesta13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.apuesta13.ForeColor = System.Drawing.Color.White;
            this.apuesta13.Location = new System.Drawing.Point(872, 438);
            this.apuesta13.Name = "apuesta13";
            this.apuesta13.Size = new System.Drawing.Size(16, 17);
            this.apuesta13.TabIndex = 161;
            this.apuesta13.Text = "0";
            // 
            // apuesta14
            // 
            this.apuesta14.AutoSize = true;
            this.apuesta14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.apuesta14.ForeColor = System.Drawing.Color.White;
            this.apuesta14.Location = new System.Drawing.Point(939, 438);
            this.apuesta14.Name = "apuesta14";
            this.apuesta14.Size = new System.Drawing.Size(16, 17);
            this.apuesta14.TabIndex = 160;
            this.apuesta14.Text = "0";
            // 
            // apuesta16
            // 
            this.apuesta16.AutoSize = true;
            this.apuesta16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.apuesta16.ForeColor = System.Drawing.Color.White;
            this.apuesta16.Location = new System.Drawing.Point(872, 454);
            this.apuesta16.Name = "apuesta16";
            this.apuesta16.Size = new System.Drawing.Size(16, 17);
            this.apuesta16.TabIndex = 159;
            this.apuesta16.Text = "0";
            // 
            // apuesta17
            // 
            this.apuesta17.AutoSize = true;
            this.apuesta17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.apuesta17.ForeColor = System.Drawing.Color.White;
            this.apuesta17.Location = new System.Drawing.Point(939, 454);
            this.apuesta17.Name = "apuesta17";
            this.apuesta17.Size = new System.Drawing.Size(16, 17);
            this.apuesta17.TabIndex = 158;
            this.apuesta17.Text = "0";
            // 
            // apuesta19
            // 
            this.apuesta19.AutoSize = true;
            this.apuesta19.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.apuesta19.ForeColor = System.Drawing.Color.White;
            this.apuesta19.Location = new System.Drawing.Point(872, 471);
            this.apuesta19.Name = "apuesta19";
            this.apuesta19.Size = new System.Drawing.Size(16, 17);
            this.apuesta19.TabIndex = 157;
            this.apuesta19.Text = "0";
            // 
            // apuesta2
            // 
            this.apuesta2.AutoSize = true;
            this.apuesta2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.apuesta2.ForeColor = System.Drawing.Color.White;
            this.apuesta2.Location = new System.Drawing.Point(939, 370);
            this.apuesta2.Name = "apuesta2";
            this.apuesta2.Size = new System.Drawing.Size(16, 17);
            this.apuesta2.TabIndex = 156;
            this.apuesta2.Text = "0";
            // 
            // apuesta1
            // 
            this.apuesta1.AutoSize = true;
            this.apuesta1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.apuesta1.ForeColor = System.Drawing.Color.White;
            this.apuesta1.Location = new System.Drawing.Point(872, 370);
            this.apuesta1.Name = "apuesta1";
            this.apuesta1.Size = new System.Drawing.Size(16, 17);
            this.apuesta1.TabIndex = 155;
            this.apuesta1.Text = "0";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(847, 556);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(168, 17);
            this.label13.TabIndex = 154;
            this.label13.Text = "34:            35:             36:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(847, 387);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(164, 17);
            this.label12.TabIndex = 153;
            this.label12.Text = "4:               5:               6:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(847, 404);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(164, 17);
            this.label11.TabIndex = 152;
            this.label11.Text = "7:               8:               9:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(847, 421);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(168, 17);
            this.label10.TabIndex = 151;
            this.label10.Text = "10:            11:             12:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(847, 438);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(168, 17);
            this.label9.TabIndex = 150;
            this.label9.Text = "13:            14:             15:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(847, 454);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(168, 17);
            this.label8.TabIndex = 149;
            this.label8.Text = "16:            17:             18:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(847, 471);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(168, 17);
            this.label7.TabIndex = 148;
            this.label7.Text = "19:            20:             21:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(847, 488);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(168, 17);
            this.label15.TabIndex = 147;
            this.label15.Text = "22:            23:             24:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(847, 505);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(168, 17);
            this.label16.TabIndex = 146;
            this.label16.Text = "25:            26:             27:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(847, 522);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(168, 17);
            this.label17.TabIndex = 145;
            this.label17.Text = "28:            29:             30:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(847, 539);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(168, 17);
            this.label18.TabIndex = 144;
            this.label18.Text = "31:            32:             33:";
            // 
            // Apuesta123
            // 
            this.Apuesta123.AutoSize = true;
            this.Apuesta123.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Apuesta123.ForeColor = System.Drawing.Color.White;
            this.Apuesta123.Location = new System.Drawing.Point(847, 370);
            this.Apuesta123.Name = "Apuesta123";
            this.Apuesta123.Size = new System.Drawing.Size(164, 17);
            this.Apuesta123.TabIndex = 143;
            this.Apuesta123.Text = "1:               2:               3:";
            // 
            // Apuestotal
            // 
            this.Apuestotal.AutoSize = true;
            this.Apuestotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.Apuestotal.ForeColor = System.Drawing.Color.White;
            this.Apuestotal.Location = new System.Drawing.Point(807, 338);
            this.Apuestotal.Name = "Apuestotal";
            this.Apuestotal.Size = new System.Drawing.Size(81, 13);
            this.Apuestotal.TabIndex = 142;
            this.Apuestotal.Text = "Apuesta actual:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(403, 28);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(373, 277);
            this.pictureBox1.TabIndex = 139;
            this.pictureBox1.TabStop = false;
            // 
            // button49
            // 
            this.button49.Location = new System.Drawing.Point(219, 244);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(128, 23);
            this.button49.TabIndex = 138;
            this.button49.Text = "Enviar mensaje";
            this.button49.UseVisualStyleBackColor = true;
            this.button49.Click += new System.EventHandler(this.button49_Click_1);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.SystemColors.Control;
            this.label6.Location = new System.Drawing.Point(208, 178);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(84, 13);
            this.label6.TabIndex = 137;
            this.label6.Text = "Escribe mensaje";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(211, 204);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(166, 20);
            this.textBox1.TabIndex = 136;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Snow;
            this.label5.Location = new System.Drawing.Point(148, 71);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 13);
            this.label5.TabIndex = 135;
            this.label5.Text = "Chat";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(331, 302);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 13);
            this.label4.TabIndex = 134;
            this.label4.Text = "Apuesta";
            // 
            // label_Chat
            // 
            this.label_Chat.BackColor = System.Drawing.Color.White;
            this.label_Chat.Location = new System.Drawing.Point(208, 28);
            this.label_Chat.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_Chat.Name = "label_Chat";
            this.label_Chat.Size = new System.Drawing.Size(169, 128);
            this.label_Chat.TabIndex = 133;
            this.label_Chat.Text = "Chat con compañeros de partida";
            // 
            // Apostar
            // 
            this.Apostar.Location = new System.Drawing.Point(325, 328);
            this.Apostar.Name = "Apostar";
            this.Apostar.Size = new System.Drawing.Size(100, 20);
            this.Apostar.TabIndex = 112;
            // 
            // button0
            // 
            this.button0.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button0.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button0.ForeColor = System.Drawing.Color.White;
            this.button0.Location = new System.Drawing.Point(266, 366);
            this.button0.Name = "button0";
            this.button0.Size = new System.Drawing.Size(42, 120);
            this.button0.TabIndex = 111;
            this.button0.Text = "0";
            this.button0.UseVisualStyleBackColor = false;
            this.button0.Click += new System.EventHandler(this.button0_Click_1);
            // 
            // button34
            // 
            this.button34.BackColor = System.Drawing.Color.Red;
            this.button34.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button34.ForeColor = System.Drawing.Color.White;
            this.button34.Location = new System.Drawing.Point(734, 444);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(42, 42);
            this.button34.TabIndex = 110;
            this.button34.Text = "34";
            this.button34.UseVisualStyleBackColor = false;
            this.button34.Click += new System.EventHandler(this.button34_Click_1);
            // 
            // button35
            // 
            this.button35.BackColor = System.Drawing.Color.Black;
            this.button35.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button35.ForeColor = System.Drawing.Color.White;
            this.button35.Location = new System.Drawing.Point(734, 405);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(42, 42);
            this.button35.TabIndex = 109;
            this.button35.Text = "35";
            this.button35.UseVisualStyleBackColor = false;
            this.button35.Click += new System.EventHandler(this.button35_Click_1);
            // 
            // button36
            // 
            this.button36.BackColor = System.Drawing.Color.Red;
            this.button36.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button36.ForeColor = System.Drawing.Color.White;
            this.button36.Location = new System.Drawing.Point(734, 366);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(42, 42);
            this.button36.TabIndex = 108;
            this.button36.Text = "36";
            this.button36.UseVisualStyleBackColor = false;
            this.button36.Click += new System.EventHandler(this.button36_Click_1);
            // 
            // button31
            // 
            this.button31.BackColor = System.Drawing.Color.Black;
            this.button31.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button31.ForeColor = System.Drawing.Color.White;
            this.button31.Location = new System.Drawing.Point(695, 444);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(42, 42);
            this.button31.TabIndex = 107;
            this.button31.Text = "31";
            this.button31.UseVisualStyleBackColor = false;
            this.button31.Click += new System.EventHandler(this.button31_Click_1);
            // 
            // button32
            // 
            this.button32.BackColor = System.Drawing.Color.Red;
            this.button32.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button32.ForeColor = System.Drawing.Color.White;
            this.button32.Location = new System.Drawing.Point(695, 405);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(42, 42);
            this.button32.TabIndex = 106;
            this.button32.Text = "32";
            this.button32.UseVisualStyleBackColor = false;
            this.button32.Click += new System.EventHandler(this.button32_Click_1);
            // 
            // button33
            // 
            this.button33.BackColor = System.Drawing.Color.Black;
            this.button33.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button33.ForeColor = System.Drawing.Color.White;
            this.button33.Location = new System.Drawing.Point(695, 366);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(42, 42);
            this.button33.TabIndex = 105;
            this.button33.Text = "33";
            this.button33.UseVisualStyleBackColor = false;
            this.button33.Click += new System.EventHandler(this.button33_Click_1);
            // 
            // button28
            // 
            this.button28.BackColor = System.Drawing.Color.Black;
            this.button28.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button28.ForeColor = System.Drawing.Color.White;
            this.button28.Location = new System.Drawing.Point(656, 444);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(42, 42);
            this.button28.TabIndex = 104;
            this.button28.Text = "28";
            this.button28.UseVisualStyleBackColor = false;
            this.button28.Click += new System.EventHandler(this.button28_Click_1);
            // 
            // button29
            // 
            this.button29.BackColor = System.Drawing.Color.Black;
            this.button29.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button29.ForeColor = System.Drawing.Color.White;
            this.button29.Location = new System.Drawing.Point(656, 405);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(42, 42);
            this.button29.TabIndex = 103;
            this.button29.Text = "29";
            this.button29.UseVisualStyleBackColor = false;
            this.button29.Click += new System.EventHandler(this.button29_Click_1);
            // 
            // button30
            // 
            this.button30.BackColor = System.Drawing.Color.Red;
            this.button30.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button30.ForeColor = System.Drawing.Color.White;
            this.button30.Location = new System.Drawing.Point(656, 366);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(42, 42);
            this.button30.TabIndex = 102;
            this.button30.Text = "30";
            this.button30.UseVisualStyleBackColor = false;
            this.button30.Click += new System.EventHandler(this.button30_Click_1);
            // 
            // button25
            // 
            this.button25.BackColor = System.Drawing.Color.Red;
            this.button25.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button25.ForeColor = System.Drawing.Color.White;
            this.button25.Location = new System.Drawing.Point(617, 444);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(42, 42);
            this.button25.TabIndex = 101;
            this.button25.Text = "25";
            this.button25.UseVisualStyleBackColor = false;
            this.button25.Click += new System.EventHandler(this.button25_Click_1);
            // 
            // button26
            // 
            this.button26.BackColor = System.Drawing.Color.Black;
            this.button26.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button26.ForeColor = System.Drawing.Color.White;
            this.button26.Location = new System.Drawing.Point(617, 405);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(42, 42);
            this.button26.TabIndex = 100;
            this.button26.Text = "26";
            this.button26.UseVisualStyleBackColor = false;
            this.button26.Click += new System.EventHandler(this.button26_Click_1);
            // 
            // button27
            // 
            this.button27.BackColor = System.Drawing.Color.Red;
            this.button27.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button27.ForeColor = System.Drawing.Color.White;
            this.button27.Location = new System.Drawing.Point(617, 366);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(42, 42);
            this.button27.TabIndex = 99;
            this.button27.Text = "27";
            this.button27.UseVisualStyleBackColor = false;
            this.button27.Click += new System.EventHandler(this.button27_Click_1);
            // 
            // button22
            // 
            this.button22.BackColor = System.Drawing.Color.Black;
            this.button22.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button22.ForeColor = System.Drawing.Color.White;
            this.button22.Location = new System.Drawing.Point(578, 444);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(42, 42);
            this.button22.TabIndex = 98;
            this.button22.Text = "22";
            this.button22.UseVisualStyleBackColor = false;
            this.button22.Click += new System.EventHandler(this.button22_Click_1);
            // 
            // button23
            // 
            this.button23.BackColor = System.Drawing.Color.Red;
            this.button23.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button23.ForeColor = System.Drawing.Color.White;
            this.button23.Location = new System.Drawing.Point(578, 405);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(42, 42);
            this.button23.TabIndex = 97;
            this.button23.Text = "23";
            this.button23.UseVisualStyleBackColor = false;
            this.button23.Click += new System.EventHandler(this.button23_Click_1);
            // 
            // button24
            // 
            this.button24.BackColor = System.Drawing.Color.Black;
            this.button24.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button24.ForeColor = System.Drawing.Color.White;
            this.button24.Location = new System.Drawing.Point(578, 366);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(42, 42);
            this.button24.TabIndex = 96;
            this.button24.Text = "24";
            this.button24.UseVisualStyleBackColor = false;
            this.button24.Click += new System.EventHandler(this.button24_Click_1);
            // 
            // button19
            // 
            this.button19.BackColor = System.Drawing.Color.Red;
            this.button19.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button19.ForeColor = System.Drawing.Color.White;
            this.button19.Location = new System.Drawing.Point(539, 444);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(42, 42);
            this.button19.TabIndex = 95;
            this.button19.Text = "19";
            this.button19.UseVisualStyleBackColor = false;
            this.button19.Click += new System.EventHandler(this.button19_Click_1);
            // 
            // button20
            // 
            this.button20.BackColor = System.Drawing.Color.Black;
            this.button20.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button20.ForeColor = System.Drawing.Color.White;
            this.button20.Location = new System.Drawing.Point(539, 405);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(42, 42);
            this.button20.TabIndex = 94;
            this.button20.Text = "20";
            this.button20.UseVisualStyleBackColor = false;
            this.button20.Click += new System.EventHandler(this.button20_Click_1);
            // 
            // button21
            // 
            this.button21.BackColor = System.Drawing.Color.Red;
            this.button21.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button21.ForeColor = System.Drawing.Color.White;
            this.button21.Location = new System.Drawing.Point(539, 366);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(42, 42);
            this.button21.TabIndex = 93;
            this.button21.Text = "21";
            this.button21.UseVisualStyleBackColor = false;
            this.button21.Click += new System.EventHandler(this.button21_Click_1);
            // 
            // button16
            // 
            this.button16.BackColor = System.Drawing.Color.Red;
            this.button16.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button16.ForeColor = System.Drawing.Color.White;
            this.button16.Location = new System.Drawing.Point(500, 444);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(42, 42);
            this.button16.TabIndex = 92;
            this.button16.Text = "16";
            this.button16.UseVisualStyleBackColor = false;
            this.button16.Click += new System.EventHandler(this.button16_Click_1);
            // 
            // button17
            // 
            this.button17.BackColor = System.Drawing.Color.Black;
            this.button17.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button17.ForeColor = System.Drawing.Color.White;
            this.button17.Location = new System.Drawing.Point(500, 405);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(42, 42);
            this.button17.TabIndex = 91;
            this.button17.Text = "17";
            this.button17.UseVisualStyleBackColor = false;
            this.button17.Click += new System.EventHandler(this.button17_Click_1);
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.Color.Red;
            this.button18.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button18.ForeColor = System.Drawing.Color.White;
            this.button18.Location = new System.Drawing.Point(500, 366);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(42, 42);
            this.button18.TabIndex = 90;
            this.button18.Text = "18";
            this.button18.UseVisualStyleBackColor = false;
            this.button18.Click += new System.EventHandler(this.button18_Click_1);
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.Black;
            this.button13.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button13.ForeColor = System.Drawing.Color.White;
            this.button13.Location = new System.Drawing.Point(461, 444);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(42, 42);
            this.button13.TabIndex = 89;
            this.button13.Text = "13";
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.button13_Click_1);
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.Red;
            this.button14.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14.ForeColor = System.Drawing.Color.White;
            this.button14.Location = new System.Drawing.Point(461, 405);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(42, 42);
            this.button14.TabIndex = 88;
            this.button14.Text = "14";
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.button14_Click_1);
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.Color.Black;
            this.button15.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button15.ForeColor = System.Drawing.Color.White;
            this.button15.Location = new System.Drawing.Point(461, 366);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(42, 42);
            this.button15.TabIndex = 87;
            this.button15.Text = "15";
            this.button15.UseVisualStyleBackColor = false;
            this.button15.Click += new System.EventHandler(this.button15_Click_1);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.Black;
            this.button10.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.ForeColor = System.Drawing.Color.White;
            this.button10.Location = new System.Drawing.Point(422, 444);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(42, 42);
            this.button10.TabIndex = 86;
            this.button10.Text = "10";
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.button10_Click_1);
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.Black;
            this.button11.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button11.ForeColor = System.Drawing.Color.White;
            this.button11.Location = new System.Drawing.Point(422, 405);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(42, 42);
            this.button11.TabIndex = 85;
            this.button11.Text = "11";
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.button11_Click_1);
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.Red;
            this.button12.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button12.ForeColor = System.Drawing.Color.White;
            this.button12.Location = new System.Drawing.Point(422, 366);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(42, 42);
            this.button12.TabIndex = 84;
            this.button12.Text = "12";
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Click += new System.EventHandler(this.button12_Click_1);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.Black;
            this.button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.Color.White;
            this.button8.Location = new System.Drawing.Point(383, 405);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(42, 42);
            this.button8.TabIndex = 83;
            this.button8.Text = "8";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click_1);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.Red;
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.Color.White;
            this.button7.Location = new System.Drawing.Point(383, 444);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(42, 42);
            this.button7.TabIndex = 82;
            this.button7.Text = "7";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click_1);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.Red;
            this.button9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.ForeColor = System.Drawing.Color.White;
            this.button9.Location = new System.Drawing.Point(383, 366);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(42, 42);
            this.button9.TabIndex = 81;
            this.button9.Text = "9";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click_1);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Red;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.Location = new System.Drawing.Point(344, 405);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(42, 42);
            this.button5.TabIndex = 80;
            this.button5.Text = "5";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Black;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(344, 444);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(42, 42);
            this.button4.TabIndex = 79;
            this.button4.Text = "4";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.Black;
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.White;
            this.button6.Location = new System.Drawing.Point(344, 366);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(42, 42);
            this.button6.TabIndex = 78;
            this.button6.Text = "6";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click_1);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Black;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(305, 405);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(42, 42);
            this.button2.TabIndex = 77;
            this.button2.Text = "2";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Red;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(305, 444);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(42, 42);
            this.button1.TabIndex = 76;
            this.button1.Text = "1";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Red;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(305, 366);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(42, 42);
            this.button3.TabIndex = 75;
            this.button3.Text = "3";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // Invitar
            // 
            this.Invitar.Location = new System.Drawing.Point(250, 201);
            this.Invitar.Name = "Invitar";
            this.Invitar.Size = new System.Drawing.Size(75, 23);
            this.Invitar.TabIndex = 77;
            this.Invitar.Text = "Invitar";
            this.Invitar.UseVisualStyleBackColor = true;
            this.Invitar.Click += new System.EventHandler(this.Invitar_Click_1);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Connectbutton
            // 
            this.Connectbutton.Location = new System.Drawing.Point(8, 70);
            this.Connectbutton.Name = "Connectbutton";
            this.Connectbutton.Size = new System.Drawing.Size(75, 23);
            this.Connectbutton.TabIndex = 91;
            this.Connectbutton.Text = "Conecta";
            this.Connectbutton.UseVisualStyleBackColor = true;
            this.Connectbutton.Click += new System.EventHandler(this.Connectbutton_Click_1);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(110, 75);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 13);
            this.label2.TabIndex = 90;
            this.label2.Text = "Contraseña";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(129, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 13);
            this.label1.TabIndex = 89;
            this.label1.Text = "Usuario";
            // 
            // Passwordtext
            // 
            this.Passwordtext.Location = new System.Drawing.Point(98, 91);
            this.Passwordtext.Name = "Passwordtext";
            this.Passwordtext.Size = new System.Drawing.Size(100, 20);
            this.Passwordtext.TabIndex = 88;
            this.Passwordtext.TextChanged += new System.EventHandler(this.Passwordtext_TextChanged);
            // 
            // Loginbutton
            // 
            this.Loginbutton.Location = new System.Drawing.Point(106, 113);
            this.Loginbutton.Name = "Loginbutton";
            this.Loginbutton.Size = new System.Drawing.Size(75, 23);
            this.Loginbutton.TabIndex = 87;
            this.Loginbutton.Text = "Login";
            this.Loginbutton.UseVisualStyleBackColor = true;
            this.Loginbutton.Click += new System.EventHandler(this.Loginbutton_Click);
            // 
            // Usertext
            // 
            this.Usertext.Location = new System.Drawing.Point(98, 38);
            this.Usertext.Name = "Usertext";
            this.Usertext.Size = new System.Drawing.Size(100, 20);
            this.Usertext.TabIndex = 86;
            // 
            // Disconectbutton
            // 
            this.Disconectbutton.Location = new System.Drawing.Point(8, 99);
            this.Disconectbutton.Name = "Disconectbutton";
            this.Disconectbutton.Size = new System.Drawing.Size(75, 23);
            this.Disconectbutton.TabIndex = 85;
            this.Disconectbutton.Text = "Desconectar";
            this.Disconectbutton.UseVisualStyleBackColor = true;
            this.Disconectbutton.Click += new System.EventHandler(this.Disconectbutton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(1493, 601);
            this.Controls.Add(this.Connectbutton);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Passwordtext);
            this.Controls.Add(this.Loginbutton);
            this.Controls.Add(this.Usertext);
            this.Controls.Add(this.Disconectbutton);
            this.Controls.Add(this.Invitar);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panelfunciones);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.ListaConectados);
            this.Name = "Form1";
            this.Text = "Juego version 1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panelfunciones.ResumeLayout(false);
            this.panelfunciones.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ListaConectados)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panelfunciones;
        private System.Windows.Forms.Button Consultbutton;
        private System.Windows.Forms.CheckBox Checkf1;
        private System.Windows.Forms.CheckBox Checkf2;
        private System.Windows.Forms.DataGridView ListaConectados;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button0;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox Apostar;
        private System.Windows.Forms.Button Invitar;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label_Chat;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label apuesta0;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label apuesta33;
        private System.Windows.Forms.Label apuesta36;
        private System.Windows.Forms.Label apuesta25;
        private System.Windows.Forms.Label apuesta28;
        private System.Windows.Forms.Label apuesta31;
        private System.Windows.Forms.Label apuesta34;
        private System.Windows.Forms.Label apuesta22;
        private System.Windows.Forms.Label apuesta23;
        private System.Windows.Forms.Label apuesta26;
        private System.Windows.Forms.Label apuesta29;
        private System.Windows.Forms.Label apuesta32;
        private System.Windows.Forms.Label apuesta35;
        private System.Windows.Forms.Label apuesta20;
        private System.Windows.Forms.Label apuesta18;
        private System.Windows.Forms.Label apuesta21;
        private System.Windows.Forms.Label apuesta24;
        private System.Windows.Forms.Label apuesta27;
        private System.Windows.Forms.Label apuesta30;
        private System.Windows.Forms.Label apuesta3;
        private System.Windows.Forms.Label apuesta4;
        private System.Windows.Forms.Label apuesta5;
        private System.Windows.Forms.Label apuesta6;
        private System.Windows.Forms.Label apuesta7;
        private System.Windows.Forms.Label apuesta8;
        private System.Windows.Forms.Label apuesta9;
        private System.Windows.Forms.Label apuesta10;
        private System.Windows.Forms.Label apuesta11;
        private System.Windows.Forms.Label apuesta12;
        private System.Windows.Forms.Label apuesta15;
        private System.Windows.Forms.Label apuesta13;
        private System.Windows.Forms.Label apuesta14;
        private System.Windows.Forms.Label apuesta16;
        private System.Windows.Forms.Label apuesta17;
        private System.Windows.Forms.Label apuesta19;
        private System.Windows.Forms.Label apuesta2;
        private System.Windows.Forms.Label apuesta1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label Apuesta123;
        private System.Windows.Forms.Label Apuestotal;
        private System.Windows.Forms.Label Numero;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label NumAnt;
        private System.Windows.Forms.Label FichasDisponibles;
        private System.Windows.Forms.Label labelfichas;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label tiempoLbl;
        private System.Windows.Forms.Button MasFichas;
        private System.Windows.Forms.Button Connectbutton;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Passwordtext;
        private System.Windows.Forms.Button Loginbutton;
        private System.Windows.Forms.TextBox Usertext;
        private System.Windows.Forms.Button Disconectbutton;
        private System.Windows.Forms.CheckBox Checkf3;
        private System.Windows.Forms.Label labelganadas;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.CheckBox Checkf4;
    }
}

