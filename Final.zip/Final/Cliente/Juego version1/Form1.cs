﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Media;
using System.Text.RegularExpressions;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        Socket server;
        Thread atender;
        int miPartida;
        int durada;
        int conexion;
        string ganador;
        string valor;
        delegate void DelegadoParaEscribir(string text);
        delegate void DelegadoGrid(string[] trozos);
        delegate void DelegadoGridBorrar();
        delegate void DelegadoPanel();
        delegate void DelegadoFichas(decimal fichas);
        string v = "";
        decimal c0 = 0m;
        decimal c1 = 0m;
        decimal c2 = 0m;
        decimal c3 = 0m;
        decimal c4 = 0m;
        decimal c5 = 0m;
        decimal c6 = 0m;
        decimal c7 = 0m;
        decimal c8 = 0m;
        decimal c9 = 0m;
        decimal c10 = 0m;
        decimal c11 = 0m;
        decimal c12 = 0m;
        decimal c13 = 0m;
        decimal c14 = 0m;
        decimal c15 = 0m;
        decimal c16 = 0m;
        decimal c17 = 0m;
        decimal c18 = 0m;
        decimal c19 = 0m;
        decimal c20 = 0m;
        decimal c21 = 0m;
        decimal c22 = 0m;
        decimal c23 = 0m;
        decimal c24 = 0m;
        decimal c25 = 0m;
        decimal c26 = 0m;
        decimal c27 = 0m;
        decimal c28 = 0m;
        decimal c29 = 0m;
        decimal c30 = 0m;
        decimal c31 = 0m;
        decimal c32 = 0m;
        decimal c33 = 0m;
        decimal c34 = 0m;
        decimal c35 = 0m;
        decimal c36 = 0m;
        decimal total = 0m;
        decimal inicial;
        decimal fichas;
        decimal apuesta;
        decimal puntuacion;
        decimal ini;
        decimal gan;
        

        string fila;
        string case9;

        int conteo = 60;

        public Form1()
        {
            InitializeComponent();
        }

       

        private void AtenderServidor() //Recibe mensaje del servidor, saca el numero de codigo y genera la respuesta adiente
        {
            
            while (true)
            {
                //Recibimos mensaje del servidor
                byte[] msg2 = new byte[512];
                server.Receive(msg2);
                string[] trozos = Encoding.ASCII.GetString(msg2).Split('|');
                int codigo = Convert.ToInt32(trozos[0]);
                string mensaje = trozos[1].Split('\0')[0];

                switch (codigo)
                {
                    
                    case 00: //Desconexion, cierra la conexion con el servidor
                        MessageBox.Show("Te has desconnectado correctamente");
                        server.Shutdown(SocketShutdown.Both);
                        server.Close();
   
                        break;
    
                    case 1: //respuesta consulta 1, genera mensaje con la respuesta

                        MessageBox.Show("Tus partidas ganadas son: \n" + mensaje);
                        break;
                    case 11: //respuesta consulta 2, genera mensaje con la respuesta

                        MessageBox.Show("Tus partidas perdidas son: \n" + mensaje);
                        break;
                    case 2: //respuesta consulta 3, genera mensaje con la respuesta
                        MessageBox.Show("Tu contraseña es: \n" + mensaje);

                        break;
                    case 3: //respuesta consulta 4, genera mensaje con la respuesta
                        MessageBox.Show("El último jugador en registrarse al sistema es: \n" + mensaje);
                        break;

                    
                    case 4: //respuesta de inicio de sesion, nos informa si se ha iniciado sesion correctamente

                        if (mensaje == "SI")
                        {
                            MessageBox.Show("Se ha iniciado sesión correctamente");
                            panelfunciones.Invoke(new DelegadoPanel(ActivarPanel));
                            panel1.Invoke(new DelegadoPanel(ActivarPanelRuleta));
                            
                            inicial = Convert.ToInt32(labelfichas.Text);
                            tiempoLbl.Text = Convert.ToString(conteo);

                        }
                        else if (mensaje == "INC")
                            MessageBox.Show("Contrasenya incorrecta");
                        else
                            MessageBox.Show("Error al iniciar sesión");
                        break;
                    case 5: //respuesta registro, nos informa si un usuario se ha registrado correctamente

                        if (mensaje == "SI")
                            MessageBox.Show("Se ha registrado correctamente");
                        else if (mensaje == "EXIS")
                            MessageBox.Show("Ya existe un usuario con ese nombre");

                        else
                            MessageBox.Show("Error al registrarse");
                        break;
                   

                    case 6: //notificacion conectados, introduce en el data grid de lista conectados los usuarios conectados

                        string[] res = mensaje.Split('/');
                        ListaConectados.Invoke(new DelegadoGrid(ActualizarGrid), new object[] { res });
                        break;

                    case 8: //invitacion (resuelto con boton iniciar partida)
                        string[] res8 = mensaje.Split('/');
                        DialogResult result = MessageBox.Show(Usertext.Text + ": " + res8[0] + " le ha invitado a Jugar, desea aceptar la partida?", "Aceptar?", MessageBoxButtons.YesNo);
                        miPartida = Convert.ToInt32(res8[1]);
                        if (result == DialogResult.Yes)
                        {
                            mensaje = "9/SI|" + miPartida + "|";
                            // Enviamos al servidor el nombre tecleado
                            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                            server.Send(msg);
                        }
                        else
                        {
                            mensaje = "9/NO|" + miPartida + "|";
                            // Enviamos al servidor el nombre tecleado
                            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                            server.Send(msg);

                        }
                        break;

                    case 9: //recibimos que hay o no hay partida (resuelto con boton iniciar partida)
                        string[] res9 = mensaje.Split('/');
                        if (res9[0] == "SI")
                        {
                            MessageBox.Show("Se ha iniciado la partida");
                            durada = 0;
                            miPartida = Convert.ToInt32(res9[1]);
                            //conteo = 45;
                        }
                        else
                        {
                            //string[] res9 = mensaje.Split('/');
                            int s = 0;

                            while (s < res9.Length)
                            {
                                case9 = case9 + ", " + res9[s];
                                s = s + 1;
                            }
                            MessageBox.Show("No se ha podido inciar la partida; los siguientes usuarios no han aceptado: " + case9);
                        }
                        break;

                    case 10: //recibimos frase del chat
                        label_Chat.Invoke(new DelegadoParaEscribir(EscribirChat), new object[] { mensaje });
                        break;

                    case 20:
                        panel2.Invoke(new DelegadoPanel(ActivarPanelExtra));
                        break;



                    case 12: //recibimos premio y lo introducimos 
                        decimal ganadas = 0m;
                        int x = Convert.ToInt32(mensaje);
                        string y = Convert.ToString(x);

                        EscribirNumero(mensaje);
                        EscribirNumAnt(mensaje);

                        if (x == 1 | x == 3 | x == 5 | x == 7 | x == 9 | x == 12 | x == 14 | x == 16 | x == 18 | x == 19 | x == 21 | x == 23 | x == 25 | x == 27 | x == 30 | x == 32 | x == 34 | x == 36)
                            this.Numero.ForeColor = System.Drawing.Color.FromArgb(255, 0, 0);
                        else if (x == 2 | x == 4 | x == 6 | x == 8 | x == 10 | x == 11 | x == 13 | x == 15 | x == 17 | x == 20 | x == 22 | x == 24 | x == 26 | x == 28 | x == 29 | x == 31 | x == 33 | x == 35)
                            this.Numero.ForeColor = System.Drawing.Color.FromArgb(0, 0, 0);
                        else
                            this.Numero.ForeColor = System.Drawing.Color.FromArgb(0, 192, 0);
                        if (x == 0)
                            fichas = fichas + c0 * 36;
                        else if (x == 1)
                            fichas = fichas + c1 * 36;
                        else if (x == 2)
                            fichas = fichas + c2 * 36;
                        else if (x == 3)
                            fichas = fichas + c3 * 36;
                        else if (x == 4)
                            fichas = fichas + c4 * 36;
                        else if (x == 5)
                            fichas = fichas + c5 * 36;
                        else if (x == 6)
                            fichas = fichas + c6 * 36;
                        else if (x == 7)
                            fichas = fichas + c7 * 36;
                        else if (x == 8)
                            fichas = fichas + c8 * 36;
                        else if (x == 9)
                            fichas = fichas + c9 * 36;
                        else if (x == 10)
                            fichas = fichas + c10 * 36;
                        else if (x == 11)
                            fichas = fichas + c11 * 36;
                        else if (x == 12)
                            fichas = fichas + c12 * 36;
                        else if (x == 13)
                            fichas = fichas + c13 * 36;
                        else if (x == 14)
                            fichas = fichas + c14 * 36;
                        else if (x == 15)
                            fichas = fichas + c15 * 36;
                        else if (x == 16)
                            fichas = fichas + c16 * 36;
                        else if (x == 17)
                            fichas = fichas + c17 * 36;
                        else if (x == 18)
                            fichas = fichas + c18 * 36;
                        else if (x == 19)
                            fichas = fichas + c19 * 36;
                        else if (x == 20)
                            fichas = fichas + c20 * 36;
                        else if (x == 21)
                            fichas = fichas + c21 * 36;
                        else if (x == 22)
                            fichas = fichas + c22 * 36;
                        else if (x == 23)
                            fichas = fichas + c23 * 36;
                        else if (x == 24)
                            fichas = fichas + c24 * 36;
                        else if (x == 25)
                            fichas = fichas + c25 * 36;
                        else if (x == 26)
                            fichas = fichas + c26 * 36;
                        else if (x == 27)
                            fichas = fichas + c27 * 36;
                        else if (x == 28)
                            fichas = fichas + c28 * 36;
                        else if (x == 29)
                            fichas = fichas + c29 * 36;
                        else if (x == 30)
                            fichas = fichas + c30 * 36;
                        else if (x == 31)
                            fichas = fichas + c31 * 36;
                        else if (x == 32)
                            fichas = fichas + c32 * 36;
                        else if (x == 33)
                            fichas = fichas + c33 * 36;
                        else if (x == 34)
                            fichas = fichas + c34 * 36;
                        else if (x == 35)
                            fichas = fichas + c35 * 36;
                        else if (x == 36)
                            fichas = fichas + c36 * 36;
                        if (total > 0)
                        {
                            ganadas = fichas - apuesta - inicial;
                            puntuacion = puntuacion + ganadas;
                            ini = Math.Round(fichas, 2);
                            gan = Math.Round(ganadas, 2);
                            inicial = fichas;
                        }

                        
                        IntroducirGanadas(ini, gan);
                        
  


                        if (total > 0)
                        {
                            mensaje = "14/" + miPartida + "/" + Usertext.Text + "/" + Convert.ToInt32(puntuacion);
                            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                            server.Send(msg);
                        }

                        c0 = 0;
                        c1 = 0;
                        c2 = 0;
                        c3 = 0;
                        c4 = 0;
                        c5 = 0;
                        c6 = 0;
                        c7 = 0;
                        c8 = 0;
                        c9 = 0;
                        c10 = 0;
                        c11 = 0;
                        c12 = 0;
                        c13 = 0;
                        c14 = 0;
                        c15 = 0;
                        c16 = 0;
                        c17 = 0;
                        c18 = 0;
                        c19 = 0;
                        c20 = 0;
                        c21 = 0;
                        c22 = 0;
                        c23 = 0;
                        c24 = 0;
                        c25 = 0;
                        c26 = 0;
                        c27 = 0;
                        c28 = 0;
                        c29 = 0;
                        c30 = 0;
                        c31 = 0;
                        c32 = 0;
                        c33 = 0;
                        c34 = 0;
                        c35 = 0;
                        c36 = 0;
                        break;

                }
            }
        }





        private void button0_Click_1(object sender, EventArgs e) //apuesta numero 0
        {
            if (Apostar.Text == "")
                MessageBox.Show("Introduzca la cantidad que quiere apostar");
            else
            {
                string compare = Apostar.Text;

                Regex regex = new Regex(@"^\d+$");

                if (regex.IsMatch(compare))
                {
                    decimal c = Convert.ToDecimal(Apostar.Text);
                    c0 = c0 + c;
                    if (c0 <= Convert.ToInt32(labelfichas.Text))
                    {
                        apuesta0.Text = Convert.ToString(c0);
                        total = c0 + c1 + c2 + c3 + c4 + c5 + c6 + c7 + c8 + c9 + c10 + c11 + c12 + c13 + c14 + c15 + c16 + c17 + c18 + c19 + c20 + c21 + c22 + c23 + c24 + c25 + c26 + c27 + c28 + c29 + c30 + c31 + c32 + c33 + c34 + c35 + c36;
                        fichas = inicial - total;

                        labelfichas.Text = Convert.ToString(Math.Round(fichas, 2));
                    }
                    else
                    {
                        MessageBox.Show("No tienes suficientes fichas");
                    }
                }
                else
                {
                    MessageBox.Show("Introduzca solo numero");
                }
            }
        }

        private void button1_Click_1(object sender, EventArgs e) //apuesta numero 1
        {
            if (Apostar.Text == "")
                MessageBox.Show("Introduzca la cantidad que quiere apostar");
            else
            {
                string compare = Apostar.Text;

                Regex regex = new Regex(@"^\d+$");

                if (regex.IsMatch(compare))
                {
                    decimal c = Convert.ToDecimal(Apostar.Text);
                    c1 = c1 + c;
                    if (c1 <= Convert.ToInt32(labelfichas.Text))
                    {
                        apuesta1.Text = Convert.ToString(c1);
                        total = c0 + c1 + c2 + c3 + c4 + c5 + c6 + c7 + c8 + c9 + c10 + c11 + c12 + c13 + c14 + c15 + c16 + c17 + c18 + c19 + c20 + c21 + c22 + c23 + c24 + c25 + c26 + c27 + c28 + c29 + c30 + c31 + c32 + c33 + c34 + c35 + c36;
                        fichas = inicial - total;

                        labelfichas.Text = Convert.ToString(Math.Round(fichas, 2));
                    }
                    else
                    {
                        MessageBox.Show("No tienes suficientes fichas");
                    }
                }
                else
                {
                    MessageBox.Show("Introduzca solo numero");
                }
            }
        }

        private void button2_Click_1(object sender, EventArgs e) //apuesta numero 2
        {
            if (Apostar.Text == "")
                MessageBox.Show("Introduzca la cantidad que quiere apostar");
            else
            {
                string compare = Apostar.Text;

                Regex regex = new Regex(@"^\d+$");

                if (regex.IsMatch(compare))
                {
                    decimal c = Convert.ToDecimal(Apostar.Text);
                    c2 = c2 + c;
                    if (c2 <= Convert.ToInt32(labelfichas.Text))
                    {
                        apuesta2.Text = Convert.ToString(c2);
                        total = c0 + c1 + c2 + c3 + c4 + c5 + c6 + c7 + c8 + c9 + c10 + c11 + c12 + c13 + c14 + c15 + c16 + c17 + c18 + c19 + c20 + c21 + c22 + c23 + c24 + c25 + c26 + c27 + c28 + c29 + c30 + c31 + c32 + c33 + c34 + c35 + c36;
                        fichas = inicial - total;

                        labelfichas.Text = Convert.ToString(Math.Round(fichas, 2));
                    }
                    else
                    {
                        MessageBox.Show("No tienes suficientes fichas");
                    }
                }
                else
                {
                    MessageBox.Show("Introduzca solo numero");
                }
            }
        }

        private void button3_Click_1(object sender, EventArgs e) //apuesta numero 3
        {
            if (Apostar.Text == "")
                MessageBox.Show("Introduzca la cantidad que quiere apostar");
            else
            {
                string compare = Apostar.Text;

                Regex regex = new Regex(@"^\d+$");

                if (regex.IsMatch(compare))
                {
                    decimal c = Convert.ToDecimal(Apostar.Text);
                    c3 = c3 + c;
                    if (c3 <= Convert.ToInt32(labelfichas.Text))
                    {
                        apuesta3.Text = Convert.ToString(c3);
                        total = c0 + c1 + c2 + c3 + c4 + c5 + c6 + c7 + c8 + c9 + c10 + c11 + c12 + c13 + c14 + c15 + c16 + c17 + c18 + c19 + c20 + c21 + c22 + c23 + c24 + c25 + c26 + c27 + c28 + c29 + c30 + c31 + c32 + c33 + c34 + c35 + c36;
                        fichas = inicial - total;

                        labelfichas.Text = Convert.ToString(Math.Round(fichas, 2));
                    }
                    else
                    {
                        MessageBox.Show("No tienes suficientes fichas");
                    }
                }
                else
                {
                    MessageBox.Show("Introduzca solo numero");
                }
            }
        }

        private void button4_Click(object sender, EventArgs e) //apuesta numero 4
        {
            if (Apostar.Text == "")
                MessageBox.Show("Introduzca la cantidad que quiere apostar");
            else
            {
                string compare = Apostar.Text;

                Regex regex = new Regex(@"^\d+$");

                if (regex.IsMatch(compare))
                {
                    decimal c = Convert.ToDecimal(Apostar.Text);
                    c4 = c4 + c;
                    if (c4 <= Convert.ToInt32(labelfichas.Text))
                    {
                        apuesta4.Text = Convert.ToString(c4);
                        total = c0 + c1 + c2 + c3 + c4 + c5 + c6 + c7 + c8 + c9 + c10 + c11 + c12 + c13 + c14 + c15 + c16 + c17 + c18 + c19 + c20 + c21 + c22 + c23 + c24 + c25 + c26 + c27 + c28 + c29 + c30 + c31 + c32 + c33 + c34 + c35 + c36;
                        fichas = inicial - total;

                        labelfichas.Text = Convert.ToString(Math.Round(fichas, 2));
                    }
                    else
                    {
                        MessageBox.Show("No tienes suficientes fichas");
                    }
                }
                else
                {
                    MessageBox.Show("Introduzca solo numero");
                }
            }
        }

        private void button5_Click(object sender, EventArgs e) //apuesta numero 5
        {
            if (Apostar.Text == "")
                MessageBox.Show("Introduzca la cantidad que quiere apostar");
            else
            {
                string compare = Apostar.Text;

                Regex regex = new Regex(@"^\d+$");

                if (regex.IsMatch(compare))
                {
                    decimal c = Convert.ToDecimal(Apostar.Text);
                    c5 = c5 + c;
                    if (c5 <= Convert.ToInt32(labelfichas.Text))
                    {
                        apuesta5.Text = Convert.ToString(c5);
                        total = c0 + c1 + c2 + c3 + c4 + c5 + c6 + c7 + c8 + c9 + c10 + c11 + c12 + c13 + c14 + c15 + c16 + c17 + c18 + c19 + c20 + c21 + c22 + c23 + c24 + c25 + c26 + c27 + c28 + c29 + c30 + c31 + c32 + c33 + c34 + c35 + c36;
                        fichas = inicial - total;

                        labelfichas.Text = Convert.ToString(Math.Round(fichas, 2));
                    }
                    else
                    {
                        MessageBox.Show("No tienes suficientes fichas");
                    }
                }
                else
                {
                    MessageBox.Show("Introduzca solo numero");
                }
            }
        }

        private void button6_Click_1(object sender, EventArgs e) //apuesta numero 6
        {
            if (Apostar.Text == "")
                MessageBox.Show("Introduzca la cantidad que quiere apostar");
            else
            {
                string compare = Apostar.Text;

                Regex regex = new Regex(@"^\d+$");

                if (regex.IsMatch(compare))
                {
                    decimal c = Convert.ToDecimal(Apostar.Text);
                    c6 = c6 + c;
                    if (c6 <= Convert.ToInt32(labelfichas.Text))
                    {
                        apuesta6.Text = Convert.ToString(c6);
                        total = c0 + c1 + c2 + c3 + c4 + c5 + c6 + c7 + c8 + c9 + c10 + c11 + c12 + c13 + c14 + c15 + c16 + c17 + c18 + c19 + c20 + c21 + c22 + c23 + c24 + c25 + c26 + c27 + c28 + c29 + c30 + c31 + c32 + c33 + c34 + c35 + c36;
                        fichas = inicial - total;

                        labelfichas.Text = Convert.ToString(Math.Round(fichas, 2));
                    }
                    else
                    {
                        MessageBox.Show("No tienes suficientes fichas");
                    }
                }
                else
                {
                    MessageBox.Show("Introduzca solo numero");
                }
            }
        }

        private void button7_Click_1(object sender, EventArgs e) //apuesta numero 7
        {
            if (Apostar.Text == "")
                MessageBox.Show("Introduzca la cantidad que quiere apostar");
            else
            {
                string compare = Apostar.Text;

                Regex regex = new Regex(@"^\d+$");

                if (regex.IsMatch(compare))
                {
                    decimal c = Convert.ToDecimal(Apostar.Text);
                    c7 = c7 + c;
                    if (c7 <= Convert.ToInt32(labelfichas.Text))
                    {
                        apuesta7.Text = Convert.ToString(c7);
                        total = c0 + c1 + c2 + c3 + c4 + c5 + c6 + c7 + c8 + c9 + c10 + c11 + c12 + c13 + c14 + c15 + c16 + c17 + c18 + c19 + c20 + c21 + c22 + c23 + c24 + c25 + c26 + c27 + c28 + c29 + c30 + c31 + c32 + c33 + c34 + c35 + c36;
                        fichas = inicial - total;

                        labelfichas.Text = Convert.ToString(Math.Round(fichas, 2));
                    }
                    else
                    {
                        MessageBox.Show("No tienes suficientes fichas");
                    }
                }
                else
                {
                    MessageBox.Show("Introduzca solo numero");
                }
            }
        }

        private void button8_Click_1(object sender, EventArgs e) //apuesta numero 8
        {
            if (Apostar.Text == "")
                MessageBox.Show("Introduzca la cantidad que quiere apostar");
            else
            {
                string compare = Apostar.Text;

                Regex regex = new Regex(@"^\d+$");

                if (regex.IsMatch(compare))
                {
                    decimal c = Convert.ToDecimal(Apostar.Text);
                    c8 = c8 + c;
                    if (c8 <= Convert.ToInt32(labelfichas.Text))
                    {
                        apuesta8.Text = Convert.ToString(c8);
                        total = c0 + c1 + c2 + c3 + c4 + c5 + c6 + c7 + c8 + c9 + c10 + c11 + c12 + c13 + c14 + c15 + c16 + c17 + c18 + c19 + c20 + c21 + c22 + c23 + c24 + c25 + c26 + c27 + c28 + c29 + c30 + c31 + c32 + c33 + c34 + c35 + c36;
                        fichas = inicial - total;

                        labelfichas.Text = Convert.ToString(Math.Round(fichas, 2));
                    }
                    else
                    {
                        MessageBox.Show("No tienes suficientes fichas");
                    }
                }
                else
                {
                    MessageBox.Show("Introduzca solo numero");
                }
            }
        }

        private void button9_Click_1(object sender, EventArgs e) //apuesta numero 9
        {
            if (Apostar.Text == "")
                MessageBox.Show("Introduzca la cantidad que quiere apostar");
            else
            {
                string compare = Apostar.Text;

                Regex regex = new Regex(@"^\d+$");

                if (regex.IsMatch(compare))
                {
                    decimal c = Convert.ToDecimal(Apostar.Text);
                    c9 = c9 + c;
                    if (c9 <= Convert.ToInt32(labelfichas.Text))
                    {
                        apuesta9.Text = Convert.ToString(c9);
                        total = c0 + c1 + c2 + c3 + c4 + c5 + c6 + c7 + c8 + c9 + c10 + c11 + c12 + c13 + c14 + c15 + c16 + c17 + c18 + c19 + c20 + c21 + c22 + c23 + c24 + c25 + c26 + c27 + c28 + c29 + c30 + c31 + c32 + c33 + c34 + c35 + c36;
                        fichas = inicial - total;

                        labelfichas.Text = Convert.ToString(Math.Round(fichas, 2));
                    }
                    else
                    {
                        MessageBox.Show("No tienes suficientes fichas");
                    }
                }
                else
                {
                    MessageBox.Show("Introduzca solo numero");
                }
            }
        }

        private void button10_Click_1(object sender, EventArgs e) //apuesta numero 10
        {
            if (Apostar.Text == "")
                MessageBox.Show("Introduzca la cantidad que quiere apostar");
            else
            {
                string compare = Apostar.Text;

                Regex regex = new Regex(@"^\d+$");

                if (regex.IsMatch(compare))
                {
                    decimal c = Convert.ToDecimal(Apostar.Text);
                    c10 = c10 + c;
                    if (c10 <= Convert.ToInt32(labelfichas.Text))
                    {
                        apuesta10.Text = Convert.ToString(c10);
                        total = c0 + c1 + c2 + c3 + c4 + c5 + c6 + c7 + c8 + c9 + c10 + c11 + c12 + c13 + c14 + c15 + c16 + c17 + c18 + c19 + c20 + c21 + c22 + c23 + c24 + c25 + c26 + c27 + c28 + c29 + c30 + c31 + c32 + c33 + c34 + c35 + c36;
                        fichas = inicial - total;

                        labelfichas.Text = Convert.ToString(Math.Round(fichas, 2));
                    }
                    else
                    {
                        MessageBox.Show("No tienes suficientes fichas");
                    }
                }
                else
                {
                    MessageBox.Show("Introduzca solo numero");
                }
            }
        }

        private void button11_Click_1(object sender, EventArgs e) //apuesta numero 11
        {
            if (Apostar.Text == "")
                MessageBox.Show("Introduzca la cantidad que quiere apostar");
            else
            {
                string compare = Apostar.Text;

                Regex regex = new Regex(@"^\d+$");

                if (regex.IsMatch(compare))
                {
                    decimal c = Convert.ToDecimal(Apostar.Text);
                    c11 = c11 + c;
                    if (c11 <= Convert.ToInt32(labelfichas.Text))
                    {
                        apuesta11.Text = Convert.ToString(c11);
                        total = c0 + c1 + c2 + c3 + c4 + c5 + c6 + c7 + c8 + c9 + c10 + c11 + c12 + c13 + c14 + c15 + c16 + c17 + c18 + c19 + c20 + c21 + c22 + c23 + c24 + c25 + c26 + c27 + c28 + c29 + c30 + c31 + c32 + c33 + c34 + c35 + c36;
                        fichas = inicial - total;

                        labelfichas.Text = Convert.ToString(Math.Round(fichas, 2));
                    }
                    else
                    {
                        MessageBox.Show("No tienes suficientes fichas");
                    }
                }
                else
                {
                    MessageBox.Show("Introduzca solo numero");
                }
            }
        }

        private void button12_Click_1(object sender, EventArgs e) //apuesta numero 12
        {
            if (Apostar.Text == "")
                MessageBox.Show("Introduzca la cantidad que quiere apostar");
            else
            {
                string compare = Apostar.Text;

                Regex regex = new Regex(@"^\d+$");

                if (regex.IsMatch(compare))
                {
                    decimal c = Convert.ToDecimal(Apostar.Text);
                    c12 = c12 + c;
                    if (c12 <= Convert.ToInt32(labelfichas.Text))
                    {
                        apuesta12.Text = Convert.ToString(c12);
                        total = c0 + c1 + c2 + c3 + c4 + c5 + c6 + c7 + c8 + c9 + c10 + c11 + c12 + c13 + c14 + c15 + c16 + c17 + c18 + c19 + c20 + c21 + c22 + c23 + c24 + c25 + c26 + c27 + c28 + c29 + c30 + c31 + c32 + c33 + c34 + c35 + c36;
                        fichas = inicial - total;

                        labelfichas.Text = Convert.ToString(Math.Round(fichas, 2));
                    }
                    else
                    {
                        MessageBox.Show("No tienes suficientes fichas");
                    }
                }
                else
                {
                    MessageBox.Show("Introduzca solo numero");
                }
            }
            
        }

        private void button13_Click_1(object sender, EventArgs e) //apuesta numero 13
        {
            if (Apostar.Text == "")
                MessageBox.Show("Introduzca la cantidad que quiere apostar");
            else
            {
                string compare = Apostar.Text;

                Regex regex = new Regex(@"^\d+$");

                if (regex.IsMatch(compare))
                {
                    decimal c = Convert.ToDecimal(Apostar.Text);
                    c13 = c13 + c;
                    if (c13 <= Convert.ToInt32(labelfichas.Text))
                    {
                        apuesta13.Text = Convert.ToString(c13);
                        total = c0 + c1 + c2 + c3 + c4 + c5 + c6 + c7 + c8 + c9 + c10 + c11 + c12 + c13 + c14 + c15 + c16 + c17 + c18 + c19 + c20 + c21 + c22 + c23 + c24 + c25 + c26 + c27 + c28 + c29 + c30 + c31 + c32 + c33 + c34 + c35 + c36;
                        fichas = inicial - total;

                        labelfichas.Text = Convert.ToString(Math.Round(fichas, 2));
                    }
                    else
                    {
                        MessageBox.Show("No tienes suficientes fichas");
                    }
                }
                else
                {
                    MessageBox.Show("Introduzca solo numero");
                }
            }
        }

        private void button14_Click_1(object sender, EventArgs e) //apuesta numero 14
        {
            if (Apostar.Text == "")
                MessageBox.Show("Introduzca la cantidad que quiere apostar");
            else
            {
                string compare = Apostar.Text;

                Regex regex = new Regex(@"^\d+$");

                if (regex.IsMatch(compare))
                {
                    decimal c = Convert.ToDecimal(Apostar.Text);
                    c14 = c14 + c;
                    if (c14 <= Convert.ToInt32(labelfichas.Text))
                    {
                        apuesta14.Text = Convert.ToString(c14);
                        total = c0 + c1 + c2 + c3 + c4 + c5 + c6 + c7 + c8 + c9 + c10 + c11 + c12 + c13 + c14 + c15 + c16 + c17 + c18 + c19 + c20 + c21 + c22 + c23 + c24 + c25 + c26 + c27 + c28 + c29 + c30 + c31 + c32 + c33 + c34 + c35 + c36;
                        fichas = inicial - total;

                        labelfichas.Text = Convert.ToString(Math.Round(fichas, 2));
                    }
                    else
                    {
                        MessageBox.Show("No tienes suficientes fichas");
                    }
                }
                else
                {
                    MessageBox.Show("Introduzca solo numero");
                }
            }
        }

        private void button15_Click_1(object sender, EventArgs e) //apuesta numero 15
        {
            if (Apostar.Text == "")
                MessageBox.Show("Introduzca la cantidad que quiere apostar");
            else
            {
                string compare = Apostar.Text;

                Regex regex = new Regex(@"^\d+$");

                if (regex.IsMatch(compare))
                {
                    decimal c = Convert.ToDecimal(Apostar.Text);
                    c15 = c15 + c;
                    if (c15 <= Convert.ToInt32(labelfichas.Text))
                    {
                        apuesta15.Text = Convert.ToString(c15);
                        total = c0 + c1 + c2 + c3 + c4 + c5 + c6 + c7 + c8 + c9 + c10 + c11 + c12 + c13 + c14 + c15 + c16 + c17 + c18 + c19 + c20 + c21 + c22 + c23 + c24 + c25 + c26 + c27 + c28 + c29 + c30 + c31 + c32 + c33 + c34 + c35 + c36;
                        fichas = inicial - total;

                        labelfichas.Text = Convert.ToString(Math.Round(fichas, 2));
                    }
                    else
                    {
                        MessageBox.Show("No tienes suficientes fichas");
                    }
                }
                else
                {
                    MessageBox.Show("Introduzca solo numero");
                }
            }
        }

        private void button16_Click_1(object sender, EventArgs e) //apuesta numero 16
        {
            if (Apostar.Text == "")
                MessageBox.Show("Introduzca la cantidad que quiere apostar");
            else
            {
                string compare = Apostar.Text;

                Regex regex = new Regex(@"^\d+$");

                if (regex.IsMatch(compare))
                {
                    decimal c = Convert.ToDecimal(Apostar.Text);
                    c16 = c16 + c;
                    if (c16 <= Convert.ToInt32(labelfichas.Text))
                    {
                        apuesta16.Text = Convert.ToString(c16);
                        total = c0 + c1 + c2 + c3 + c4 + c5 + c6 + c7 + c8 + c9 + c10 + c11 + c12 + c13 + c14 + c15 + c16 + c17 + c18 + c19 + c20 + c21 + c22 + c23 + c24 + c25 + c26 + c27 + c28 + c29 + c30 + c31 + c32 + c33 + c34 + c35 + c36;
                        fichas = inicial - total;

                        labelfichas.Text = Convert.ToString(Math.Round(fichas, 2));
                    }
                    else
                    {
                        MessageBox.Show("No tienes suficientes fichas");
                    }
                }
                else
                {
                    MessageBox.Show("Introduzca solo numero");
                }
            }
        }

        private void button17_Click_1(object sender, EventArgs e) //apuesta numero 17
        {
            if (Apostar.Text == "")
                MessageBox.Show("Introduzca la cantidad que quiere apostar");
            else
            {
                string compare = Apostar.Text;

                Regex regex = new Regex(@"^\d+$");

                if (regex.IsMatch(compare))
                {
                    decimal c = Convert.ToDecimal(Apostar.Text);
                    c17 = c17 + c;
                    if (c17 <= Convert.ToInt32(labelfichas.Text))
                    {
                        apuesta17.Text = Convert.ToString(c17);
                        total = c0 + c1 + c2 + c3 + c4 + c5 + c6 + c7 + c8 + c9 + c10 + c11 + c12 + c13 + c14 + c15 + c16 + c17 + c18 + c19 + c20 + c21 + c22 + c23 + c24 + c25 + c26 + c27 + c28 + c29 + c30 + c31 + c32 + c33 + c34 + c35 + c36;
                        fichas = inicial - total;

                        labelfichas.Text = Convert.ToString(Math.Round(fichas, 2));
                    }
                    else
                    {
                        MessageBox.Show("No tienes suficientes fichas");
                    }
                }
                else
                {
                    MessageBox.Show("Introduzca solo numero");
                }
            }
        }

        private void button18_Click_1(object sender, EventArgs e) //apuesta numero 18
        {
            if (Apostar.Text == "")
                MessageBox.Show("Introduzca la cantidad que quiere apostar");
            else
            {
                string compare = Apostar.Text;

                Regex regex = new Regex(@"^\d+$");

                if (regex.IsMatch(compare))
                {
                    decimal c = Convert.ToDecimal(Apostar.Text);
                    c18 = c18 + c;
                    if (c18 <= Convert.ToInt32(labelfichas.Text))
                    {
                        apuesta18.Text = Convert.ToString(c18);
                        total = c0 + c1 + c2 + c3 + c4 + c5 + c6 + c7 + c8 + c9 + c10 + c11 + c12 + c13 + c14 + c15 + c16 + c17 + c18 + c19 + c20 + c21 + c22 + c23 + c24 + c25 + c26 + c27 + c28 + c29 + c30 + c31 + c32 + c33 + c34 + c35 + c36;
                        fichas = inicial - total;

                        labelfichas.Text = Convert.ToString(Math.Round(fichas, 2));
                    }
                    else
                    {
                        MessageBox.Show("No tienes suficientes fichas");
                    }
                }
                else
                {
                    MessageBox.Show("Introduzca solo numero");
                }
            }
        }

        private void button19_Click_1(object sender, EventArgs e) //apuesta numero 19
        {
            if (Apostar.Text == "")
                MessageBox.Show("Introduzca la cantidad que quiere apostar");
            else
            {
                string compare = Apostar.Text;

                Regex regex = new Regex(@"^\d+$");

                if (regex.IsMatch(compare))
                {
                    decimal c = Convert.ToDecimal(Apostar.Text);
                    c19 = c19 + c;
                    if (c19 <= Convert.ToInt32(labelfichas.Text))
                    {
                        apuesta19.Text = Convert.ToString(c19);
                        total = c0 + c1 + c2 + c3 + c4 + c5 + c6 + c7 + c8 + c9 + c10 + c11 + c12 + c13 + c14 + c15 + c16 + c17 + c18 + c19 + c20 + c21 + c22 + c23 + c24 + c25 + c26 + c27 + c28 + c29 + c30 + c31 + c32 + c33 + c34 + c35 + c36;
                        fichas = inicial - total;

                        labelfichas.Text = Convert.ToString(Math.Round(fichas, 2));
                    }
                    else
                    {
                        MessageBox.Show("No tienes suficientes fichas");
                    }
                }
                else
                {
                    MessageBox.Show("Introduzca solo numero");
                }
            }
        }

        private void button20_Click_1(object sender, EventArgs e) //apuesta numero 20
        {
            if (Apostar.Text == "")
                MessageBox.Show("Introduzca la cantidad que quiere apostar");
            else
            {
                string compare = Apostar.Text;

                Regex regex = new Regex(@"^\d+$");

                if (regex.IsMatch(compare))
                {
                    decimal c = Convert.ToDecimal(Apostar.Text);
                    c20 = c20 + c;
                    if (c20 <= Convert.ToInt32(labelfichas.Text))
                    {
                        apuesta20.Text = Convert.ToString(c20);
                        total = c0 + c1 + c2 + c3 + c4 + c5 + c6 + c7 + c8 + c9 + c10 + c11 + c12 + c13 + c14 + c15 + c16 + c17 + c18 + c19 + c20 + c21 + c22 + c23 + c24 + c25 + c26 + c27 + c28 + c29 + c30 + c31 + c32 + c33 + c34 + c35 + c36;
                        fichas = inicial - total;

                        labelfichas.Text = Convert.ToString(Math.Round(fichas, 2));
                    }
                    else
                    {
                        MessageBox.Show("No tienes suficientes fichas");
                    }
                }
                else
                {
                    MessageBox.Show("Introduzca solo numero");
                }
            }
        }

        private void button21_Click_1(object sender, EventArgs e) //apuesta numero 21
        {
            if (Apostar.Text == "")
                MessageBox.Show("Introduzca la cantidad que quiere apostar");
            else
            {
                string compare = Apostar.Text;

                Regex regex = new Regex(@"^\d+$");

                if (regex.IsMatch(compare))
                {
                    decimal c = Convert.ToDecimal(Apostar.Text);
                    c21 = c21 + c;
                    if (c21 <= Convert.ToInt32(labelfichas.Text))
                    {
                        apuesta21.Text = Convert.ToString(c21);
                        total = c0 + c1 + c2 + c3 + c4 + c5 + c6 + c7 + c8 + c9 + c10 + c11 + c12 + c13 + c14 + c15 + c16 + c17 + c18 + c19 + c20 + c21 + c22 + c23 + c24 + c25 + c26 + c27 + c28 + c29 + c30 + c31 + c32 + c33 + c34 + c35 + c36;
                        fichas = inicial - total;

                        labelfichas.Text = Convert.ToString(Math.Round(fichas, 2));
                    }
                    else
                    {
                        MessageBox.Show("No tienes suficientes fichas");
                    }
                }
                else
                {
                    MessageBox.Show("Introduzca solo numero");
                }
            }
        }

        private void button22_Click_1(object sender, EventArgs e) //apuesta numero 22
        {
            if (Apostar.Text == "")
                MessageBox.Show("Introduzca la cantidad que quiere apostar");
            else
            {
                string compare = Apostar.Text;

                Regex regex = new Regex(@"^\d+$");

                if (regex.IsMatch(compare))
                {
                    decimal c = Convert.ToDecimal(Apostar.Text);
                    c22 = c22 + c;
                    if (c22 <= Convert.ToInt32(labelfichas.Text))
                    {
                        apuesta22.Text = Convert.ToString(c22);
                        total = c0 + c1 + c2 + c3 + c4 + c5 + c6 + c7 + c8 + c9 + c10 + c11 + c12 + c13 + c14 + c15 + c16 + c17 + c18 + c19 + c20 + c21 + c22 + c23 + c24 + c25 + c26 + c27 + c28 + c29 + c30 + c31 + c32 + c33 + c34 + c35 + c36;
                        fichas = inicial - total;

                        labelfichas.Text = Convert.ToString(Math.Round(fichas, 2));
                    }
                    else
                    {
                        MessageBox.Show("No tienes suficientes fichas");
                    }
                }
                else
                {
                    MessageBox.Show("Introduzca solo numero");
                }
            }
        }

        private void button23_Click_1(object sender, EventArgs e) //apuesta numero 23
        {
            if (Apostar.Text == "")
                MessageBox.Show("Introduzca la cantidad que quiere apostar");
            else
            {
                string compare = Apostar.Text;

                Regex regex = new Regex(@"^\d+$");

                if (regex.IsMatch(compare))
                {
                    decimal c = Convert.ToDecimal(Apostar.Text);
                    c23 = c23 + c;
                    if (c23 <= Convert.ToInt32(labelfichas.Text))
                    {
                        apuesta23.Text = Convert.ToString(c23);
                        total = c0 + c1 + c2 + c3 + c4 + c5 + c6 + c7 + c8 + c9 + c10 + c11 + c12 + c13 + c14 + c15 + c16 + c17 + c18 + c19 + c20 + c21 + c22 + c23 + c24 + c25 + c26 + c27 + c28 + c29 + c30 + c31 + c32 + c33 + c34 + c35 + c36;
                        fichas = inicial - total;

                        labelfichas.Text = Convert.ToString(Math.Round(fichas, 2));
                    }
                    else
                    {
                        MessageBox.Show("No tienes suficientes fichas");
                    }
                }
                else
                {
                    MessageBox.Show("Introduzca solo numero");
                }
            }
        }

        private void button24_Click_1(object sender, EventArgs e) //apuesta numero 24
        {
            if (Apostar.Text == "")
                MessageBox.Show("Introduzca la cantidad que quiere apostar");
            else
            {
                string compare = Apostar.Text;

                Regex regex = new Regex(@"^\d+$");

                if (regex.IsMatch(compare))
                {
                    decimal c = Convert.ToDecimal(Apostar.Text);
                    c24 = c24 + c;
                    if (c24 <= Convert.ToInt32(labelfichas.Text))
                    {
                        apuesta24.Text = Convert.ToString(c24);
                        total = c0 + c1 + c2 + c3 + c4 + c5 + c6 + c7 + c8 + c9 + c10 + c11 + c12 + c13 + c14 + c15 + c16 + c17 + c18 + c19 + c20 + c21 + c22 + c23 + c24 + c25 + c26 + c27 + c28 + c29 + c30 + c31 + c32 + c33 + c34 + c35 + c36;
                        fichas = inicial - total;

                        labelfichas.Text = Convert.ToString(Math.Round(fichas, 2));
                    }
                    else
                    {
                        MessageBox.Show("No tienes suficientes fichas");
                    }
                }
                else
                {
                    MessageBox.Show("Introduzca solo numero");
                }
            }
        }

        private void button25_Click_1(object sender, EventArgs e) //apuesta numero 25
        {
            if (Apostar.Text == "")
                MessageBox.Show("Introduzca la cantidad que quiere apostar");
            else
            {
                string compare = Apostar.Text;

                Regex regex = new Regex(@"^\d+$");

                if (regex.IsMatch(compare))
                {
                    decimal c = Convert.ToDecimal(Apostar.Text);
                    c25 = c25 + c;
                    if (c25 <= Convert.ToInt32(labelfichas.Text))
                    {
                        apuesta25.Text = Convert.ToString(c25);
                        total = c0 + c1 + c2 + c3 + c4 + c5 + c6 + c7 + c8 + c9 + c10 + c11 + c12 + c13 + c14 + c15 + c16 + c17 + c18 + c19 + c20 + c21 + c22 + c23 + c24 + c25 + c26 + c27 + c28 + c29 + c30 + c31 + c32 + c33 + c34 + c35 + c36;
                        fichas = inicial - total;

                        labelfichas.Text = Convert.ToString(Math.Round(fichas, 2));
                    }
                    else
                    {
                        MessageBox.Show("No tienes suficientes fichas");
                    }
                }
                else
                {
                    MessageBox.Show("Introduzca solo numero");
                }
            }
        }

        private void button26_Click_1(object sender, EventArgs e) //apuesta numero 26
        {
            if (Apostar.Text == "")
                MessageBox.Show("Introduzca la cantidad que quiere apostar");
            else
            {
                string compare = Apostar.Text;

                Regex regex = new Regex(@"^\d+$");

                if (regex.IsMatch(compare))
                {
                    decimal c = Convert.ToDecimal(Apostar.Text);
                    c26 = c26 + c;
                    if (c26 <= Convert.ToInt32(labelfichas.Text))
                    {
                        apuesta26.Text = Convert.ToString(c26);
                        total = c0 + c1 + c2 + c3 + c4 + c5 + c6 + c7 + c8 + c9 + c10 + c11 + c12 + c13 + c14 + c15 + c16 + c17 + c18 + c19 + c20 + c21 + c22 + c23 + c24 + c25 + c26 + c27 + c28 + c29 + c30 + c31 + c32 + c33 + c34 + c35 + c36;
                        fichas = inicial - total;

                        labelfichas.Text = Convert.ToString(Math.Round(fichas, 2));
                    }
                    else
                    {
                        MessageBox.Show("No tienes suficientes fichas");
                    }
                }
                else
                {
                    MessageBox.Show("Introduzca solo numero");
                }
            }
        }

        private void button27_Click_1(object sender, EventArgs e) //apuesta numero 27
        {
            if (Apostar.Text == "")
                MessageBox.Show("Introduzca la cantidad que quiere apostar");
            else
            {
                string compare = Apostar.Text;

                Regex regex = new Regex(@"^\d+$");

                if (regex.IsMatch(compare))
                {
                    decimal c = Convert.ToDecimal(Apostar.Text);
                    c27 = c27 + c;
                    if (c27 <= Convert.ToInt32(labelfichas.Text))
                    {
                        apuesta27.Text = Convert.ToString(c27);
                        total = c0 + c1 + c2 + c3 + c4 + c5 + c6 + c7 + c8 + c9 + c10 + c11 + c12 + c13 + c14 + c15 + c16 + c17 + c18 + c19 + c20 + c21 + c22 + c23 + c24 + c25 + c26 + c27 + c28 + c29 + c30 + c31 + c32 + c33 + c34 + c35 + c36;
                        fichas = inicial - total;

                        labelfichas.Text = Convert.ToString(Math.Round(fichas, 2));
                    }
                    else
                    {
                        MessageBox.Show("No tienes suficientes fichas");
                    }
                }
                else
                {
                    MessageBox.Show("Introduzca solo numero");
                }
            }
        }

        private void button28_Click_1(object sender, EventArgs e) //apuesta numero 28
        {
            if (Apostar.Text == "")
                MessageBox.Show("Introduzca la cantidad que quiere apostar");
            else
            {
                string compare = Apostar.Text;

                Regex regex = new Regex(@"^\d+$");

                if (regex.IsMatch(compare))
                {
                    decimal c = Convert.ToDecimal(Apostar.Text);
                    c28 = c28 + c;
                    if (c28 <= Convert.ToInt32(labelfichas.Text))
                    {
                        apuesta28.Text = Convert.ToString(c28);
                        total = c0 + c1 + c2 + c3 + c4 + c5 + c6 + c7 + c8 + c9 + c10 + c11 + c12 + c13 + c14 + c15 + c16 + c17 + c18 + c19 + c20 + c21 + c22 + c23 + c24 + c25 + c26 + c27 + c28 + c29 + c30 + c31 + c32 + c33 + c34 + c35 + c36;
                        fichas = inicial - total;

                        labelfichas.Text = Convert.ToString(Math.Round(fichas, 2));
                    }
                    else
                    {
                        MessageBox.Show("No tienes suficientes fichas");
                    }
                }
                else
                {
                    MessageBox.Show("Introduzca solo numero");
                }
            }
        }

        private void button29_Click_1(object sender, EventArgs e) //apuesta numero 29
        {
            if (Apostar.Text == "")
                MessageBox.Show("Introduzca la cantidad que quiere apostar");
            else
            {
                string compare = Apostar.Text;

                Regex regex = new Regex(@"^\d+$");

                if (regex.IsMatch(compare))
                {
                    decimal c = Convert.ToDecimal(Apostar.Text);
                    c29 = c29 + c;
                    if (c29 <= Convert.ToInt32(labelfichas.Text))
                    {
                        apuesta29.Text = Convert.ToString(c29);
                        total = c0 + c1 + c2 + c3 + c4 + c5 + c6 + c7 + c8 + c9 + c10 + c11 + c12 + c13 + c14 + c15 + c16 + c17 + c18 + c19 + c20 + c21 + c22 + c23 + c24 + c25 + c26 + c27 + c28 + c29 + c30 + c31 + c32 + c33 + c34 + c35 + c36;
                        fichas = inicial - total;

                        labelfichas.Text = Convert.ToString(Math.Round(fichas, 2));
                    }
                    else
                    {
                        MessageBox.Show("No tienes suficientes fichas");
                    }
                }
                else
                {
                    MessageBox.Show("Introduzca solo numero");
                }
            
            }
        }

        private void button30_Click_1(object sender, EventArgs e) //apuesta numero 30
        {
            if (Apostar.Text == "")
                MessageBox.Show("Introduzca la cantidad que quiere apostar");
            else
            {
                string compare = Apostar.Text;

                Regex regex = new Regex(@"^\d+$");

                if (regex.IsMatch(compare))
                {
                    decimal c = Convert.ToDecimal(Apostar.Text);
                    c30 = c30 + c;
                    if (c30 <= Convert.ToInt32(labelfichas.Text))
                    {
                        apuesta30.Text = Convert.ToString(c30);
                        total = c0 + c1 + c2 + c3 + c4 + c5 + c6 + c7 + c8 + c9 + c10 + c11 + c12 + c13 + c14 + c15 + c16 + c17 + c18 + c19 + c20 + c21 + c22 + c23 + c24 + c25 + c26 + c27 + c28 + c29 + c30 + c31 + c32 + c33 + c34 + c35 + c36;
                        fichas = inicial - total;

                        labelfichas.Text = Convert.ToString(Math.Round(fichas, 2));
                    }
                    else
                    {
                        MessageBox.Show("No tienes suficientes fichas");
                    }
                }
                else
                {
                    MessageBox.Show("Introduzca solo numero");
                }
            }
        }

        private void button31_Click_1(object sender, EventArgs e) //apuesta numero 31
        {
            if (Apostar.Text == "")
                MessageBox.Show("Introduzca la cantidad que quiere apostar");
            else
            {
                string compare = Apostar.Text;

                Regex regex = new Regex(@"^\d+$");

                if (regex.IsMatch(compare))
                {
                    decimal c = Convert.ToDecimal(Apostar.Text);
                    c31 = c31 + c;
                    if (c31 <= Convert.ToInt32(labelfichas.Text))
                    {
                        apuesta31.Text = Convert.ToString(c31);
                        total = c0 + c1 + c2 + c3 + c4 + c5 + c6 + c7 + c8 + c9 + c10 + c11 + c12 + c13 + c14 + c15 + c16 + c17 + c18 + c19 + c20 + c21 + c22 + c23 + c24 + c25 + c26 + c27 + c28 + c29 + c30 + c31 + c32 + c33 + c34 + c35 + c36;
                        fichas = inicial - total;

                        labelfichas.Text = Convert.ToString(Math.Round(fichas, 2));
                    }
                    else
                    {
                        MessageBox.Show("No tienes suficientes fichas");
                    }
                }
                else
                {
                    MessageBox.Show("Introduzca solo numero");
                }
            }
        }

        private void button32_Click_1(object sender, EventArgs e) //apuesta numero 32
        {
            if (Apostar.Text == "")
                MessageBox.Show("Introduzca la cantidad que quiere apostar");
            else
            {
                string compare = Apostar.Text;

                Regex regex = new Regex(@"^\d+$");

                if (regex.IsMatch(compare))
                {
                    decimal c = Convert.ToDecimal(Apostar.Text);
                    c32 = c32 + c;
                    if (c32 <= Convert.ToInt32(labelfichas.Text))
                    {
                        apuesta32.Text = Convert.ToString(c32);
                        total = c0 + c1 + c2 + c3 + c4 + c5 + c6 + c7 + c8 + c9 + c10 + c11 + c12 + c13 + c14 + c15 + c16 + c17 + c18 + c19 + c20 + c21 + c22 + c23 + c24 + c25 + c26 + c27 + c28 + c29 + c30 + c31 + c32 + c33 + c34 + c35 + c36;
                        fichas = inicial - total;

                        labelfichas.Text = Convert.ToString(Math.Round(fichas, 2));
                    }
                    else
                    {
                        MessageBox.Show("No tienes suficientes fichas");
                    }
                }
                else
                {
                    MessageBox.Show("Introduzca solo numero");
                }
            }
        }

        private void button33_Click_1(object sender, EventArgs e) //apuesta numero 33
        {
            if (Apostar.Text == "")
                MessageBox.Show("Introduzca la cantidad que quiere apostar");
            else
            {
                string compare = Apostar.Text;

                Regex regex = new Regex(@"^\d+$");

                if (regex.IsMatch(compare))
                {
                    decimal c = Convert.ToDecimal(Apostar.Text);
                    c33 = c33 + c;
                    if (c33 <= Convert.ToInt32(labelfichas.Text))
                    {
                        apuesta33.Text = Convert.ToString(c33);
                        total = c0 + c1 + c2 + c3 + c4 + c5 + c6 + c7 + c8 + c9 + c10 + c11 + c12 + c13 + c14 + c15 + c16 + c17 + c18 + c19 + c20 + c21 + c22 + c23 + c24 + c25 + c26 + c27 + c28 + c29 + c30 + c31 + c32 + c33 + c34 + c35 + c36;
                        fichas = inicial - total;

                        labelfichas.Text = Convert.ToString(Math.Round(fichas, 2));
                    }
                    else
                    {
                        MessageBox.Show("No tienes suficientes fichas");
                    }
                }
                else
                {
                    MessageBox.Show("Introduzca solo numero");
                }
            }
        }

        private void button34_Click_1(object sender, EventArgs e) //apuesta numero 34
        {
            if (Apostar.Text == "")
                MessageBox.Show("Introduzca la cantidad que quiere apostar");
            else
            {
                string compare = Apostar.Text;

                Regex regex = new Regex(@"^\d+$");

                if (regex.IsMatch(compare))
                {
                    decimal c = Convert.ToDecimal(Apostar.Text);
                    c34 = c34 + c;
                    if (c34 <= Convert.ToInt32(labelfichas.Text))
                    {
                        apuesta34.Text = Convert.ToString(c34);
                        total = c0 + c1 + c2 + c3 + c4 + c5 + c6 + c7 + c8 + c9 + c10 + c11 + c12 + c13 + c14 + c15 + c16 + c17 + c18 + c19 + c20 + c21 + c22 + c23 + c24 + c25 + c26 + c27 + c28 + c29 + c30 + c31 + c32 + c33 + c34 + c35 + c36;
                        fichas = inicial - total;

                        labelfichas.Text = Convert.ToString(Math.Round(fichas, 2));
                    }
                    else
                    {
                        MessageBox.Show("No tienes suficientes fichas");
                    }
                }
                else
                {
                    MessageBox.Show("Introduzca solo numero");
                }
            }
        }

        private void button35_Click_1(object sender, EventArgs e) //apuesta numero 35
        {
            if (Apostar.Text == "")
                MessageBox.Show("Introduzca la cantidad que quiere apostar");
            else
            {
                string compare = Apostar.Text;

                Regex regex = new Regex(@"^\d+$");

                if (regex.IsMatch(compare))
                {
                    decimal c = Convert.ToDecimal(Apostar.Text);
                    c35 = c35 + c;
                    if (c35 <= Convert.ToInt32(labelfichas.Text))
                    {
                        apuesta35.Text = Convert.ToString(c35);
                        total = c0 + c1 + c2 + c3 + c4 + c5 + c6 + c7 + c8 + c9 + c10 + c11 + c12 + c13 + c14 + c15 + c16 + c17 + c18 + c19 + c20 + c21 + c22 + c23 + c24 + c25 + c26 + c27 + c28 + c29 + c30 + c31 + c32 + c33 + c34 + c35 + c36;
                        fichas = inicial - total;

                        labelfichas.Text = Convert.ToString(Math.Round(fichas, 2));
                    }
                    else
                    {
                        MessageBox.Show("No tienes suficientes fichas");
                    }
                }
                else
                {
                    MessageBox.Show("Introduzca solo numero");
                }
            }
        }

        private void button36_Click_1(object sender, EventArgs e) //apuesta numero 36
        {
            if (Apostar.Text == "")
                MessageBox.Show("Introduzca la cantidad que quiere apostar");
            else
            {
                string compare = Apostar.Text;

                Regex regex = new Regex(@"^\d+$");

                if (regex.IsMatch(compare))
                {
                    decimal c = Convert.ToDecimal(Apostar.Text);
                    c36 = c36 + c;
                    if (c36 <= Convert.ToInt32(labelfichas.Text))
                    {
                        apuesta36.Text = Convert.ToString(c36);
                        total = c0 + c1 + c2 + c3 + c4 + c5 + c6 + c7 + c8 + c9 + c10 + c11 + c12 + c13 + c14 + c15 + c16 + c17 + c18 + c19 + c20 + c21 + c22 + c23 + c24 + c25 + c26 + c27 + c28 + c29 + c30 + c31 + c32 + c33 + c34 + c35 + c36;
                        fichas = inicial - total;

                        labelfichas.Text = Convert.ToString(Math.Round(fichas, 2));
                    }
                    else
                    {
                        MessageBox.Show("No tienes suficientes fichas");
                    }
                }
                else
                {
                    MessageBox.Show("Introduzca solo numero");
                }
            }
        }

        private void button40_Click(object sender, EventArgs e) //cancelar apuesta
        {
            c0 = 0;
            c1 = 0;
            c2 = 0;
            c3 = 0;
            c4 = 0;
            c5 = 0;
            c6 = 0;
            c7 = 0;
            c8 = 0;
            c9 = 0;
            c10 = 0;
            c11 = 0;
            c12 = 0;
            c13 = 0;
            c14 = 0;
            c15 = 0;
            c16 = 0;
            c17 = 0;
            c18 = 0;
            c19 = 0;
            c20 = 0;
            c21 = 0;
            c22 = 0;
            c23 = 0;
            c24 = 0;
            c25 = 0;
            c26 = 0;
            c27 = 0;
            c28 = 0;
            c29 = 0;
            c30 = 0;
            c31 = 0;
            c32 = 0;
            c33 = 0;
            c34 = 0;
            c35 = 0;
            c36 = 0;
            apuesta0.Text = "0";
            apuesta1.Text = "0";
            apuesta2.Text = "0";
            apuesta3.Text = "0";
            apuesta4.Text = "0";
            apuesta5.Text = "0";
            apuesta6.Text = "0";
            apuesta7.Text = "0";
            apuesta8.Text = "0";
            apuesta9.Text = "0";
            apuesta10.Text = "0";
            apuesta11.Text = "0";
            apuesta12.Text = "0";
            apuesta13.Text = "0";
            apuesta14.Text = "0";
            apuesta15.Text = "0";
            apuesta16.Text = "0";
            apuesta17.Text = "0";
            apuesta18.Text = "0";
            apuesta19.Text = "0";
            apuesta20.Text = "0";
            apuesta21.Text = "0";
            apuesta22.Text = "0";
            apuesta23.Text = "0";
            apuesta24.Text = "0";
            apuesta25.Text = "0";
            apuesta26.Text = "0";
            apuesta27.Text = "0";
            apuesta28.Text = "0";
            apuesta29.Text = "0";
            apuesta30.Text = "0";
            apuesta31.Text = "0";
            apuesta32.Text = "0";
            apuesta33.Text = "0";
            apuesta34.Text = "0";
            apuesta35.Text = "0";
            apuesta36.Text = "0";
            total = c0 + c1 + c2 + c3 + c4 + c5 + c6 + c7 + c8 + c9 + c10 + c11 + c12 + c13 + c14 + c15 + c16 + c17 + c18 + c19 + c20 + c21 + c22 + c23 + c24 + c25 + c26 + c27 + c28 + c29 + c30 + c31 + c32 + c33 + c34 + c35 + c36;
            fichas = inicial - total;
            labelfichas.Text = Convert.ToString(Math.Round(fichas, 2));
        }



        private void ListaConectados_CellContentClick(object sender, DataGridViewCellEventArgs e) //click jugador al que queremos invitar
        {
            string nombres = (string)ListaConectados.Rows[e.RowIndex].Cells[0].Value;
            int encontrado = 0;
            if (fila != null)
            {
                string paraComp = fila + "/";
                string[] trozos1 = paraComp.Split('/');
                int len = trozos1.Length;
                int cont = 0;
                while ((cont < len) && (encontrado == 0))
                {
                    if (nombres == trozos1[cont])
                        encontrado = 1;

                    cont = cont + 1;
                }
                if (encontrado == 0)
                    fila = fila + "/" + nombres;
            }
            else
            {
                fila = nombres;
            }
        }



        private void Form1_FormClosing(object sender, FormClosingEventArgs e) //cierre del form, parar el timer
        {
            timer1.Enabled = false;
        }

        
        private void Form1_Load(object sender, EventArgs e) //apertura del form, con los paneles disabled para que el jugador no pueda tocar cosas sin haber iniciado sesion
        {
            pictureBox1.Image = Image.FromFile(@"C:\Users\jpadulles.CRW-91XCM12\Desktop\Final\Cliente\Juego version1\bin\Debug\ruleta.gif");
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
     
            panel1.Enabled = false;
            panelfunciones.Enabled = false;
        }
        private void ActualizarGrid(string[] res) //funcion para escribir en el grid de lista conectados el usuario dado por el sevidor
        {
            ListaConectados.Rows.Clear(); 
            ListaConectados.Name = "Conectados";
            ListaConectados.ColumnCount = 2;
            ListaConectados.RowHeadersVisible = false;
            ListaConectados.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            ListaConectados.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCellsExceptHeaders;
            ListaConectados.Columns[0].Name = "Jugador";
            ListaConectados.Columns[1].Name = "Socket";

            int i = 1;
            while (i <= Convert.ToInt32(res[0]))
            {
                int s = 2 * i - 1;
                int r = 2 * i;
                ListaConectados.Rows.Add(res[s], res[r]);
                i = i + 1;
            }
        }

        private void EscribirChat(string text) //funcion para escribir en el chat el mensaje dado por el servidor
        {
            string Texto = label_Chat.Text;
            this.label_Chat.Text = text + "\n" + Texto;
        }

        private void EscribirNumero(string text) //funcion para escribir un numero dado por el servidor
        {
            this.Numero.Text = text;
        }

        private void EscribirNumAnt(string text) //funcion para escribir el numero anterior dado por el servidor
        {
            string z = text + " | ";
            v = z + v;
            this.NumAnt.Text = v;
        }


        private void FichasIni(decimal ini) 
        {
            this.labelfichas.Text = Convert.ToString(ini);
        }

        private void ActivarPanel()
        {
            this.panelfunciones.Enabled = true;
        }
        private void ActivarPanelExtra()
        {
            this.panel2.Enabled = true;
            Activartimer1();
            timer1.Interval = 1000;
            FueraButton41();
        }

        private void ActivarPanelRuleta()
        {
            this.panel1.Enabled = true;
            Loginbutton.Enabled = false;
   
            labelfichas.Text = "1000";
        }

        private void Activartimer1()
        {
            this.timer1.Enabled = true;
        }


        private void Invitar_Click_1(object sender, EventArgs e) //funcion de invitacion
        {
            string mensaje;
            if (fila == null)
                MessageBox.Show("Seleccione con quien quiere jugar");
            else
            {
                mensaje = "8/" + fila + "|";
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);
            }
        }

        private void Consultbutton_Click_1(object sender, EventArgs e) //funcion de checks de las consultas que se quieren realizar
        {
            if ((Checkf1.Checked && Checkf2.Checked) || (Checkf1.Checked && Checkf3.Checked) || (Checkf1.Checked && Checkf4.Checked)|| (Checkf2.Checked && Checkf3.Checked)|| (Checkf2.Checked && Checkf4.Checked)|| (Checkf3.Checked && Checkf4.Checked))
            {
                MessageBox.Show("Marca solo una consulta");
            }
            else
            {
                if (Checkf1.Checked)
                {
                    string mensaje = "1/"+Usertext.Text;
                    byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                    server.Send(msg);
                }
                else if (Checkf4.Checked)
                {
                    string mensaje = "11/" + Usertext.Text;
                    byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                    server.Send(msg);
                }
                else if (Checkf2.Checked)
                {
                    string mensaje = "2/" + Usertext.Text;
                    byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                    server.Send(msg);
                }
                else if (Checkf3.Checked)
                {
                    string mensaje = "3/";
                    byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                    server.Send(msg);
                }
        }
        }

        private void button49_Click_1(object sender, EventArgs e) //funcion de escribir en el chat y enviar el mensaje
        {
            string mensaje;
            if (textBox1 == null)
                MessageBox.Show("Escribe un mensaje");
            else
            {
                mensaje = "10/" + miPartida + "/" + textBox1.Text;
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);
            }
        }

        private void MasFichas_Click_1(object sender, EventArgs e) //funcion de añadir mas fichas
        {
            inicial = inicial + 1000;
            labelfichas.Text = Convert.ToString(Math.Round(inicial, 2));
            puntuacion = puntuacion - 1000;
            labelganadas.Text = Convert.ToString(Math.Round(puntuacion, 2));
        }
        

        private void Connectbutton_Click_1(object sender, EventArgs e) //funcion de conectarse al servidor
        {
            IPAddress direc = IPAddress.Parse("147.83.117.22");
            IPEndPoint ipep = new IPEndPoint(direc, 50069);


            //Creamos el socket 
            server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            try
            {
                server.Connect(ipep);//Intentamos conectar el socket
                this.BackColor = Color.Green;
                MessageBox.Show("Conectado");
                conexion = 1;
                

            }
            catch (SocketException ex)
            {
                //Si hay excepcion imprimimos error y salimos del programa con return 
                MessageBox.Show("No he podido conectar con el servidor");
                return;
            }
            
        }




        private void Loginbutton_Click(object sender, EventArgs e) //Funcion de inicio de sesion
        {
            bool resultado = Regex.IsMatch(Usertext.Text, @"^[a-zA-Z]+$");
            if (!resultado)
            {
                MessageBox.Show("El nombre solo puede contener letras");
            }
            else
            {
                if (conexion == 1)
                {
                    string mensaje = "4/" + Usertext.Text + "/" + Passwordtext.Text;
                    // Enviamos al servidor el nombre tecleado
                    byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                    server.Send(msg);

                    ThreadStart ts = delegate { AtenderServidor(); };
                    atender = new Thread(ts);
                    atender.Start();
  

                }
                else
                {
                    MessageBox.Show("No estas conectado");
                }
            }
        }
        
        private void FueraButton41()
        {
            this.button41.Enabled = false;
        }
        private void Registro_Click(object sender, EventArgs e) //Funcion de registro
        {
            string mensaje = "5/" + Usertext.Text + "/" + Passwordtext.Text;
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);
        }

        private void button39_Click(object sender, EventArgs e) //Boton de girar, en el caso de estar jugando un jugador
        {

            SoundPlayer player1 = new SoundPlayer(@"C:\Users\Joan R\Desktop\Cliente\Juego version1\bin\Debug\hola3.wav");
            player1.Play();
            System.Threading.Thread.Sleep(2500);
            SoundPlayer player2 = new SoundPlayer(@"C:\Users\Joan R\Desktop\Cliente\Juego version1\bin\Debug\hola1.wav");
            player2.PlayLooping();
            
            

         
            decimal ganadas = 0m;
            apuesta0.Text = "0";
            apuesta1.Text = "0";
            apuesta2.Text = "0";
            apuesta3.Text = "0";
            apuesta4.Text = "0";
            apuesta5.Text = "0";
            apuesta6.Text = "0";
            apuesta7.Text = "0";
            apuesta8.Text = "0";
            apuesta9.Text = "0";
            apuesta10.Text = "0";
            apuesta11.Text = "0";
            apuesta12.Text = "0";
            apuesta13.Text = "0";
            apuesta14.Text = "0";
            apuesta15.Text = "0";
            apuesta16.Text = "0";
            apuesta17.Text = "0";
            apuesta18.Text = "0";
            apuesta19.Text = "0";
            apuesta20.Text = "0";
            apuesta21.Text = "0";
            apuesta22.Text = "0";
            apuesta23.Text = "0";
            apuesta24.Text = "0";
            apuesta25.Text = "0";
            apuesta26.Text = "0";
            apuesta27.Text = "0";
            apuesta28.Text = "0";
            apuesta29.Text = "0";
            apuesta30.Text = "0";
            apuesta31.Text = "0";
            apuesta32.Text = "0";
            apuesta33.Text = "0";
            apuesta34.Text = "0";
            apuesta35.Text = "0";
            apuesta36.Text = "0";
            Random r = new Random();
            int x = r.Next(0, 37);
            string y = Convert.ToString(x);
            Numero.Text = y;
            string z = y + " | ";
            v = z + v;
            NumAnt.Text = v;
            if (x == 1 | x == 3 | x == 5 | x == 7 | x == 9 | x == 12 | x == 14 | x == 16 | x == 18 | x == 19 | x == 21 | x == 23 | x == 25 | x == 27 | x == 30 | x == 32 | x == 34 | x == 36)
            {
                this.Numero.ForeColor = System.Drawing.Color.FromArgb(255, 0, 0);
            }
            else if (x == 2 | x == 4 | x == 6 | x == 8 | x == 10 | x == 11 | x == 13 | x == 15 | x == 17 | x == 20 | x == 22 | x == 24 | x == 26 | x == 28 | x == 29 | x == 31 | x == 33 | x == 35)
            {
                this.Numero.ForeColor = System.Drawing.Color.FromArgb(0, 0, 0);
            }
            else
            {
                this.Numero.ForeColor = System.Drawing.Color.FromArgb(0, 192, 0);
            }
            if (x == 0)
            {
                fichas = fichas + c0 * 36;
            }
            else if (x == 1)
            {
                fichas = fichas + c1 * 36;
            }
            else if (x == 2)
            {
                fichas = fichas + c2 * 36;
            }
            else if (x == 3)
            {
                fichas = fichas + c3 * 36;
            }
            else if (x == 4)
            {
                fichas = fichas + c4 * 36;
            }
            else if (x == 5)
            {
                fichas = fichas + c5 * 36;
            }
            else if (x == 6)
            {
                fichas = fichas + c6 * 36;
            }
            else if (x == 7)
            {
                fichas = fichas + c7 * 36;
            }
            else if (x == 8)
            {
                fichas = fichas + c8 * 36;
            }
            else if (x == 9)
            {
                fichas = fichas + c9 * 36;
            }
            else if (x == 10)
            {
                fichas = fichas + c10 * 36;
            }
            else if (x == 11)
            {
                fichas = fichas + c11 * 36;
            }
            else if (x == 12)
            {
                fichas = fichas + c12 * 36;
            }
            else if (x == 13)
            {
                fichas = fichas + c13 * 36;
            }
            else if (x == 14)
            {
                fichas = fichas + c14 * 36;
            }
            else if (x == 15)
            {
                fichas = fichas + c15 * 36;
            }
            else if (x == 16)
            {
                fichas = fichas + c16 * 36;
            }
            else if (x == 17)
            {
                fichas = fichas + c17 * 36;
            }
            else if (x == 18)
            {
                fichas = fichas + c18 * 36;
            }
            else if (x == 19)
            {
                fichas = fichas + c19 * 36;
            }
            else if (x == 20)
            {
                fichas = fichas + c20 * 36;
            }
            else if (x == 21)
            {
                fichas = fichas + c21 * 36;
            }
            if (x == 22)
            {
                fichas = fichas + c22 * 36;
            }
            if (x == 23)
            {
                fichas = fichas + c23 * 36;
            }
            if (x == 24)
            {
                fichas = fichas + c24 * 36;
            }
            if (x == 25)
            {
                fichas = fichas + c25 * 36;
            }
            if (x == 26)
            {
                fichas = fichas + c26 * 36;
            }
            if (x == 27)
            {
                fichas = fichas + c27 * 36;
            }
            if (x == 28)
            {
                fichas = fichas + c28 * 36;
            }
            if (x == 29)
            {
                fichas = fichas + c29 * 36;
            }
            if (x == 30)
            {
                fichas = fichas + c30 * 36;
            }
            if (x == 31)
            {
                fichas = fichas + c31 * 36;
            }
            if (x == 32)
            {
                fichas = fichas + c32 * 36;
            }
            if (x == 33)
            {
                fichas = fichas + c33 * 36;
            }
            if (x == 34)
            {
                fichas = fichas + c34 * 36;
            }
            if (x == 35)
            {
                fichas = fichas + c35 * 36;
            }
            if (x == 36)
            {
                fichas = fichas + c36 * 36;
            }
            apuesta = inicial;
            inicial = fichas;
            ganadas = fichas - apuesta + total;
            labelfichas.Text = Convert.ToString(Math.Round(inicial, 2));
            labelganadas.Text = Convert.ToString(Math.Round(ganadas, 2));

            c0 = 0;
            c1 = 0;
            c2 = 0;
            c3 = 0;
            c4 = 0;
            c5 = 0;
            c6 = 0;
            c7 = 0;
            c8 = 0;
            c9 = 0;
            c10 = 0;
            c11 = 0;
            c12 = 0;
            c13 = 0;
            c14 = 0;
            c15 = 0;
            c16 = 0;
            c17 = 0;
            c18 = 0;
            c19 = 0;
            c20 = 0;
            c21 = 0;
            c22 = 0;
            c23 = 0;
            c24 = 0;
            c25 = 0;
            c26 = 0;
            c27 = 0;
            c28 = 0;
            c29 = 0;
            c30 = 0;
            c31 = 0;
            c32 = 0;
            c33 = 0;
            c34 = 0;
            c35 = 0;
            c36 = 0;

        }

 

        private void Passwordtext_TextChanged(object sender, EventArgs e)
        {
            
            // The password character is an asterisk.
            Passwordtext.PasswordChar = '*';
        }


        private void timer1_Tick(object sender, EventArgs e)
        {
            conteo = conteo - 1;
            tiempoLbl.Text = Convert.ToString(conteo);
            if (conteo == 0)
            {
                string mensaje = "12/" + miPartida;
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);

                apuesta0.Text = "0";
                apuesta1.Text = "0";
                apuesta2.Text = "0";
                apuesta3.Text = "0";
                apuesta4.Text = "0";
                apuesta5.Text = "0";
                apuesta6.Text = "0";
                apuesta7.Text = "0";
                apuesta8.Text = "0";
                apuesta9.Text = "0";
                apuesta10.Text = "0";
                apuesta11.Text = "0";
                apuesta12.Text = "0";
                apuesta13.Text = "0";
                apuesta14.Text = "0";
                apuesta15.Text = "0";
                apuesta16.Text = "0";
                apuesta17.Text = "0";
                apuesta18.Text = "0";
                apuesta19.Text = "0";
                apuesta20.Text = "0";
                apuesta21.Text = "0";
                apuesta22.Text = "0";
                apuesta23.Text = "0";
                apuesta24.Text = "0";
                apuesta25.Text = "0";
                apuesta26.Text = "0";
                apuesta27.Text = "0";
                apuesta28.Text = "0";
                apuesta29.Text = "0";
                apuesta30.Text = "0";
                apuesta31.Text = "0";
                apuesta32.Text = "0";
                apuesta33.Text = "0";
                apuesta34.Text = "0";
                apuesta35.Text = "0";
                apuesta36.Text = "0";

                conteo = 60;
            }
            durada = durada + 1;
        }
    
        

        private void Disconectbutton_Click(object sender, EventArgs e)
        {
            //Mensaje de desconexión
            timer1.Enabled = false;
            //int puntos = 0;
            //int x = 0;

            string mensaje = "00/";

            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);
            MessageBox.Show("Te has desconnectado correctamente");

            // Nos desconectamos
           // atender.Abort();
            this.BackColor = Color.Gray;
            server.Shutdown(SocketShutdown.Both);
            server.Close();
            
        }

        private void Eliminar_Click(object sender, EventArgs e)
        {
            string mensaje = "6/" + Usertext.Text + "/" + Passwordtext.Text;
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);
        }

        private void button41_Click(object sender, EventArgs e)
        {
            string mensaje = "20/";
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);
        }

        private void IntroducirGanadas(decimal ganadas, decimal fichas)
        {
            
            labelfichas.Text = Convert.ToString(Math.Round(fichas, 2));
            labelganadas.Text = Convert.ToString(Math.Round(ganadas, 2));

        }
   
  
    }
}
