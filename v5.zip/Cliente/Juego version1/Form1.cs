﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        Socket server;
        Thread atender;

        public Form1()
        {
            InitializeComponent();
            CheckForIllegalCrossThreadCalls = false;
        }

        private void AtenderServidor()
        {
            while (true)
            {
                //Recibimos mensaje del servidor
                byte[] msg2 = new byte[512];
                server.Receive(msg2);
                string[] trozos = Encoding.ASCII.GetString(msg2).Split('/');
                int codigo = Convert.ToInt32(trozos[0]);
                //string mensaje = mensaje = trozos[1].Split('\0')[0];
                string mensaje = trozos[1].Split('\0')[0];

                switch (codigo)
                {
                    case 0:
                        server.Shutdown(SocketShutdown.Both);
                        server.Close();
                        break;
                    case 1: //login

                        if (mensaje == "SI")
                        {
                            MessageBox.Show("Se ha iniciado sesión correctamente");
                            //Ya se pueden pedir funciones
                            panelfunciones.Enabled = true;
                        }
                        else if (mensaje == "NO")
                        {
                            MessageBox.Show("Contrasenya incorrecta");
                        }
                        else
                        {
                            MessageBox.Show("Error al iniciar sesión");
                        }
                        break;
                    case 2: //consulta 1

                        MessageBox.Show("El jugador que mas partidas ha ganado es es: \n" + mensaje);
                        break;

                    case 3: //consulta 2

                        MessageBox.Show("Los jugadores que han jugado en esa fecha son: \n" + mensaje);
                        break;


                    case 4: //notificacion conectados

                        string[] res = mensaje.Split('/');
                        ListaConectados.Rows.Clear();
                        ListaConectados.Name = "Conectados";
                        ListaConectados.ColumnCount = 2;
                        //ListaConectados.RowCount = Convert.ToInt32(res[0]);
                        //ListaConectados.ColumnHeadersVisible = false;
                        ListaConectados.RowHeadersVisible = false;
                        ListaConectados.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
                        ListaConectados.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCellsExceptHeaders;
                        //ListaConectados[0,0].Value="Jugador";
                        //ListaConectados[1,0].Value="Socket";
                        ListaConectados.Columns[0].Name = "Jugador";
                        ListaConectados.Columns[1].Name = "Socket";

                        int i = 1;
                        while (i <= Convert.ToInt32(res[0]))
                        {
                            int s = 2 * i - 1;
                            int r = 2 * i;
                            ListaConectados.Rows.Add(res[s], res[r]);
                            i = i + 1;
                        }
                        break;



                }
            }
        }

       

        
        private void DisconnectButton_Click(object sender, EventArgs e)
        {
            //Mensaje de desconexión
            string mensaje = "0/" + Usertext.Text;

            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);

            // Nos desconectamos
            atender.Abort();
            this.BackColor = Color.Gray;
            server.Shutdown(SocketShutdown.Both);
            server.Close();
        }

        private void button_enviar_peticion_Click(object sender, EventArgs e)
        {
            if (Checkf1.Checked)
            {
                string mensaje = "2/";

                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);

                //Recibimos la respuesta del servidor
                byte[] msg2 = new byte[512];
                server.Receive(msg2);
                mensaje = Encoding.ASCII.GetString(msg2).Split('\0')[0];
                MessageBox.Show("El jugador que mas partidas ha ganado es es: \n" + mensaje);
            }
            if (checkBox1.Checked)
            {
                string mensaje = "3/" + fecha.Text;

                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);
            }
        }

        private void Connectbutton_Click(object sender, EventArgs e)
        {
            IPAddress direc = IPAddress.Parse("192.168.56.101");
            IPEndPoint ipep = new IPEndPoint(direc, 9050);


            //Creamos el socket 
            server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            try
            {
                server.Connect(ipep);//Intentamos conectar el socket
                this.BackColor = Color.Green;
                MessageBox.Show("Conectado");

            }
            catch (SocketException ex)
            {
                //Si hay excepcion imprimimos error y salimos del programa con return 
                MessageBox.Show("No he podido conectar con el servidor");
                return;
            }
        }

        private void Loginbutton_Click(object sender, EventArgs e)
        {
            string mensaje = "4/" + Usertext.Text + "/" + Passwordtext.Text;
            // Enviamos al servidor el nombre tecleado
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);

            ThreadStart ts = delegate { AtenderServidor(); };
            atender = new Thread(ts);
            atender.Start();
        }

        

    }
}