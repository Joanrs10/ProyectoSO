﻿DROP DATABASE IF EXISTS Juego;
CREATE DATABASE Juego;
USE Juego;
CREATE TABLE Jugador (
  Codigo INTEGER NOT NULL,
  Nombre TEXT NOT NULL,
  Contrasenya TEXT NOT NULL,
  Partidasganadas INTEGER NOT NULL,
  Partidasperdidas INTEGER NOT NULL,
  PRIMARY KEY (Codigo)
)ENGINE = InnoDB;

CREATE TABLE Partida (
  Codigo INTEGER NOT NULL,
  Nombreganador TEXT NOT NULL,
  Duracion INTEGER NOT NULL,
  Fecha TEXT NOT NULL,
  PRIMARY KEY (Codigo)
)ENGINE = InnoDB;

CREATE TABLE Relacion (
  IdJugador INTEGER, 
  IdPartida INTEGER,
  Puntos INTEGER NOT NULL,
  FOREIGN KEY (IdJugador) REFERENCES Jugador(Codigo),
  FOREIGN KEY (IdPartida) REFERENCES Partida(Codigo)
  )ENGINE = InnoDB;

INSERT INTO Jugador(Codigo, Nombre, Contrasenya, PartidasGanadas, PartidasPerdidas) VALUES(1,'Arnau','hola',3,0);
INSERT INTO Jugador(Codigo, Nombre, Contrasenya, PartidasGanadas, PartidasPerdidas) VALUES(2,'Joan','hola',0,4);
INSERT INTO Jugador(Codigo, Nombre, Contrasenya, PartidasGanadas, PartidasPerdidas) VALUES(3,'Alex','hola',1,0);

INSERT INTO Partida(Codigo, Nombreganador, Duracion, Fecha) VALUES(1,'Arnau', 60, '2/10');
INSERT INTO Partida(Codigo, Nombreganador, Duracion, Fecha) VALUES(2,'Arnau', 50, '2/10');
INSERT INTO Partida(Codigo, Nombreganador, Duracion, Fecha) VALUES(3,'Alex', 40, '2/10');
INSERT INTO Partida(Codigo, Nombreganador, Duracion, Fecha) VALUES(4,'Arnau', 30, '2/10');

INSERT INTO Relacion(IdJugador, IdPartida, Puntos) VALUES(1, 1 , 20);
INSERT INTO Relacion(IdJugador, IdPartida, Puntos) VALUES(2, 1 , 15);
INSERT INTO Relacion(IdJugador, IdPartida, Puntos) VALUES(1, 2 , 30);
INSERT INTO Relacion(IdJugador, IdPartida, Puntos) VALUES(2, 2 , 15);
INSERT INTO Relacion(IdJugador, IdPartida, Puntos) VALUES(3, 3 , 50);
INSERT INTO Relacion(IdJugador, IdPartida, Puntos) VALUES(2, 3 , 5);
INSERT INTO Relacion(IdJugador, IdPartida, Puntos) VALUES(1, 4 , 45);
INSERT INTO Relacion(IdJugador, IdPartida, Puntos) VALUES(2, 4 , 40);
