#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <mysql.h>
#include <pthread.h>

//estructura para sockets y conectados
typedef struct{
	char nombre[50];
	int socket;
}Conectado;
typedef struct{
	int numero;
	Conectado conectados[100];
}ListaConectados;


int Poner(char nombre[50],int socket, ListaConectados *lista)
	
{
	if (lista->numero<100)
	{
		lista->conectados[lista->numero].socket=socket;
		strcpy(lista->conectados[lista->numero].nombre,nombre);
		lista->numero++;
		
		
		return 0;
	}
	else
		return -1;
}


int Quitar(char nombre[50],ListaConectados *lista)
{
	int encontrado=0;
	int i=0;
	while ((i<lista->numero) &&(!encontrado))
	{
		if (strcmp(lista->conectados[i].nombre,nombre)==0)
			encontrado=1;
		else
			i=i+1;
	}
	if (encontrado)
	{
		while (i<lista->numero-1)
		{
			lista->conectados[i]=lista->conectados[i+1];
			i=i+1;
		}
		lista->numero=lista->numero-1;
		return 0;
	}
	else
		return -1;
}


int DameSocket(char nombre[50],ListaConectados *lista)
	
{
	int encontrado=0;
	int i=0;
	while((i<lista->numero)&&(!encontrado))
	{
		if (strcmp(lista->conectados[i].nombre,nombre)==0)
			encontrado=1;
		else
			i=i+1;
	}
	if (encontrado)
		return lista->conectados[i].socket;
	else
		return -1;
}


void DameConectados(ListaConectados *lista, char conectados[100])
{
	int i;
	sprintf(conectados,"%d",lista->numero);
	for(i=0;i<(lista->numero);i++)
		sprintf(conectados,"%s/%s/%d",conectados,lista->conectados[i].nombre,lista->conectados[i].socket);
	
}



//estructura para listapartidas
/*typedef struct{*/
/*	char jug1[20];*/
/*	int sock1;*/
/*	char jug2[20];*/
/*	int sock2;*/
/*}TablaPartida;*/

typedef struct{
	int id_partida;
	char Jugadores[100];
}TablaPartida;


/*int DameSocketRival(TablaPartida table[100],char Jugador[20],int id)*/
/*{*/
/*	if (strcmp(table[id].jug1,Jugador)==0)*/
/*		return table[id].sock2;*/
/*	else if (strcmp(table[id].jug2,Jugador)==0)*/
/*		return table[id].sock1;*/
/*	else*/
/*		return -1;*/
/*}*/

void Rellenar(TablaPartida table[100])
{
	int cont=0;
	while (cont<100)
	{
		table[cont].id_partida=-1;
		cont=cont+1;
	}
	return;
}

int AnadirPartida(TablaPartida table[100], char jugador[100])
{
	int cont=0;
	int encontrado=0;
	while ((!encontrado)&&(cont<100))
	{
		if (table[cont].id_partida==-1)
			encontrado=1;
		else
			cont=cont+1;
	}
	if (encontrado==1)
	{
		strcpy(table[cont].Jugadores,jugador);
		table[cont].id_partida=cont;
		return cont;
	}
	else
		return -1;
}

int EliminarPartida(TablaPartida table[100], int id)
{
	if ((id>=0) && (id<=100))
	{
		table[id].Jugadores,"";
		table[id].id_partida=-1;
		return id;
	}
	else
		return -1;
}

int contador;
ListaConectados miLista;
TablaPartida miTablaPartidas[100];



/*int cont=0;*/
/*while (cont<100)*/
/*{*/
/*	miTablaPartidas[cont].sock1==-1;*/
/*	miTablaPartidas[cont].sock2==-1;*/
/*	cont=cont+1;*/
/*}*/



//Estructura acceso excluyente
pthread_mutex_t mutex=PTHREAD_MUTEX_INITIALIZER;

void *AtenderCliente (void *socket)
{
	int sock_conn;
	int *s;
	s=(int *) socket;
	sock_conn=*s;
	
	char peticion[512];
	char respuesta[512];
	int ret;
	int numero;
	char consulta [200];
	
	int terminar=0;
	
	// Entramos en un bucle para atender todas las peticiones de este cliente
	//hasta que se desconecte
	while (terminar ==0)
	{
		// Ahora recibimos la petici?n
		ret=read(sock_conn,peticion, sizeof(peticion));
		printf ("Recibido\n");
		
		MYSQL *conn;
		int err;
		// Estructura especial para almacenar resultados de consultas 
		MYSQL_RES *resultado;
		MYSQL_ROW row;
		
		//Creamos una conexion al servidor MYSQL 
		conn = mysql_init(NULL);
		if (conn==NULL) {
			printf ("Error al crear la conexion: %u %s\n", 
					mysql_errno(conn), mysql_error(conn));
			exit (1);
		}
		//inicializar la conexion
		conn = mysql_real_connect (conn, "localhost","root", "mysql", "Juego",0, NULL, 0);
		if (conn==NULL) {
			printf ("Error al inicializar la conexion: %u %s\n", 
					mysql_errno(conn), mysql_error(conn));
			exit (1);
		}
		// consulta SQL para obtener una tabla con todos los datos
		// de la base de datos
		err=mysql_query (conn, "SELECT * FROM Jugador");
		if (err!=0) {
			printf ("Error al consultar datos de la base %u %s\n",
					mysql_errno(conn), mysql_error(conn));
			exit (1);
		}
		//recogemos el resultado de la consulta. El resultado de la
		//consulta se devuelve en una variable del tipo puntero a
		//MYSQL_RES tal y como hemos declarado anteriormente.
		//Se trata de una tabla virtual en memoria que es la copia
		//de la tabla real en disco.
		resultado = mysql_store_result (conn);
		// El resultado es una estructura matricial en memoria
		// en la que cada fila contiene los datos de una persona.
		
		// Ahora obtenemos la primera fila que se almacena en una
		// variable de tipo MYSQL_ROW
		row = mysql_fetch_row (resultado);
		// En una fila hay tantas columnas como datos tiene una
		// persona. En nuestro caso hay tres columnas: dni(row[0]),
		// nombre(row[1]) y edad (row[2]).
		if (row == NULL)
			printf ("No se han obtenido datos en la consulta\n");
		else
		{
			while (row !=NULL) 
			{
				// la columna 2 contiene una palabra que es la edad
				// la convertimos a entero 
				
				// las columnas 0 y 1 contienen DNI y nombre 
				printf ("ID: %s, Username: %s, Password: %s\n", row[0], row[1], row[2]);
				// obtenemos la siguiente fila
				row = mysql_fetch_row (resultado);
			}
		}
		
		
		err=mysql_query (conn, "SELECT * FROM Relacion");
		if (err!=0) {
			printf ("Error al consultar datos de la base %u %s\n",
					mysql_errno(conn), mysql_error(conn));
			exit (1);
		}
		//recogemos el resultado de la consulta. El resultado de la
		//consulta se devuelve en una variable del tipo puntero a
		//MYSQL_RES tal y como hemos declarado anteriormente.
		//Se trata de una tabla virtual en memoria que es la copia
		//de la tabla real en disco.
		resultado = mysql_store_result (conn);
		// El resultado es una estructura matricial en memoria
		// en la que cada fila contiene los datos de una persona.
		
		// Ahora obtenemos la primera fila que se almacena en una
		// variable de tipo MYSQL_ROW
		row = mysql_fetch_row (resultado);
		// En una fila hay tantas columnas como datos tiene una
		// persona. En nuestro caso hay tres columnas: dni(row[0]),
		// nombre(row[1]) y edad (row[2]).
		if (row == NULL)
			printf ("No se han obtenido datos en la consulta\n");
		else
		{
			while (row !=NULL) 
			{
				// la columna 2 contiene una palabra que es la edad
				// la convertimos a entero 
				
				// las columnas 0 y 1 contienen DNI y nombre 
				printf ("Id jugador: %d, Id partida: %d, puntos: %d\n", atoi(row[0]), atoi(row[1]), atoi(row[2]));
				// obtenemos la siguiente fila
				row = mysql_fetch_row (resultado);
			}
		}
		
		err=mysql_query (conn, "SELECT * FROM Partida");
		if (err!=0) {
			printf ("Error al consultar datos de la base %u %s\n",
					mysql_errno(conn), mysql_error(conn));
			exit (1);
		}
		//recogemos el resultado de la consulta. El resultado de la
		//consulta se devuelve en una variable del tipo puntero a
		//MYSQL_RES tal y como hemos declarado anteriormente.
		//Se trata de una tabla virtual en memoria que es la copia
		//de la tabla real en disco.
		resultado = mysql_store_result (conn);
		// El resultado es una estructura matricial en memoria
		// en la que cada fila contiene los datos de una persona.
		
		// Ahora obtenemos la primera fila que se almacena en una
		// variable de tipo MYSQL_ROW
		row = mysql_fetch_row (resultado);
		// En una fila hay tantas columnas como datos tiene una
		// persona. En nuestro caso hay tres columnas: dni(row[0]),
		// nombre(row[1]) y edad (row[2]).
		if (row == NULL)
			printf ("No se han obtenido datos en la consulta\n");
		else
		{
			while (row !=NULL) 
			{
				// la columna 2 contiene una palabra que es la edad
				// la convertimos a entero 
				
				// las columnas 0 y 1 contienen DNI y nombre 
				
				// obtenemos la siguiente fila
				row = mysql_fetch_row (resultado);
			}
		}
		
		// Tenemos que a?adirle la marca de fin de string 
		// para que no escriba lo que hay despues en el buffer
		peticion[ret]='\0';
		
		
		printf ("Peticion: %s\n",peticion);
		
		// vamos a ver que quieren
		char *p = strtok( peticion, "/");
		int codigo =  atoi (p);
		// Ya tenemos el c?digo de la petici?n
		char nombre[20];
		char partida[20];
		char usuario[50];
		char contrasenya[50];
		char fila[20];
		int contTabla;

		
		if (codigo ==0) //petici?n de desconexi?n
		{
			
			p = strtok( NULL, "/");
			
			strcpy (nombre, p);
			
			int res=(Quitar,&miLista);
			if (res==-1)
				printf("Error\n");
			char conectados[100];
			DameConectados(&miLista,conectados);
			printf ("Conectados: %s\n",conectados);
			sprintf(respuesta,"%s",conectados);
			terminar=1;
			/*			mysql_close (conn);*/
			/*			exit(0);*/
		}
		else if (codigo ==1) 
		{	
			p = strtok( NULL, "/");
			strcpy(usuario,p);
			p = strtok( NULL, "/");
			strcpy(contrasenya,p);
			
			strcpy(respuesta,"");
			strcpy(consulta,"SELECT Jugador.Contrasenya FROM Jugador WHERE Jugador.Nombre='");
			strcat(consulta,usuario);
			strcat(consulta,"'");
			err=mysql_query (conn, consulta); 
			if (err!=0) {
				printf ("Error al consultar datos de la base %u %s\n",
						mysql_errno(conn), mysql_error(conn));
				exit (1);
			}
			//recogemos el resultado de la consulta 
			resultado = mysql_store_result (conn); 
			row = mysql_fetch_row (resultado);
			printf("ContrasenyaBBDD: %s\n",row[0]);
			printf("Contrasenya: %s\n",contrasenya);
			if (row == NULL)
			{
				printf ("No se han obtenido datos en la consulta\n");
				strcpy(respuesta,"1/NO");
			}
			
			else
			{
				
				if (strcmp(row[0],contrasenya)==0)
				{
					strcpy(respuesta,"1/SI");
					/*					contador=contador+1;*/
					/*					int cod=Pon(usuario,&contador,&miLista);*/
					int cod=Poner(usuario,sock_conn,&miLista);
					if (cod==-1)
						printf("Error\n");
					
				}
				
			}
		}	
		
		else if (codigo ==2)
		{
			
			err=mysql_query (conn, "select Jugador.nombre from Jugador where Jugador.Partidasganadas=(select max(Jugador.Partidasganadas) from Jugador)");
			if (err!=0)
			{
				printf ("Error al consultar datos de la base %u %s\n",
						mysql_errno(conn), mysql_error(conn));
				exit (1);
			}
			
			resultado = mysql_store_result (conn);
			row = mysql_fetch_row (resultado);
			
			if (row == NULL)
			{
				printf ("No se han obtenido datos en la consulta\n");
			}
			else
			{
				strcpy (respuesta, "2/");
				strcat(respuesta, row);
				return 1;
			}
			
			
			
		}	
		
		else if (codigo ==3)
		{
			p = strtok( NULL, "/");
			char fecha[20];
			strcpy (fecha, p); 
			char consulta1[80]; 
			strcpy(consulta1,"SELECT Jugador.nombre FROM Jugador,Relacion,Partida WHERE partida.fecha = '");
			strcat(consulta1,fecha);
			strcat(consulta1,"'AND Partida.id = Relacion.idpartida AND jugador.id = relacion.idjugador");
			err=mysql_query (conn,consulta);
			
			if (err!=0)
			{
				printf ("Error al consultar datos de la base %u %s\n",
						mysql_errno(conn), mysql_error(conn));
				exit (1);
			}
			
			resultado = mysql_store_result (conn);
			row = mysql_fetch_row (resultado);
			if (row == NULL)
			{
				printf ("No se han obtenido datos en la consulta\n");
			}
			else
			{
				strcpy (respuesta, "3/");
				while (row !=NULL) 
				{
					printf ("%s\n", row[0]);
					row = mysql_fetch_row (resultado);
					strcpy (respuesta, row);
					sprintf(respuesta,"respuesta%s,",row);
				}
				return 1;
				mysql_close (conn);
				
			}			
		}
		
		
		
		
		
		
		
		
		if ((codigo==1)||(codigo==2)||(codigo==3))
		{
			pthread_mutex_lock(&mutex);
			contador=contador+1;
			pthread_mutex_unlock(&mutex);
		}
		
		if (codigo==0)
		{
			char conectados[100];
			DameConectados(&miLista,conectados);
			printf ("%s\n",conectados);
			char notificacion[20];
			sprintf(notificacion, "4/%s", conectados);
			printf("Notificacion: %s\n", notificacion);
			int j=0;
			while (j<miLista.numero)
			{
				write(miLista.conectados[j].socket, notificacion, strlen(notificacion));
				/*				write(4, notificacion, strlen(notificacion));*/
				/*				write(socket[j],notificacion, strlen(notificacion));*/
				j=j+1;
			}
			
		}
		// Se acabo el servicio para este cliente
		// cerrar la conexion con el servidor MYSQL 
		
		
	}
	
	close(sock_conn); 
	
}


int main(int argc, char *argv[])
{
	
	int sock_conn, sock_listen;
	struct sockaddr_in serv_adr;
	
	Rellenar(miTablaPartidas);
	
	if ((sock_listen = socket(AF_INET, SOCK_STREAM, 0)) < 0)
		printf("Error creant socket");
	// Fem el bind al port
	
	
	memset(&serv_adr, 0, sizeof(serv_adr));// inicialitza a zero serv_addr
	serv_adr.sin_family = AF_INET;
	
	// asocia el socket a cualquiera de las IP de la m?quina. 
	//htonl formatea el numero que recibe al formato necesario
	serv_adr.sin_addr.s_addr = htonl(INADDR_ANY);
	// establecemos el puerto de escucha
	serv_adr.sin_port = htons(9050);
	if (bind(sock_listen, (struct sockaddr *) &serv_adr, sizeof(serv_adr)) < 0)
		printf ("Error al bind");
	
	if (listen(sock_listen, 3) < 0)
		printf("Error en el Listen");
	
	contador=0;
	int i=0;
	int sockets[100];
	pthread_t thread[100];
	// Bucle infinito
	for (;;){
		printf ("Escuchando\n");
		
		sock_conn = accept(sock_listen, NULL, NULL);
		printf ("He recibido conexion\n");
		//sock_conn es el socket que usaremos para este cliente
		sockets[i]=sock_conn;
		
		pthread_create(&thread[i],NULL,AtenderCliente,&sockets[i]);
		i=i+1;
		
	}
	/*	mysql_close (conn);*/
	exit(0);
}

	
	
}
