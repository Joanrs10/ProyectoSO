#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <stdio.h>
#include <mysql.h>
#include <pthread.h>



//Estructura necesaria para acceso excluyente
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

typedef struct {
	char nombre [20];
	int socket;
} usuario;

typedef struct {
	usuario usuarios [100];
	int num;
} ListaConectados;

void ABRIRBBDD (void)
{
	MYSQL *conn;
	int err;
	
	MYSQL_RES *resultado;
	MYSQL_ROW row;
	
	
	conn = mysql_init(NULL);
	if (conn==NULL)
	{
		printf ("Error al crear la conexion: %u %s\n",
				mysql_errno(conn), mysql_error(conn));
		exit (1);
	}
	
	conn = mysql_real_connect (conn, "localhost", "root", "mysql",
							   "Juego",0, NULL, 0);
	if (conn==NULL)
	{
		printf ("Error al inicializar la conexion: %u %s\n",
				mysql_errno(conn), mysql_error(conn));
		exit (1);
	}
	else 
	{ 
		printf("Conexion realizada con exito\n");
	}
}
int CONSULTARBBDD (int codigo, char p[512], char respuesta[512], char nombre [20])
{ 
	MYSQL *conn;
	int err;
	MYSQL_RES *resultado;
	MYSQL_ROW row;
	conn = mysql_init(NULL);
	
	if (codigo ==0);
	{
		p = strtok( NULL, "/");
		strcpy (nombre, p);
		strcpy (respuesta,"0/");
		return 0;
	}
	if (codigo ==1)
	{
		p = strtok( NULL, "/");
		strcpy (nombre, p);
		char password[20];
		p = strtok( NULL, "/");
		strcpy (password, p); 
		MYSQL *conn;
		int err;
		
		MYSQL_RES *resultado;
		MYSQL_ROW row;
		char consulta[80]; 
		strcpy(consulta,"SELECT Jugador.Codigo FROM Jugador WHERE Jugador.Nombre = '");
		strcat(consulta, nombre);
		strcat(consulta,"'AND Jugador.Contrase�a = '");
		strcat(consulta, p);
		err=mysql_query (conn,consulta);
		
		if (err!=0)
		{
			printf ("Error al consultar datos de la base %u %s\n",
					mysql_errno(conn), mysql_error(conn));
			
			exit (1);
		}
		
		resultado = mysql_store_result (conn);
		
		row = mysql_fetch_row (resultado);
		
		if (row == NULL)
		{
			printf ("No se han obtenido datos en la consulta\n");
			strcpy (respuesta,"1/NO");
			return 1;
		}
		
		
		else
		{
			strcpy (respuesta,"1/SI");
			return 1;
		}
	}
	
	if (codigo == 2)
	{
		char consulta[20];
		strcpy(consulta,"SELECT Jugador.nombre FROM Jugador where Jugador.Partidasganadas=(SELECT MAX(Jugador.Partidasganadas) FROM Jugador)");
		err=mysql_query (conn,consulta);
		
		if (err!=0)
		{
			printf ("Error al consultar datos de la base %u %s\n",
					mysql_errno(conn), mysql_error(conn));
			exit (1);
		}
		
		resultado = mysql_store_result (conn);
		row = mysql_fetch_row (resultado);
		
		if (row == NULL)
		{
			printf ("No se han obtenido datos en la consulta\n");
		}
		else
		{
			strcpy (respuesta, "2/'");
			strcat(respuesta, row[0]);
			return 1;
		}
		mysql_close (conn);
	}
	
	if (codigo ==3)
	{
		char fecha[20];
		strcpy (fecha, p); 
		char consulta1[80]; 
		strcpy(consulta1,"SELECT Jugador.nombre FROM Jugador,Relacion,Partida WHERE partida.fecha = '");
		strcat(consulta1,fecha);
		strcat(consulta1,"'AND Partida.id = Relacion.idpartida AND jugador.id = relacion.idjugador");
		err=mysql_query (conn,consulta1);
		
		if (err!=0)
		{
			printf ("Error al consultar datos de la base %u %s\n",
					mysql_errno(conn), mysql_error(conn));
			exit (1);
		}
		
		resultado = mysql_store_result (conn);
		row = mysql_fetch_row (resultado);
		if (row == NULL)
		{
			printf ("No se han obtenido datos en la consulta\n");
		}
		else
		{
			strcpy (respuesta, "3/");
			
			while (row !=NULL) 
			{
				sprintf(respuesta,"respuesta%s,",row[0]);
				row = mysql_fetch_row (resultado);
			}
			return 1;
			mysql_close (conn);
		}
		
	}
}
int Poner(char nombre[20],int socket, ListaConectados *lista)
{	
	if (lista->num<100)
	{
		lista->usuarios[lista->num].socket=socket;
		strcpy(lista->usuarios[lista->num].nombre,nombre);
		lista->num++;
		return 0;
	}
	else
	{
		return -1;
	}
}
int Quitar(char nombre[20],ListaConectados *lista)
{
	int encontrado=0;
	int i=0;
	while ((i<lista->num) &&(!encontrado))
	{
		if (strcmp(lista->usuarios[i].nombre,nombre)==0)
			encontrado=1;
		else
			i=i+1;
	}
	if (encontrado)
	{
		while (lista->num-1)
		{
			lista[i]=lista[i+1];
			i=i+1;
		}
		lista->num=lista->num-1;
		return 0;
	}
	else
		return -1;
}

void Dameconectados(ListaConectados *lista,char conectados[500])
{
	sprintf(conectados, "%s/%d", lista->usuarios[0].nombre, lista->usuarios[0].socket);
	for (int r=1;r<lista->num;r++) 
	{ 
		sprintf(conectados, "/%s/%d", lista->usuarios[r].nombre, lista->usuarios[r].socket);
	}
	
}
void *AtenderCliente (void *socket)
{
	ListaConectados milista;
	int sock_conn;
	int *s;
	s= (int *) socket;
	sock_conn = *s;
	//int socket_conn = * (int *) socket;
	
	char peticion[512];
	char respuesta[512];
	int ret; 
	
	int terminar; 
	while (terminar == 0) 
	{
		// Ahora recibimos su nombre, que dejamos en buff
		ret=read(sock_conn,peticion, sizeof(peticion));
		printf ("Recibido\n");
		
		// Tenemos que a�adirle la marca de fin de string 
		// para que no escriba lo que hay despues en el buffer
		peticion[ret]='\0';
		
		//Escribimos el nombre en la consola
		
		printf ("Peticion: %s\n",peticion);
		
		
		char *p = strtok(peticion, "/");
		int codigo =  atoi (p);
		char usuario [20]; 
		if (codigo !=0)
		{ 
			int num = CONSULTARBBDD (codigo, respuesta, p, usuario);
			
			if (num == 0)
			{ 
				terminar = 1; 
			}
			else 
			{ 
				write (sock_conn,respuesta, strlen(respuesta));
			}
		}
		if (codigo == 1) 
		{
			pthread_mutex_lock(&mutex);
			int r = Poner(usuario,sock_conn, &milista); 
			pthread_mutex_unlock(&mutex);
			if (r == 0) 
			{ 
				printf("Cambios realizados con exito\n");
			}
			else 
			{ 
				printf("Error al a�adir usuario conectado\n");
			}
		}
		
		if (codigo == 0)
		{
			pthread_mutex_lock(&mutex); 
			int r = Quitar (usuario, &milista);
			pthread_mutex_unlock(&mutex);
			if (r == 0) 
			{ 
				printf("Cambios realizados con exito\n");
			}
			else 
			{ 
				printf("Error al a�adir usuario conectado\n");
			}	
		}
		
		
		if (codigo == 4) 
		{ 
			pthread_mutex_lock(&mutex);
			char conectados[500];
			Dameconectados(&milista,conectados);
			pthread_mutex_unlock ( &mutex );
			char notificacion[20];
			sprintf(notificacion, "4/%s", conectados);
			write(sock_conn, notificacion, strlen(notificacion));
		}
	} 
	close (sock_conn);
}


int main(int argc, char *argv[])
{
	ABRIRBBDD ();
	ListaConectados milista;
	int sock_conn, sock_listen;
	struct sockaddr_in serv_adr;
	
	// INICIALITZACIONS
	// Obrim el socket
	if ((sock_listen = socket(AF_INET, SOCK_STREAM, 0)) < 0)
		printf("Error creant socket\n");
	// Fem el bind al port
	
	
	memset(&serv_adr, 0, sizeof(serv_adr));// inicialitza a zero serv_addr
	serv_adr.sin_family = AF_INET;
	
	// asocia el socket a cualquiera de las IP de la m?quina. 
	//htonl formatea el numero que recibe al formato necesario
	serv_adr.sin_addr.s_addr = htonl(INADDR_ANY);
	// escucharemos en el port 9050
	serv_adr.sin_port = htons(9050);
	if (bind(sock_listen, (struct sockaddr *) &serv_adr, sizeof(serv_adr)) < 0)
		printf ("Error al bind\n");
	//La cola de peticiones pendientes no podra ser superior a 4
	if (listen(sock_listen, 2) < 0)
		printf("Error en el Listen\n");
	
	int i;
	int counter=0;
	int sockets[100];
	pthread_t thread;
	i=0;
	
	for(;;){
		printf ("Escuchando\n");
		
		sock_conn = accept(sock_listen, NULL, NULL);
		printf ("He recibido conexion\n");
		//sock_conn es el socket que usaremos para este cliente
		sockets[i] = sock_conn;
		//sock_conn es el socket que usaremos para este cliente
		
		// Crear thead y decirle lo que tiene que hacer
		
		pthread_create (&thread, NULL, AtenderCliente,&sockets[i]);
		i=i+1;
		
	}
	
	
}
