void *AtenderCliente (void *socket)
{
	int sock_conn;
	int *s;
	s= (int *) socket;
	sock_conn= *s;
	
	//int socket_conn = * (int *) socket;
	
	char peticion[512];
	char respuesta[512];
	int ret; 
	
	int terminar; 
	while (terminar == 0) 
	{
		// Ahora recibimos su nombre, que dejamos en buff
		ret=read(sock_conn,peticion, sizeof(peticion));
		printf ("Recibido\n");
		
		// Tenemos que a�adirle la marca de fin de string 
		// para que no escriba lo que hay despues en el buffer
		peticion[ret]='\0';
		
		//Escribimos el nombre en la consola
		
		printf ("Peticion: %s\n",peticion);
		
		
		char* p = strtok(peticion, "/");
		int codigo =  atoi (p);
		if (codigo !=0)
		{ 
			CONSULTARBBDD (codigo, respuesta, p)
				if (CONSULTARBBDD == NULL)
			{ 
					terminar = 1; 
			}
				else 
				{ 
					write (sock_conn,respuesta, strlen(respuesta));
				}
		}
		if ((codigo == 1) || (codigo == 2) || (codigo == 3))
		{
			pthread_mutex_lock( &mutex );
			if (codigo == 4) 
			{ 
				char conectados[100];
				DameConectados(&miLista,conectados);
				printf ("%s\n",conectados);
				char notificacion[20];
				sprintf(notificacion, "4/%s", conectados);
				printf("Notificacion: %s\n", notificacion);
				int j=0;
				while (j<miLista.numero)
				{
					write(miLista.conectados[j].socket, notificacion, strlen(notificacion));
					/*				write(4, notificacion, strlen(notificacion));*/
					/*				write(socket[j],notificacion, strlen(notificacion));*/
					j=j+1;
				}
				
			}
			pthread_mutex_unlock ( &mutex );
		} 
		close (sock_conn);
	}
	
	