int CONSULTARBBDD (int codigo, char p[512], char respuesta[512])
{ 
	if (codigo ==0);
	{
		return 0;
	}
	if (codigo ==1)
	{
		printf ("he conseguido entrar en 1");
		peticion = strtok( NULL, "/");
		char nombre[20];
		strcpy (nombre, p);
		char password[20];
		p = strtok( NULL, "/");
		strcpy (password, p); 
		
		char consulta[80]; 
		strcpy(consulta,"SELECT Jugador.Codigo FROM Jugador WHERE Jugador.Nombre = '");
		strcat(consulta, nombre);
		strcat(consulta,"'AND Jugador.Contrase�a = '");
		strcat(consulta, p);
		err=mysql_query (conn,consulta);
		
		if (err!=0)
		{
			printf ("Error al consultar datos de la base %u %s\n",
					mysql_errno(conn), mysql_error(conn));
			
			exit (1);
		}
		
		resultado = mysql_store_result (conn);
		row = mysql_fetch_row (resultado);
		
		if (row == NULL)
		{
			printf ("No se han obtenido datos en la consulta\n");
			strcpy (respuesta,"NO");
			return 1;
		}
		
		
		else		
			strcpy (respuesta,"SI");
			return 1;
		mysql_close (conn);
	}		
	
	if (codigo == 2)
	{
		err=mysql_query (conn, "select Jugador.nombre from Jugador where Jugador.Partidasganadas=(select max(Jugador.Partidasganadas) from Jugador)");
		if (err!=0)
		{
			printf ("Error al consultar datos de la base %u %s\n",
			mysql_errno(conn), mysql_error(conn));
			exit (1);
		}
	
		resultado = mysql_store_result (conn);
		row = mysql_fetch_row (resultado);
	
		if (row == NULL)
		{
			printf ("No se han obtenido datos en la consulta\n");
		}
		else
		{
			strcpy (respuesta,row[0]);
		}
		mysql_close (conn);
	
	if (c ==3)
	{
		char fecha[20];
		strcpy (fecha, p); 
		char consulta1[80]; 
		strcpy(consulta1,"SELECT Jugador.nombre FROM Jugador,Relacion,Partida WHERE partida.fecha = '");
		strcat(consulta1,fecha);
		strcat(consulta1,"'AND Partida.id = Relacion.idpartida AND jugador.id = relacion.idjugador");
		err=mysql_query (conn,consulta);
	
		if (err!=0)
		{
			printf ("Error al consultar datos de la base %u %s\n",
			mysql_errno(conn), mysql_error(conn));
			exit (1);
		}
	
		resultado = mysql_store_result (conn);
		row = mysql_fetch_row (resultado);
		if (row == NULL)
		{
			printf ("No se han obtenido datos en la consulta\n");
		else
		{
			while (row !=NULL) 
			{
				printf ("%s\n", row[0]);
				row = mysql_fetch_row (resultado);
				strcpy (buff2, row);
				sprintf(respuesta,"respuesta,%s",row);
			}
		mysql_close (conn);
			
	}
}
