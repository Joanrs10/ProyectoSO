void ABRIRBBDD (void)
{
MYSQL *conn;
int err;

MYSQL_RES *resultado;
MYSQL_ROW row;


conn = mysql_init(NULL);
if (conn==NULL)
{
	printf ("Error al crear la conexion: %u %s\n",
			mysql_errno(conn), mysql_error(conn));
	exit (1);
}

conn = mysql_real_connect (conn, "localhost", "root", "mysql",
						   "Juego",0, NULL, 0);
if (conn==NULL)
{
	printf ("Error al inicializar la conexion: %u %s\n",
			mysql_errno(conn), mysql_error(conn));
	exit (1);
}
else 
{ 
	printf("COnexion realizada con exito");
}
