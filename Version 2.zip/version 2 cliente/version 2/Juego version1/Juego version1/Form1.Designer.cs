﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Conectbutton = new System.Windows.Forms.Button();
            this.Disconectbutton = new System.Windows.Forms.Button();
            this.Usertext = new System.Windows.Forms.TextBox();
            this.Loginbutton = new System.Windows.Forms.Button();
            this.Passwordtext = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panelfunciones = new System.Windows.Forms.Panel();
            this.fecha = new System.Windows.Forms.TextBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.Consultbutton = new System.Windows.Forms.Button();
            this.Checkf1 = new System.Windows.Forms.CheckBox();
            this.ListaConectados = new System.Windows.Forms.DataGridView();
            this.label3 = new System.Windows.Forms.Label();
            this.panelfunciones.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ListaConectados)).BeginInit();
            this.SuspendLayout();
            // 
            // Conectbutton
            // 
            this.Conectbutton.Location = new System.Drawing.Point(96, 40);
            this.Conectbutton.Name = "Conectbutton";
            this.Conectbutton.Size = new System.Drawing.Size(75, 23);
            this.Conectbutton.TabIndex = 0;
            this.Conectbutton.Text = "Conectar";
            this.Conectbutton.UseVisualStyleBackColor = true;
            // 
            // Disconectbutton
            // 
            this.Disconectbutton.Location = new System.Drawing.Point(96, 78);
            this.Disconectbutton.Name = "Disconectbutton";
            this.Disconectbutton.Size = new System.Drawing.Size(75, 23);
            this.Disconectbutton.TabIndex = 1;
            this.Disconectbutton.Text = "Desconectar";
            this.Disconectbutton.UseVisualStyleBackColor = true;
            // 
            // Usertext
            // 
            this.Usertext.Location = new System.Drawing.Point(442, 40);
            this.Usertext.Name = "Usertext";
            this.Usertext.Size = new System.Drawing.Size(100, 20);
            this.Usertext.TabIndex = 2;
            // 
            // Loginbutton
            // 
            this.Loginbutton.Location = new System.Drawing.Point(458, 143);
            this.Loginbutton.Name = "Loginbutton";
            this.Loginbutton.Size = new System.Drawing.Size(75, 23);
            this.Loginbutton.TabIndex = 3;
            this.Loginbutton.Text = "Login";
            this.Loginbutton.UseVisualStyleBackColor = true;
            this.Loginbutton.Click += new System.EventHandler(this.Loginbutton_Click);
            // 
            // Passwordtext
            // 
            this.Passwordtext.Location = new System.Drawing.Point(442, 96);
            this.Passwordtext.Name = "Passwordtext";
            this.Passwordtext.Size = new System.Drawing.Size(100, 20);
            this.Passwordtext.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(474, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Usuario";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(474, 78);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Contraseña";
            // 
            // panelfunciones
            // 
            this.panelfunciones.Controls.Add(this.fecha);
            this.panelfunciones.Controls.Add(this.checkBox1);
            this.panelfunciones.Controls.Add(this.Consultbutton);
            this.panelfunciones.Controls.Add(this.Checkf1);
            this.panelfunciones.Location = new System.Drawing.Point(24, 228);
            this.panelfunciones.Name = "panelfunciones";
            this.panelfunciones.Size = new System.Drawing.Size(493, 231);
            this.panelfunciones.TabIndex = 7;
            // 
            // fecha
            // 
            this.fecha.Location = new System.Drawing.Point(309, 54);
            this.fecha.Name = "fecha";
            this.fecha.Size = new System.Drawing.Size(100, 20);
            this.fecha.TabIndex = 3;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(62, 56);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(244, 17);
            this.checkBox1.TabIndex = 2;
            this.checkBox1.Text = "Jugadores que jugaron en esta fecha DD/MM";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // Consultbutton
            // 
            this.Consultbutton.Location = new System.Drawing.Point(62, 145);
            this.Consultbutton.Name = "Consultbutton";
            this.Consultbutton.Size = new System.Drawing.Size(75, 23);
            this.Consultbutton.TabIndex = 1;
            this.Consultbutton.Text = "Consultar";
            this.Consultbutton.UseVisualStyleBackColor = true;
            this.Consultbutton.Click += new System.EventHandler(this.Consultbutton_Click);
            // 
            // Checkf1
            // 
            this.Checkf1.AutoSize = true;
            this.Checkf1.Location = new System.Drawing.Point(62, 22);
            this.Checkf1.Name = "Checkf1";
            this.Checkf1.Size = new System.Drawing.Size(272, 17);
            this.Checkf1.TabIndex = 0;
            this.Checkf1.Text = "Quiero saber el jugador que más partidas ha ganado";
            this.Checkf1.UseVisualStyleBackColor = true;
            // 
            // ListaConectados
            // 
            this.ListaConectados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ListaConectados.Location = new System.Drawing.Point(603, 266);
            this.ListaConectados.Name = "ListaConectados";
            this.ListaConectados.Size = new System.Drawing.Size(240, 150);
            this.ListaConectados.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(671, 238);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Lista Conectados";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(855, 533);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.ListaConectados);
            this.Controls.Add(this.panelfunciones);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Passwordtext);
            this.Controls.Add(this.Loginbutton);
            this.Controls.Add(this.Usertext);
            this.Controls.Add(this.Disconectbutton);
            this.Controls.Add(this.Conectbutton);
            this.Name = "Form1";
            this.Text = "Juego version 1";
            this.panelfunciones.ResumeLayout(false);
            this.panelfunciones.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ListaConectados)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Conectbutton;
        private System.Windows.Forms.Button Disconectbutton;
        private System.Windows.Forms.TextBox Usertext;
        private System.Windows.Forms.Button Loginbutton;
        private System.Windows.Forms.TextBox Passwordtext;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panelfunciones;
        private System.Windows.Forms.Button Consultbutton;
        private System.Windows.Forms.CheckBox Checkf1;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.TextBox fecha;
        private System.Windows.Forms.DataGridView ListaConectados;
        private System.Windows.Forms.Label label3;
    }
}

